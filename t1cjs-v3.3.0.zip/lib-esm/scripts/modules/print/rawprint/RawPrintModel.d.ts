import { T1CLibException, T1CResponse } from "../../../..";
export interface AbstractRawPrint {
    list(callback?: (error: T1CLibException, data: PrinterListResponse) => void): Promise<PrinterListResponse>;
    print(name: string, job: string, data: string, callback?: (error: T1CLibException, data: PrintResponse) => void): Promise<PrintResponse>;
}
export declare class PrinterList {
    printers: Array<string>;
    constructor(printers: Array<string>);
}
export declare class PrinterListResponse extends T1CResponse {
    data: PrinterList;
    success: boolean;
    constructor(data: PrinterList, success: boolean);
}
export declare class Print {
    printed: boolean;
    constructor(printed: boolean);
}
export declare class PrintResponse extends T1CResponse {
    data: Print;
    success: boolean;
    constructor(data: Print, success: boolean);
}
