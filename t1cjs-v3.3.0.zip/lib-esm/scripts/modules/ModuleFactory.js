import { EidBe } from './smartcards/token/eid/be/EidBe';
import { Aventra } from './smartcards/token/pki/aventra4/Aventra';
import { Oberthur } from "./smartcards/token/pki/oberthur73/Oberthur";
import { Idemia } from "./smartcards/token/pki/idemia82/Idemia";
import { Emv } from "./smartcards/payment/emv/Emv";
import { FileExchange } from "./file/fileExchange/FileExchange";
import { RemoteLoading } from "./hsm/remoteloading/RemoteLoading";
import { EidGeneric } from "./smartcards/token/eid/generic/EidGeneric";
import { EidDiplad } from "./smartcards/token/eid/diplad/EidDiplad";
import { Pkcs11Generic } from "./pkcs11/generic/Pkcs11Generic";
import { PaymentGeneric } from "./smartcards/payment/generic/PaymentGeneric";
import { EidLux } from "./smartcards/token/eid/lux/EidLux";
import { Wacom } from "./wacom/Wacom";
import { PKCS11 } from "./pkcs11/pkcs11Object/Pkcs11";
import { Crelan } from "./smartcards/payment/crelan/Crelan";
import { RawPrint } from "./print/rawprint/RawPrint";
var CONTAINER_NEW_CONTEXT_PATH = '/modules/';
var CONTAINER_BEID = CONTAINER_NEW_CONTEXT_PATH + 'beid';
var CONTAINER_DIPLAD = CONTAINER_NEW_CONTEXT_PATH + 'diplad';
var CONTAINER_LUXEID = CONTAINER_NEW_CONTEXT_PATH + 'luxeid';
var CONTAINER_DNIE = CONTAINER_NEW_CONTEXT_PATH + 'dnie';
var CONTAINER_EMV = CONTAINER_NEW_CONTEXT_PATH + 'emv';
var CONTAINER_CRELAN = CONTAINER_NEW_CONTEXT_PATH + 'crelan';
var CONTAINER_WACOM = CONTAINER_NEW_CONTEXT_PATH + 'wacom-stu';
var CONTAINER_ISABEL = CONTAINER_NEW_CONTEXT_PATH + 'isabel';
var CONTAINER_FILE_EXCHANGE = CONTAINER_NEW_CONTEXT_PATH + 'fileexchange';
var CONTAINER_LUXTRUST = CONTAINER_NEW_CONTEXT_PATH + 'luxtrust';
var CONTAINER_MOBIB = CONTAINER_NEW_CONTEXT_PATH + 'mobib';
var CONTAINER_OCRA = CONTAINER_NEW_CONTEXT_PATH + 'ocra';
var CONTAINER_AVENTRA = CONTAINER_NEW_CONTEXT_PATH + 'aventra_myid_4';
var CONTAINER_OBERTHUR = CONTAINER_NEW_CONTEXT_PATH + 'oberthur_73';
var CONTAINER_IDEMIA = CONTAINER_NEW_CONTEXT_PATH + 'idemia_cosmo_82';
var CONTAINER_PIV = CONTAINER_NEW_CONTEXT_PATH + 'piv';
var CONTAINER_PTEID = CONTAINER_NEW_CONTEXT_PATH + 'pteid';
var CONTAINER_PKCS11 = CONTAINER_NEW_CONTEXT_PATH + 'pkcs11';
var CONTAINER_PKCS11_Object = CONTAINER_NEW_CONTEXT_PATH + 'pkcs11-objects';
var CONTAINER_REMOTE_LOADING = CONTAINER_NEW_CONTEXT_PATH + 'remoteloading';
var CONTAINER_JAVA_KEY_TOOL = CONTAINER_NEW_CONTEXT_PATH + 'java-keytool';
var CONTAINER_SSH = CONTAINER_NEW_CONTEXT_PATH + 'ssh';
var CONTAINER_RAW_PRINT = CONTAINER_NEW_CONTEXT_PATH + 'rawprint';
var ModuleFactory = (function () {
    function ModuleFactory(url, connection) {
        this.url = url;
        this.connection = connection;
    }
    ModuleFactory.prototype.createEidGeneric = function (reader_id, pin, pinType) {
        return new EidGeneric(this.url, CONTAINER_NEW_CONTEXT_PATH, this.connection, reader_id, pin, pinType);
    };
    ModuleFactory.prototype.createEidGenericMeta = function () {
        return new EidGeneric(this.url, CONTAINER_NEW_CONTEXT_PATH, this.connection, "");
    };
    ModuleFactory.prototype.createPaymentGeneric = function (reader_id) {
        return new PaymentGeneric(this.url, CONTAINER_NEW_CONTEXT_PATH, this.connection, reader_id);
    };
    ModuleFactory.prototype.createPaymentGenericMeta = function () {
        return new PaymentGeneric(this.url, CONTAINER_NEW_CONTEXT_PATH, this.connection, "");
    };
    ModuleFactory.prototype.createEidDiplad = function (reader_id) {
        return new EidDiplad(this.url, CONTAINER_DIPLAD, this.connection, reader_id);
    };
    ModuleFactory.prototype.createPKCS11Generic = function () {
        return new Pkcs11Generic(this.url, CONTAINER_PKCS11, this.connection);
    };
    ModuleFactory.prototype.createEidBE = function (reader_id) {
        return new EidBe(this.url, CONTAINER_BEID, this.connection, reader_id);
    };
    ModuleFactory.prototype.createAventra = function (reader_id) {
        return new Aventra(this.url, CONTAINER_AVENTRA, this.connection, reader_id);
    };
    ModuleFactory.prototype.createOberthur = function (reader_id) {
        return new Oberthur(this.url, CONTAINER_OBERTHUR, this.connection, reader_id);
    };
    ModuleFactory.prototype.createIdemia = function (reader_id) {
        return new Idemia(this.url, CONTAINER_IDEMIA, this.connection, reader_id);
    };
    ModuleFactory.prototype.createEmv = function (reader_id) {
        return new Emv(this.url, CONTAINER_EMV, this.connection, reader_id);
    };
    ModuleFactory.prototype.createCrelan = function (reader_id) {
        return new Crelan(this.url, CONTAINER_CRELAN, this.connection, reader_id);
    };
    ModuleFactory.prototype.createFileExchange = function () {
        return new FileExchange(this.url, CONTAINER_FILE_EXCHANGE, this.connection);
    };
    ModuleFactory.prototype.createRawPrint = function () {
        return new RawPrint(this.url, CONTAINER_RAW_PRINT, this.connection);
    };
    ModuleFactory.prototype.createRemoteLoading = function (reader_id) {
        return new RemoteLoading(this.url, CONTAINER_REMOTE_LOADING, this.connection, reader_id);
    };
    ModuleFactory.prototype.createEidLUX = function (reader_id, pin, pinType) {
        return new EidLux(this.url, CONTAINER_LUXEID, this.connection, reader_id, pin, pinType);
    };
    ModuleFactory.prototype.createWacom = function () {
        return new Wacom(this.url, CONTAINER_WACOM, this.connection);
    };
    ModuleFactory.prototype.createPKCS11 = function (modulePath) {
        return new PKCS11(this.url, CONTAINER_PKCS11_Object, this.connection, modulePath);
    };
    return ModuleFactory;
}());
export { ModuleFactory };
//# sourceMappingURL=ModuleFactory.js.map