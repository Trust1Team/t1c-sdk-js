var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
import { DataObjectResponse, } from '../../../../../core/service/CoreModel';
var ModuleDescriptionResponse = (function (_super) {
    __extends(ModuleDescriptionResponse, _super);
    function ModuleDescriptionResponse(data, success) {
        var _this = _super.call(this, data, success) || this;
        _this.data = data;
        _this.success = success;
        return _this;
    }
    return ModuleDescriptionResponse;
}(DataObjectResponse));
export { ModuleDescriptionResponse };
var TokenAddressResponse = (function (_super) {
    __extends(TokenAddressResponse, _super);
    function TokenAddressResponse(data, success) {
        var _this = _super.call(this, data, success) || this;
        _this.data = data;
        _this.success = success;
        return _this;
    }
    return TokenAddressResponse;
}(DataObjectResponse));
export { TokenAddressResponse };
var TokenPictureResponse = (function (_super) {
    __extends(TokenPictureResponse, _super);
    function TokenPictureResponse(data, success) {
        var _this = _super.call(this, data, success) || this;
        _this.data = data;
        _this.success = success;
        return _this;
    }
    return TokenPictureResponse;
}(DataObjectResponse));
export { TokenPictureResponse };
var TokenVerifyPinResponse = (function (_super) {
    __extends(TokenVerifyPinResponse, _super);
    function TokenVerifyPinResponse(data, success) {
        var _this = _super.call(this, data, success) || this;
        _this.data = data;
        _this.success = success;
        return _this;
    }
    return TokenVerifyPinResponse;
}(DataObjectResponse));
export { TokenVerifyPinResponse };
var TokenVerifyPinResponseData = (function () {
    function TokenVerifyPinResponseData(verified) {
        this.verified = verified;
    }
    return TokenVerifyPinResponseData;
}());
export { TokenVerifyPinResponseData };
var TokenSignResponse = (function (_super) {
    __extends(TokenSignResponse, _super);
    function TokenSignResponse(data, success) {
        var _this = _super.call(this, data, success) || this;
        _this.data = data;
        _this.success = success;
        return _this;
    }
    return TokenSignResponse;
}(DataObjectResponse));
export { TokenSignResponse };
var TokenSignResponseData = (function () {
    function TokenSignResponseData(data) {
        this.data = data;
    }
    return TokenSignResponseData;
}());
export { TokenSignResponseData };
var TokenAuthenticateResponse = (function (_super) {
    __extends(TokenAuthenticateResponse, _super);
    function TokenAuthenticateResponse(data, success) {
        var _this = _super.call(this, data, success) || this;
        _this.data = data;
        _this.success = success;
        return _this;
    }
    return TokenAuthenticateResponse;
}(DataObjectResponse));
export { TokenAuthenticateResponse };
var TokenAuthenticateResponseData = (function () {
    function TokenAuthenticateResponseData(data) {
        this.data = data;
    }
    return TokenAuthenticateResponseData;
}());
export { TokenAuthenticateResponseData };
var TokenModuleDescription = (function () {
    function TokenModuleDescription(desc) {
        this.desc = desc;
    }
    return TokenModuleDescription;
}());
export { TokenModuleDescription };
var TokenAddressData = (function () {
    function TokenAddressData(municipality, rawData, signature, streetAndNumber, version, zipcode) {
        this.municipality = municipality;
        this.rawData = rawData;
        this.signature = signature;
        this.streetAndNumber = streetAndNumber;
        this.version = version;
        this.zipcode = zipcode;
    }
    return TokenAddressData;
}());
export { TokenAddressData };
var TokenAllDataResponse = (function (_super) {
    __extends(TokenAllDataResponse, _super);
    function TokenAllDataResponse(data, success) {
        var _this = _super.call(this, data, success) || this;
        _this.data = data;
        _this.success = success;
        return _this;
    }
    return TokenAllDataResponse;
}(DataObjectResponse));
export { TokenAllDataResponse };
var TokenAllData = (function () {
    function TokenAllData(picture, biometric, address) {
        this.picture = picture;
        this.biometric = biometric;
        this.address = address;
    }
    return TokenAllData;
}());
export { TokenAllData };
var TokenPictureData = (function () {
    function TokenPictureData(picture, signature, width, height) {
        this.picture = picture;
        this.signature = signature;
        this.width = width;
        this.height = height;
    }
    return TokenPictureData;
}());
export { TokenPictureData };
var TokenData = (function () {
    function TokenData(rawData, version, serialNumber, label, prnGeneration, eidCompliant, graphicalPersoVersion, versionRfu, electricalPersoVersion, electricalPersoInterfaceVersion, changeCounter, activated) {
        this.rawData = rawData;
        this.version = version;
        this.serialNumber = serialNumber;
        this.label = label;
        this.prnGeneration = prnGeneration;
        this.eidCompliant = eidCompliant;
        this.graphicalPersoVersion = graphicalPersoVersion;
        this.versionRfu = versionRfu;
        this.electricalPersoVersion = electricalPersoVersion;
        this.electricalPersoInterfaceVersion = electricalPersoInterfaceVersion;
        this.changeCounter = changeCounter;
        this.activated = activated;
    }
    return TokenData;
}());
export { TokenData };
var TokenDataResponse = (function (_super) {
    __extends(TokenDataResponse, _super);
    function TokenDataResponse(data, success) {
        var _this = _super.call(this, data, success) || this;
        _this.data = data;
        _this.success = success;
        return _this;
    }
    return TokenDataResponse;
}(DataObjectResponse));
export { TokenDataResponse };
var TokenBiometricData = (function () {
    function TokenBiometricData(birthDate, birthLocation, cardDeliveryMunicipality, cardNumber, cardValidityDateBegin, cardValidityDateEnd, chipNumber, documentType, firstNames, name, nationalNumber, nationality, nobleCondition, pictureHash, rawData, sex, signature, specialStatus, thirdName, version, issuer) {
        this.birthDate = birthDate;
        this.birthLocation = birthLocation;
        this.cardDeliveryMunicipality = cardDeliveryMunicipality;
        this.cardNumber = cardNumber;
        this.cardValidityDateBegin = cardValidityDateBegin;
        this.cardValidityDateEnd = cardValidityDateEnd;
        this.chipNumber = chipNumber;
        this.documentType = documentType;
        this.firstNames = firstNames;
        this.name = name;
        this.nationalNumber = nationalNumber;
        this.nationality = nationality;
        this.nobleCondition = nobleCondition;
        this.pictureHash = pictureHash;
        this.rawData = rawData;
        this.sex = sex;
        this.signature = signature;
        this.specialStatus = specialStatus;
        this.thirdName = thirdName;
        this.version = version;
        this.issuer = issuer;
    }
    return TokenBiometricData;
}());
export { TokenBiometricData };
var TokenBiometricDataResponse = (function (_super) {
    __extends(TokenBiometricDataResponse, _super);
    function TokenBiometricDataResponse(data, success) {
        var _this = _super.call(this, data, success) || this;
        _this.data = data;
        _this.success = success;
        return _this;
    }
    return TokenBiometricDataResponse;
}(DataObjectResponse));
export { TokenBiometricDataResponse };
var TokenAlgorithmReferencesResponse = (function () {
    function TokenAlgorithmReferencesResponse(data, success) {
        this.data = data;
        this.success = success;
    }
    return TokenAlgorithmReferencesResponse;
}());
export { TokenAlgorithmReferencesResponse };
var TokenAlgorithmReferences = (function () {
    function TokenAlgorithmReferences(ref) {
        this.ref = ref;
    }
    return TokenAlgorithmReferences;
}());
export { TokenAlgorithmReferences };
var TokenResetPinResponse = (function () {
    function TokenResetPinResponse(data, success) {
        this.data = data;
        this.success = success;
    }
    return TokenResetPinResponse;
}());
export { TokenResetPinResponse };
var TokenResetPin = (function () {
    function TokenResetPin(verified) {
        this.verified = verified;
    }
    return TokenResetPin;
}());
export { TokenResetPin };
//# sourceMappingURL=EidGenericModel.js.map