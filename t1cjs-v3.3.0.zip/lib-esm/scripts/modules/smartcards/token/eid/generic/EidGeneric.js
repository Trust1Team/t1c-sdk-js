import { RequestHandler } from '../../../../../util/RequestHandler';
import { CertParser } from "../../../../../util/CertParser";
import { ResponseHandler } from "../../../../../util/ResponseHandler";
import { PinType, Pinutil } from "../../../../../..";
var EidGeneric = (function () {
    function EidGeneric(baseUrl, containerUrl, connection, reader_id, pin, pinType) {
        this.baseUrl = baseUrl;
        this.containerUrl = containerUrl;
        this.connection = connection;
        this.reader_id = reader_id;
        this.pin = pin;
        this.pinType = pinType;
    }
    EidGeneric.EncryptedHeader = function (code, pinType) {
        if (code && pinType) {
            if (pinType === PinType.CAN) {
                return { 'X-Pace-Can': Pinutil.encryptPin(code) };
            }
            else {
                return { 'X-Pace-Pin': Pinutil.encryptPin(code) };
            }
        }
        else {
            return undefined;
        }
    };
    EidGeneric.prototype.allData = function (module, options, callback) {
        var requestOptions = RequestHandler.determineOptionsWithFilter(options);
        return this.connection.get(this.baseUrl, this.tokenApp(module, EidGeneric.ALL_DATA, true), requestOptions.params, EidGeneric.EncryptedHeader(this.pin, this.pinType), callback);
    };
    EidGeneric.prototype.biometric = function (module, callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(module, EidGeneric.BIOMETRIC, true), undefined, EidGeneric.EncryptedHeader(this.pin, this.pinType), callback);
    };
    EidGeneric.prototype.address = function (module, callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(module, EidGeneric.ADDRESS, true), undefined, EidGeneric.EncryptedHeader(this.pin, this.pinType), callback);
    };
    EidGeneric.prototype.tokenData = function (module, callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(module, EidGeneric.TOKEN, true), undefined, EidGeneric.EncryptedHeader(this.pin, this.pinType), callback);
    };
    EidGeneric.prototype.picture = function (module, callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(module, EidGeneric.PHOTO, true), undefined, EidGeneric.EncryptedHeader(this.pin, this.pinType), callback);
    };
    EidGeneric.prototype.rootCertificate = function (module, parseCerts, callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(module, EidGeneric.CERT_ROOT, true), undefined, EidGeneric.EncryptedHeader(this.pin, this.pinType), callback).then(function (res) {
            return CertParser.processTokenCertificate(res, parseCerts, callback);
        }).catch(function (error) {
            return ResponseHandler.error(error, callback);
        });
    };
    EidGeneric.prototype.intermediateCertificates = function (module, parseCerts, callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(module, EidGeneric.CERT_INTERMEDIATE, true), undefined, EidGeneric.EncryptedHeader(this.pin, this.pinType), callback).then(function (res) {
            return CertParser.processTokenCertificate(res, parseCerts, callback);
        }).catch(function (error) {
            return ResponseHandler.error(error, callback);
        });
    };
    EidGeneric.prototype.authenticationCertificate = function (module, parseCerts, callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(module, EidGeneric.CERT_AUTHENTICATION, true), undefined, EidGeneric.EncryptedHeader(this.pin, this.pinType), callback).then(function (res) {
            return CertParser.processTokenCertificate(res, parseCerts, callback);
        }).catch(function (error) {
            return ResponseHandler.error(error, callback);
        });
    };
    EidGeneric.prototype.nonRepudiationCertificate = function (module, parseCerts, callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(module, EidGeneric.CERT_NON_REPUDIATION, true), undefined, EidGeneric.EncryptedHeader(this.pin, this.pinType), callback).then(function (res) {
            return CertParser.processTokenCertificate(res, parseCerts, callback);
        }).catch(function (error) {
            return ResponseHandler.error(error, callback);
        });
    };
    EidGeneric.prototype.encryptionCertificate = function (module, parseCerts, callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(module, EidGeneric.CERT_ENCRYPTION, true), undefined, EidGeneric.EncryptedHeader(this.pin, this.pinType), callback).then(function (res) {
            return CertParser.processTokenCertificate(res, parseCerts, callback);
        }).catch(function (error) {
            return ResponseHandler.error(error, callback);
        });
    };
    EidGeneric.prototype.allAlgoRefs = function (module, callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(module, EidGeneric.SUPPORTED_ALGOS, true), undefined, EidGeneric.EncryptedHeader(this.pin, this.pinType), callback);
    };
    EidGeneric.prototype.allCerts = function (module, parseCerts, options, callback) {
        var reqOptions = RequestHandler.determineOptionsWithFilter(options);
        return this.connection.get(this.baseUrl, this.tokenApp(module, EidGeneric.ALL_CERTIFICATES, true), reqOptions.params, EidGeneric.EncryptedHeader(this.pin, this.pinType), callback).then(function (res) {
            return CertParser.processTokenAllCertificates(res, parseCerts, callback);
        }).catch(function (error) {
            return ResponseHandler.error(error, callback);
        });
    };
    EidGeneric.prototype.verifyPin = function (module, body, callback) {
        body.pin = Pinutil.encryptPin(body.pin);
        return this.connection.post(this.baseUrl, this.tokenApp(module, EidGeneric.VERIFY_PIN, true), body, undefined, EidGeneric.EncryptedHeader(this.pin, this.pinType), callback);
    };
    EidGeneric.prototype.authenticate = function (module, body, callback) {
        body.pin = Pinutil.encryptPin(body.pin);
        return this.connection.post(this.baseUrl, this.tokenApp(module, EidGeneric.AUTHENTICATE, true), body, undefined, EidGeneric.EncryptedHeader(this.pin, this.pinType), callback);
    };
    EidGeneric.prototype.sign = function (module, body, bulk, callback) {
        body.pin = Pinutil.encryptPin(body.pin);
        return this.connection.post(this.baseUrl, this.tokenApp(module, EidGeneric.SIGN_DATA, true), body, this.getBulkSignQueryParams(bulk), EidGeneric.EncryptedHeader(this.pin, this.pinType), callback);
    };
    EidGeneric.prototype.resetBulkPin = function (module, callback) {
        return this.connection.post(this.baseUrl, this.tokenApp(module, EidGeneric.RESET_BULK_PIN, false), null, undefined, EidGeneric.EncryptedHeader(this.pin, this.pinType), callback);
    };
    EidGeneric.prototype.tokenApp = function (module, path, includeReaderId) {
        var suffix = this.containerUrl;
        suffix += module;
        suffix += EidGeneric.PATH_TOKEN_APP;
        if (this.reader_id && this.reader_id.length && includeReaderId) {
            suffix += EidGeneric.PATH_READERS + '/' + this.reader_id;
        }
        if (path && path.length) {
            suffix += path.startsWith('/') ? path : '/' + path;
        }
        return suffix;
    };
    EidGeneric.prototype.baseApp = function (module, path) {
        var suffix = this.containerUrl;
        suffix += module;
        if (path && path.length) {
            suffix += path.startsWith('/') ? path : '/' + path;
        }
        return suffix;
    };
    EidGeneric.prototype.getModuleDescription = function (module, callback) {
        return this.connection.get(this.baseUrl, this.baseApp(module, EidGeneric.PATH_MOD_DESC), undefined, EidGeneric.EncryptedHeader(this.pin, this.pinType), callback);
    };
    EidGeneric.prototype.getBulkSignQueryParams = function (bulk) {
        if (bulk) {
            return { bulk: true };
        }
    };
    EidGeneric.PATH_TOKEN_APP = '/apps/token';
    EidGeneric.PATH_MOD_DESC = '/desc';
    EidGeneric.PATH_READERS = '/readers';
    EidGeneric.ALL_DATA = '/all-data';
    EidGeneric.ALL_CERTIFICATES = '/cert-list';
    EidGeneric.CERT_ROOT = '/root-cert';
    EidGeneric.CERT_AUTHENTICATION = '/authentication-cert';
    EidGeneric.CERT_NON_REPUDIATION = '/nonrepudiation-cert';
    EidGeneric.CERT_ENCRYPTION = '/encryption-cert';
    EidGeneric.CERT_INTERMEDIATE = '/intermediate-certs';
    EidGeneric.BIOMETRIC = '/biometric';
    EidGeneric.ADDRESS = '/address';
    EidGeneric.PHOTO = '/picture';
    EidGeneric.TOKEN = '/info';
    EidGeneric.VERIFY_PIN = '/verify-pin';
    EidGeneric.SIGN_DATA = '/sign';
    EidGeneric.AUTHENTICATE = '/authenticate';
    EidGeneric.VERIFY_PRIV_KEY_REF = 'non-repudiation';
    EidGeneric.SUPPORTED_ALGOS = '/supported-algorithms';
    EidGeneric.RESET_BULK_PIN = "/reset-bulk-pin";
    return EidGeneric;
}());
export { EidGeneric };
//# sourceMappingURL=EidGeneric.js.map