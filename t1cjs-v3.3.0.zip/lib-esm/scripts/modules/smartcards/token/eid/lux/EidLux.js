import { RequestHandler } from '../../../../../util/RequestHandler';
import { PinType } from "./EidLuxModel";
import { CertParser } from "../../../../../util/CertParser";
import { ResponseHandler } from "../../../../../util/ResponseHandler";
import { Pinutil } from "../../../../../..";
var EidLux = (function () {
    function EidLux(baseUrl, containerUrl, connection, reader_id, pin, pinType) {
        this.baseUrl = baseUrl;
        this.containerUrl = containerUrl;
        this.connection = connection;
        this.reader_id = reader_id;
        this.pin = pin;
        this.pinType = pinType;
        if (!pinType) {
            this.pinType = PinType.PIN;
        }
    }
    EidLux.EncryptedHeader = function (code, pinType) {
        if (pinType === PinType.CAN) {
            return { 'X-Pace-Can': code === undefined ? '' : Pinutil.encryptPin(code) };
        }
        else {
            return { 'X-Pace-Pin': code === undefined ? '' : Pinutil.encryptPin(code) };
        }
    };
    EidLux.prototype.allData = function (options, callback) {
        var requestOptions = RequestHandler.determineOptionsWithFilter(options);
        return this.connection.get(this.baseUrl, this.tokenApp(EidLux.ALL_DATA, true), requestOptions.params, EidLux.EncryptedHeader(this.pin, this.pinType), callback);
    };
    EidLux.prototype.biometric = function (callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(EidLux.RN_DATA, true), undefined, EidLux.EncryptedHeader(this.pin, this.pinType), callback);
    };
    EidLux.prototype.address = function (callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(EidLux.ADDRESS, true), undefined, EidLux.EncryptedHeader(this.pin, this.pinType), callback);
    };
    EidLux.prototype.tokenData = function (callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(EidLux.TOKEN, true), undefined, EidLux.EncryptedHeader(this.pin, this.pinType), callback);
    };
    EidLux.prototype.picture = function (callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(EidLux.PHOTO, true), undefined, EidLux.EncryptedHeader(this.pin, this.pinType), callback);
    };
    EidLux.prototype.rootCertificate = function (parseCerts, callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(EidLux.CERT_ROOT, true), undefined, EidLux.EncryptedHeader(this.pin, this.pinType), callback).then(function (res) {
            return CertParser.processTokenCertificate(res, parseCerts, callback);
        }).catch(function (error) {
            return ResponseHandler.error(error, callback);
        });
    };
    EidLux.prototype.authenticationCertificate = function (parseCerts, callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(EidLux.CERT_AUTHENTICATION, true), undefined, EidLux.EncryptedHeader(this.pin, this.pinType), callback).then(function (res) {
            return CertParser.processTokenCertificate(res, parseCerts, callback);
        }).catch(function (error) {
            return ResponseHandler.error(error, callback);
        });
    };
    EidLux.prototype.nonRepudiationCertificate = function (parseCerts, callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(EidLux.CERT_NON_REPUDIATION, true), undefined, EidLux.EncryptedHeader(this.pin, this.pinType), callback).then(function (res) {
            return CertParser.processTokenCertificate(res, parseCerts, callback);
        }).catch(function (error) {
            return ResponseHandler.error(error, callback);
        });
    };
    EidLux.prototype.allAlgoRefs = function (callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(EidLux.SUPPORTED_ALGOS, true), undefined, EidLux.EncryptedHeader(this.pin, this.pinType), callback);
    };
    EidLux.prototype.allCerts = function (parseCerts, options, callback) {
        var reqOptions = RequestHandler.determineOptionsWithFilter(options);
        return this.connection.get(this.baseUrl, this.tokenApp(EidLux.ALL_CERTIFICATES, true), reqOptions.params, EidLux.EncryptedHeader(this.pin, this.pinType), callback).then(function (res) {
            return CertParser.processTokenAllCertificates(res, parseCerts, callback);
        }).catch(function (error) {
            return ResponseHandler.error(error, callback);
        });
    };
    EidLux.prototype.verifyPin = function (body, callback) {
        body.pin = Pinutil.encryptPin(body.pin);
        return this.connection.post(this.baseUrl, this.tokenApp(EidLux.VERIFY_PIN, true), body, undefined, EidLux.EncryptedHeader(this.pin, this.pinType), callback);
    };
    EidLux.prototype.authenticate = function (body, callback) {
        body.pin = Pinutil.encryptPin(body.pin);
        return this.connection.post(this.baseUrl, this.tokenApp(EidLux.AUTHENTICATE, true), body, undefined, EidLux.EncryptedHeader(this.pin, this.pinType), callback);
    };
    EidLux.prototype.sign = function (body, bulk, callback) {
        body.pin = Pinutil.encryptPin(body.pin);
        return this.connection.post(this.baseUrl, this.tokenApp(EidLux.SIGN_DATA, true), body, this.getBulkSignQueryParams(bulk), EidLux.EncryptedHeader(this.pin, this.pinType), callback);
    };
    EidLux.prototype.resetBulkPin = function (callback) {
        return this.connection.post(this.baseUrl, this.tokenApp(EidLux.RESET_BULK_PIN, false), null, undefined, undefined, callback);
    };
    EidLux.prototype.tokenApp = function (path, includeReaderId) {
        var suffix = this.containerUrl;
        suffix += EidLux.PATH_TOKEN_APP;
        if (this.reader_id && this.reader_id.length && includeReaderId) {
            suffix += EidLux.PATH_READERS + '/' + this.reader_id;
        }
        if (path && path.length) {
            suffix += path.startsWith('/') ? path : '/' + path;
        }
        return suffix;
    };
    EidLux.prototype.getBulkSignQueryParams = function (bulk) {
        if (bulk) {
            return { bulk: true };
        }
    };
    EidLux.PATH_TOKEN_APP = '/apps/token';
    EidLux.PATH_READERS = '/readers';
    EidLux.ALL_DATA = '/all-data';
    EidLux.ALL_CERTIFICATES = '/cert-list';
    EidLux.CERT_ROOT = '/root-cert';
    EidLux.CERT_AUTHENTICATION = '/authentication-cert';
    EidLux.CERT_NON_REPUDIATION = '/nonrepudiation-cert';
    EidLux.RN_DATA = '/biometric';
    EidLux.ADDRESS = '/address';
    EidLux.PHOTO = '/picture';
    EidLux.TOKEN = '/info';
    EidLux.VERIFY_PIN = '/verify-pin';
    EidLux.SIGN_DATA = '/sign';
    EidLux.AUTHENTICATE = '/authenticate';
    EidLux.VERIFY_PRIV_KEY_REF = 'non-repudiation';
    EidLux.SUPPORTED_ALGOS = '/supported-algorithms';
    EidLux.RESET_BULK_PIN = "/reset-bulk-pin";
    return EidLux;
}());
export { EidLux };
//# sourceMappingURL=EidLux.js.map