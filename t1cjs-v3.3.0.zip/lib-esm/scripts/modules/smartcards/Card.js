var Options = (function () {
    function Options(filters, parseCerts) {
        this.filters = filters;
        this.parseCerts = parseCerts;
    }
    return Options;
}());
export { Options };
//# sourceMappingURL=Card.js.map