var PaymentVerifyPinData = (function () {
    function PaymentVerifyPinData(pin, osDialog) {
        this.pin = pin;
        this.osDialog = osDialog;
    }
    return PaymentVerifyPinData;
}());
export { PaymentVerifyPinData };
var PaymentSignData = (function () {
    function PaymentSignData(txId, language, data) {
        this.txId = txId;
        this.language = language;
        this.data = data;
    }
    return PaymentSignData;
}());
export { PaymentSignData };
//# sourceMappingURL=PaymentCard.js.map