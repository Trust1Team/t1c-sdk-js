var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
import { DataObjectResponse } from "../../../../../index";
var PaymentModuleDescriptionResponse = (function (_super) {
    __extends(PaymentModuleDescriptionResponse, _super);
    function PaymentModuleDescriptionResponse(data, success) {
        var _this = _super.call(this, data, success) || this;
        _this.data = data;
        _this.success = success;
        return _this;
    }
    return PaymentModuleDescriptionResponse;
}(DataObjectResponse));
export { PaymentModuleDescriptionResponse };
var PaymentModuleDescription = (function () {
    function PaymentModuleDescription(desc) {
        this.desc = desc;
    }
    return PaymentModuleDescription;
}());
export { PaymentModuleDescription };
var PaymentVerifyPinResponse = (function (_super) {
    __extends(PaymentVerifyPinResponse, _super);
    function PaymentVerifyPinResponse(data, success) {
        var _this = _super.call(this, data, success) || this;
        _this.data = data;
        _this.success = success;
        return _this;
    }
    return PaymentVerifyPinResponse;
}(DataObjectResponse));
export { PaymentVerifyPinResponse };
var PaymentVerifyPinResponseData = (function () {
    function PaymentVerifyPinResponseData(verified) {
        this.verified = verified;
    }
    return PaymentVerifyPinResponseData;
}());
export { PaymentVerifyPinResponseData };
var PaymentReadData = (function () {
    function PaymentReadData(applications) {
        this.applications = applications;
    }
    return PaymentReadData;
}());
export { PaymentReadData };
var PaymentApplication = (function () {
    function PaymentApplication(aid, name, priority) {
        this.aid = aid;
        this.name = name;
        this.priority = priority;
    }
    return PaymentApplication;
}());
export { PaymentApplication };
var PaymentReadDataResponse = (function (_super) {
    __extends(PaymentReadDataResponse, _super);
    function PaymentReadDataResponse(data, success) {
        var _this = _super.call(this, data, success) || this;
        _this.data = data;
        _this.success = success;
        return _this;
    }
    return PaymentReadDataResponse;
}(DataObjectResponse));
export { PaymentReadDataResponse };
var PaymentReadApplicationData = (function () {
    function PaymentReadApplicationData(country, countryCode, effectiveDate, expirationDate, language, name, pan) {
        this.country = country;
        this.countryCode = countryCode;
        this.effectiveDate = effectiveDate;
        this.expirationDate = expirationDate;
        this.language = language;
        this.name = name;
        this.pan = pan;
    }
    return PaymentReadApplicationData;
}());
export { PaymentReadApplicationData };
var PaymentReadApplicationDataResponse = (function (_super) {
    __extends(PaymentReadApplicationDataResponse, _super);
    function PaymentReadApplicationDataResponse(data, success) {
        var _this = _super.call(this, data, success) || this;
        _this.data = data;
        _this.success = success;
        return _this;
    }
    return PaymentReadApplicationDataResponse;
}(DataObjectResponse));
export { PaymentReadApplicationDataResponse };
var PaymentSignResponseData = (function () {
    function PaymentSignResponseData(success, data, cardSignature, readerSignature) {
        this.success = success;
        this.data = data;
        this.cardSignature = cardSignature;
        this.readerSignature = readerSignature;
    }
    return PaymentSignResponseData;
}());
export { PaymentSignResponseData };
var PaymentSignResponse = (function () {
    function PaymentSignResponse(data, success) {
        this.data = data;
        this.success = success;
    }
    return PaymentSignResponse;
}());
export { PaymentSignResponse };
//# sourceMappingURL=PaymentGenericModel.js.map