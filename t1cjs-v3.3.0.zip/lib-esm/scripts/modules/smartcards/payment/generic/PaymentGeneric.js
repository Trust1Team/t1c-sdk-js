import { Pinutil } from "../../../../../index";
import { RequestHandler } from "../../../../util/RequestHandler";
var PaymentGeneric = (function () {
    function PaymentGeneric(baseUrl, containerUrl, connection, reader_id) {
        this.baseUrl = baseUrl;
        this.containerUrl = containerUrl;
        this.connection = connection;
        this.reader_id = reader_id;
    }
    PaymentGeneric.prototype.allCerts = function (module, aid, filters, callback) {
        var reqOptions = RequestHandler.determineOptionsWithFilter(filters);
        return this.connection.get(this.baseUrl, this.paymentApp(module, PaymentGeneric.ALL_CERTIFICATES, aid, true), reqOptions.params, callback);
    };
    PaymentGeneric.prototype.iccPublicCertificate = function (module, aid, callback) {
        return this.connection.get(this.baseUrl, this.paymentApp(module, PaymentGeneric.CERT_ICC, aid, true), undefined, undefined, callback);
    };
    PaymentGeneric.prototype.issuerPublicCertificate = function (module, aid, callback) {
        return this.connection.get(this.baseUrl, this.paymentApp(module, PaymentGeneric.CERT_ISSUER, aid, true), undefined, undefined, callback);
    };
    PaymentGeneric.prototype.readApplicationData = function (module, callback) {
        return this.connection.get(this.baseUrl, this.paymentApp(module, PaymentGeneric.READ_APPLICATION_DATA, undefined, true), undefined, undefined, callback);
    };
    PaymentGeneric.prototype.readData = function (module, callback) {
        return this.connection.get(this.baseUrl, this.paymentApp(module, PaymentGeneric.READ_DATA, undefined, true), undefined, undefined, callback);
    };
    PaymentGeneric.prototype.verifyPin = function (module, body, callback) {
        body.pin = Pinutil.encryptPin(body.pin);
        return this.connection.post(this.baseUrl, this.paymentApp(module, PaymentGeneric.VERIFY_PIN, undefined, true), body, undefined, undefined, callback);
    };
    PaymentGeneric.prototype.resetBulkPin = function (module, callback) {
        return this.connection.post(this.baseUrl, this.paymentApp(module, PaymentGeneric.RESET_BULK_PIN, undefined, false), null, undefined, undefined, callback);
    };
    PaymentGeneric.prototype.sign = function (module, body, bulk, callback) {
        return this.connection.post(this.baseUrl, this.paymentApp(module, PaymentGeneric.SIGN, undefined, true), body, this.getBulkSignQueryParams(bulk), undefined, callback);
    };
    PaymentGeneric.prototype.getBulkSignQueryParams = function (bulk) {
        if (bulk) {
            return { bulk: true };
        }
    };
    PaymentGeneric.prototype.paymentApp = function (module, path, aid, includeReaderId) {
        var suffix = this.containerUrl;
        suffix += module;
        suffix += PaymentGeneric.PATH_PAYMENT_APP;
        if (aid != undefined) {
            suffix += '/' + aid;
        }
        if (this.reader_id && this.reader_id.length && includeReaderId) {
            suffix += PaymentGeneric.PATH_READERS + '/' + this.reader_id;
        }
        if (path && path.length) {
            suffix += path.startsWith('/') ? path : '/' + path;
        }
        return suffix;
    };
    PaymentGeneric.prototype.baseApp = function (module, path) {
        var suffix = this.containerUrl;
        suffix += module;
        if (path && path.length) {
            suffix += path.startsWith('/') ? path : '/' + path;
        }
        return suffix;
    };
    PaymentGeneric.prototype.getModuleDescription = function (module, callback) {
        return this.connection.get(this.baseUrl, this.baseApp(module, PaymentGeneric.PATH_MOD_DESC), undefined, undefined, callback);
    };
    PaymentGeneric.PATH_MOD_DESC = '/desc';
    PaymentGeneric.PATH_READERS = '/readers';
    PaymentGeneric.PATH_PAYMENT_APP = '/apps/payment';
    PaymentGeneric.ALL_CERTIFICATES = '/cert-list';
    PaymentGeneric.CERT_ISSUER = '/issuer-cert';
    PaymentGeneric.CERT_ICC = '/icc-cert';
    PaymentGeneric.READ_DATA = '/data';
    PaymentGeneric.RESET_BULK_PIN = '/reset-bulk-pin';
    PaymentGeneric.READ_APPLICATION_DATA = '/application-data';
    PaymentGeneric.VERIFY_PIN = '/verify-pin';
    PaymentGeneric.SIGN = '/sign';
    return PaymentGeneric;
}());
export { PaymentGeneric };
//# sourceMappingURL=PaymentGeneric.js.map