import { Pinutil } from "../../../../../index";
import { RequestHandler } from "../../../../util/RequestHandler";
var Crelan = (function () {
    function Crelan(baseUrl, containerUrl, connection, reader_id) {
        this.baseUrl = baseUrl;
        this.containerUrl = containerUrl;
        this.connection = connection;
        this.reader_id = reader_id;
    }
    Crelan.prototype.allCerts = function (aid, filters, callback) {
        var reqOptions = RequestHandler.determineOptionsWithFilter(filters);
        return this.connection.get(this.baseUrl, this.paymentApp(Crelan.ALL_CERTIFICATES, aid, true), reqOptions.params, callback);
    };
    Crelan.prototype.iccPublicCertificate = function (aid, callback) {
        return this.connection.get(this.baseUrl, this.paymentApp(Crelan.CERT_ICC, aid, true), undefined, undefined, callback);
    };
    Crelan.prototype.issuerPublicCertificate = function (aid, callback) {
        return this.connection.get(this.baseUrl, this.paymentApp(Crelan.CERT_ISSUER, aid, true), undefined, undefined, callback);
    };
    Crelan.prototype.readApplicationData = function (callback) {
        return this.connection.get(this.baseUrl, this.paymentApp(Crelan.READ_APPLICATION_DATA, undefined, true), undefined, undefined, callback);
    };
    Crelan.prototype.readData = function (callback) {
        return this.connection.get(this.baseUrl, this.paymentApp(Crelan.READ_DATA, undefined, true), undefined, undefined, callback);
    };
    Crelan.prototype.verifyPin = function (body, callback) {
        body.pin = Pinutil.encryptPin(body.pin);
        return this.connection.post(this.baseUrl, this.paymentApp(Crelan.VERIFY_PIN, undefined, true), body, undefined, undefined, callback);
    };
    Crelan.prototype.sign = function (body, bulk, callback) {
        return this.connection.post(this.baseUrl, this.paymentApp(Crelan.SIGN, undefined, true), body, this.getBulkSignQueryParams(bulk), undefined, callback);
    };
    Crelan.prototype.resetBulkPin = function (callback) {
        return this.connection.post(this.baseUrl, this.paymentApp(Crelan.RESET_BULK_PIN, undefined, false), null, undefined, undefined, callback);
    };
    Crelan.prototype.getBulkSignQueryParams = function (bulk) {
        if (bulk) {
            return { bulk: true };
        }
    };
    Crelan.prototype.paymentApp = function (path, aid, includeReaderId) {
        var suffix = this.containerUrl;
        suffix += Crelan.PATH_PAYMENT_APP;
        if (aid != undefined) {
            suffix += '/' + aid;
        }
        if (this.reader_id && this.reader_id.length && includeReaderId) {
            suffix += Crelan.PATH_READERS + '/' + this.reader_id;
        }
        if (path && path.length) {
            suffix += path.startsWith('/') ? path : '/' + path;
        }
        return suffix;
    };
    Crelan.PATH_PAYMENT_APP = '/apps/payment';
    Crelan.PATH_READERS = '/readers';
    Crelan.ALL_CERTIFICATES = '/cert-list';
    Crelan.CERT_ISSUER = '/issuer-cert';
    Crelan.CERT_ICC = '/icc-cert';
    Crelan.READ_DATA = '/data';
    Crelan.READ_APPLICATION_DATA = '/application-data';
    Crelan.VERIFY_PIN = '/verify-pin';
    Crelan.SIGN = '/sign';
    Crelan.RESET_BULK_PIN = '/reset-bulk-pin';
    return Crelan;
}());
export { Crelan };
//# sourceMappingURL=Crelan.js.map