import { Pkcs11Config } from "./Pkcs11GenericModel";
var Pkcs11Generic = (function () {
    function Pkcs11Generic(baseUrl, containerUrl, connection) {
        this.baseUrl = baseUrl;
        this.containerUrl = containerUrl;
        this.connection = connection;
    }
    Pkcs11Generic.prototype.os = function (callback) {
        return this.connection.get(this.baseUrl, this.genericPkcs11Path(Pkcs11Generic.OS), undefined, undefined, callback);
    };
    Pkcs11Generic.prototype.slotInfo = function (slotId, callback) {
        return this.connection.get(this.baseUrl, this.genericPkcs11Path(Pkcs11Generic.SLOT_INFO, slotId), undefined, undefined, callback);
    };
    Pkcs11Generic.prototype.getAliases = function (slotId, data, callback) {
        return this.connection.post(this.baseUrl, this.genericPkcs11Path(Pkcs11Generic.ALIASES, slotId), data, undefined, undefined, callback);
    };
    Pkcs11Generic.prototype.getPrivateKeyType = function (slotId, alias, data, callback) {
        return this.connection.post(this.baseUrl, this.genericPkcs11Path(Pkcs11Generic.PRIVATE_KEY_TYPE, slotId, alias), data, undefined, undefined, callback);
    };
    Pkcs11Generic.prototype.verifyPin = function (slotId, alias, data, callback) {
        return this.connection.post(this.baseUrl, this.genericPkcs11Path(Pkcs11Generic.VERIFY_PIN, slotId, alias), data, undefined, undefined, callback);
    };
    Pkcs11Generic.prototype.getCertificates = function (slotId, alias, data, callback) {
        return this.connection.post(this.baseUrl, this.genericPkcs11Path(Pkcs11Generic.ALL_CERTIFICATES, slotId, alias), data, undefined, undefined, callback);
    };
    Pkcs11Generic.prototype.info = function (callback) {
        return this.connection.get(this.baseUrl, this.genericPkcs11Path(Pkcs11Generic.INFO), undefined, undefined, callback);
    };
    Pkcs11Generic.prototype.sign = function (slotId, alias, data, callback) {
        return this.connection.post(this.baseUrl, this.genericPkcs11Path(Pkcs11Generic.SIGN, slotId, alias), data, undefined, undefined, callback);
    };
    Pkcs11Generic.prototype.slots = function (callback) {
        return this.connection.get(this.baseUrl, this.genericPkcs11Path(Pkcs11Generic.SLOTS), undefined, undefined, callback);
    };
    Pkcs11Generic.prototype.slotsWithTokenPresent = function (callback) {
        return this.connection.get(this.baseUrl, this.genericPkcs11Path(Pkcs11Generic.SLOTS), {
            "tokenPresent": true
        }, undefined, callback);
    };
    Pkcs11Generic.prototype.token = function (slotId, callback) {
        return this.connection.get(this.baseUrl, this.genericPkcs11Path(Pkcs11Generic.TOKEN_INFO, slotId), undefined, undefined, callback);
    };
    Pkcs11Generic.prototype.clearConfig = function (callback) {
        return this.connection.get(this.baseUrl, this.genericPkcs11Path(Pkcs11Generic.CLEAR_CONFIG), undefined, undefined, callback);
    };
    Pkcs11Generic.prototype.getConfig = function (callback) {
        return this.connection.get(this.baseUrl, this.genericPkcs11Path(Pkcs11Generic.GET_CONFIG), undefined, undefined, callback);
    };
    Pkcs11Generic.prototype.uploadConfig = function (config, callback) {
        return this.connection.put(this.baseUrl, this.genericPkcs11Path(Pkcs11Generic.UPLOAD_CONFIG), new Pkcs11Config(config), undefined, undefined, callback);
    };
    Pkcs11Generic.prototype.genericPkcs11Path = function (path, slotNumber, alias) {
        var suffix = this.containerUrl;
        if (slotNumber != null || slotNumber != undefined) {
            suffix += Pkcs11Generic.PATH_SLOT_ID + slotNumber.toString();
        }
        if (alias) {
            suffix += Pkcs11Generic.PATH_SLOT_ALIAS + alias;
        }
        if (path && path.length) {
            suffix += path.startsWith('/') ? path : '/' + path;
        }
        return suffix;
    };
    Pkcs11Generic.PATH_SLOT_ID = '/slots/';
    Pkcs11Generic.PATH_SLOT_ALIAS = '/aliases/';
    Pkcs11Generic.ALL_CERTIFICATES = '/certificates';
    Pkcs11Generic.OS = '/os';
    Pkcs11Generic.INFO = '/info';
    Pkcs11Generic.SIGN = '/sign';
    Pkcs11Generic.VERIFY_PIN = '/verify-pin';
    Pkcs11Generic.SLOTS = '/slots';
    Pkcs11Generic.TOKEN_INFO = '/token';
    Pkcs11Generic.SLOT_INFO = '';
    Pkcs11Generic.ALIASES = '/aliases';
    Pkcs11Generic.PRIVATE_KEY_TYPE = '/type';
    Pkcs11Generic.UPLOAD_CONFIG = '/config';
    Pkcs11Generic.GET_CONFIG = '/config';
    Pkcs11Generic.CLEAR_CONFIG = '/config/clear';
    return Pkcs11Generic;
}());
export { Pkcs11Generic };
//# sourceMappingURL=Pkcs11Generic.js.map