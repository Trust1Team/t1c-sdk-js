var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
import { DataObjectResponse } from '../../../core/service/CoreModel';
var Pkcs11ObjectInfoResponse = (function (_super) {
    __extends(Pkcs11ObjectInfoResponse, _super);
    function Pkcs11ObjectInfoResponse(data, success) {
        var _this = _super.call(this, data, success) || this;
        _this.data = data;
        _this.success = success;
        return _this;
    }
    return Pkcs11ObjectInfoResponse;
}(DataObjectResponse));
export { Pkcs11ObjectInfoResponse };
var Pkcs11ObjectSign = (function () {
    function Pkcs11ObjectSign(data) {
        this.data = data;
    }
    return Pkcs11ObjectSign;
}());
export { Pkcs11ObjectSign };
var Pkcs11ObjectSignResponse = (function () {
    function Pkcs11ObjectSignResponse(data, success) {
        this.data = data;
        this.success = success;
    }
    return Pkcs11ObjectSignResponse;
}());
export { Pkcs11ObjectSignResponse };
var Pkcs11ObjectSlots = (function () {
    function Pkcs11ObjectSlots(slots) {
        this.slots = slots;
    }
    return Pkcs11ObjectSlots;
}());
export { Pkcs11ObjectSlots };
var Pkcs11ObjectSlotsResponse = (function () {
    function Pkcs11ObjectSlotsResponse(data, success) {
        this.data = data;
        this.success = success;
    }
    return Pkcs11ObjectSlotsResponse;
}());
export { Pkcs11ObjectSlotsResponse };
var Pkcs11ObjectCertificates = (function () {
    function Pkcs11ObjectCertificates(certificates) {
        this.certificates = certificates;
    }
    return Pkcs11ObjectCertificates;
}());
export { Pkcs11ObjectCertificates };
var Pkcs11ObjectCertificate = (function () {
    function Pkcs11ObjectCertificate(id, certificate, parsed) {
        this.id = id;
        this.certificate = certificate;
        this.parsed = parsed;
    }
    return Pkcs11ObjectCertificate;
}());
export { Pkcs11ObjectCertificate };
var Pkcs11ObjectCertificatesResponse = (function () {
    function Pkcs11ObjectCertificatesResponse(data, success) {
        this.data = data;
        this.success = success;
    }
    return Pkcs11ObjectCertificatesResponse;
}());
export { Pkcs11ObjectCertificatesResponse };
var Pkcs11SignData = (function () {
    function Pkcs11SignData(slotId, certificateId, algorithm, data, pin, osDialog) {
        this.slotId = slotId;
        this.certificateId = certificateId;
        this.algorithm = algorithm;
        this.data = data;
        this.pin = pin;
        this.osDialog = osDialog;
    }
    return Pkcs11SignData;
}());
export { Pkcs11SignData };
var Pkcs11ObjectTokenResponse = (function () {
    function Pkcs11ObjectTokenResponse(data, success) {
        this.data = data;
        this.success = success;
    }
    return Pkcs11ObjectTokenResponse;
}());
export { Pkcs11ObjectTokenResponse };
var Pkcs11SetConfigResponse = (function () {
    function Pkcs11SetConfigResponse(data, success) {
        this.data = data;
        this.success = success;
    }
    return Pkcs11SetConfigResponse;
}());
export { Pkcs11SetConfigResponse };
//# sourceMappingURL=Pkcs11Model.js.map