import { T1CLibException } from '../../../core/exceptions/CoreExceptions';
import { LocalConnection } from '../../../core/client/Connection';
import { AbstractPkcs11, Pkcs11ObjectCertificatesResponse, Pkcs11ObjectSignResponse, Pkcs11ObjectSlotsResponse, Pkcs11ObjectTokenResponse, Pkcs11SignData } from './Pkcs11Model';
export declare class PKCS11 implements AbstractPkcs11 {
    protected baseUrl: string;
    protected containerUrl: string;
    protected connection: LocalConnection;
    protected configPath: string;
    static PATH_SLOT_ID: string;
    static ALL_CERTIFICATES: string;
    static CONFIG: string;
    static INFO: string;
    static SIGN: string;
    static SLOTS: string;
    static TOKEN: string;
    private modulePath;
    constructor(baseUrl: string, containerUrl: string, connection: LocalConnection, configPath: string);
    certificates(slotId: string, parseCerts?: boolean, callback?: (error: T1CLibException, data: Pkcs11ObjectCertificatesResponse) => void): Promise<Pkcs11ObjectCertificatesResponse>;
    signData(signData: Pkcs11SignData, callback?: (error: T1CLibException, data: Pkcs11ObjectSignResponse) => void): Promise<Pkcs11ObjectSignResponse>;
    slots(callback?: (error: T1CLibException, data: Pkcs11ObjectSlotsResponse) => void): Promise<Pkcs11ObjectSlotsResponse>;
    slotsWithTokenPresent(callback?: (error: T1CLibException, data: Pkcs11ObjectSlotsResponse) => void): Promise<Pkcs11ObjectSlotsResponse>;
    token(slotId: string, callback?: (error: T1CLibException, data: Pkcs11ObjectTokenResponse) => void): Promise<Pkcs11ObjectTokenResponse>;
    private setLibrary;
    protected pkcs11Path(path?: string, slotNumber?: string): string;
}
