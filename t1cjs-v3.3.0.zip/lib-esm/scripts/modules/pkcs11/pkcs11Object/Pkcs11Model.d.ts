/// <reference types="pkijs" />
import { T1CLibException } from '../../../core/exceptions/CoreExceptions';
import { DataObjectResponse } from '../../../core/service/CoreModel';
import { Pkcs11Info, Pkcs11Slot, Pkcs11TokenInfo } from "../../../..";
import Certificate from 'pkijs/src/Certificate';
export interface AbstractPkcs11 {
    certificates(slotId: string, parseCerts?: boolean, callback?: (error: T1CLibException, data: Pkcs11ObjectCertificatesResponse) => void): Promise<Pkcs11ObjectCertificatesResponse>;
    signData(data: Pkcs11SignData, callback?: (error: T1CLibException, data: Pkcs11ObjectSignResponse) => void): Promise<Pkcs11ObjectSignResponse>;
    slots(callback?: (error: T1CLibException, data: Pkcs11ObjectSlotsResponse) => void): Promise<Pkcs11ObjectSlotsResponse>;
    slotsWithTokenPresent(callback?: (error: T1CLibException, data: Pkcs11ObjectSlotsResponse) => void): Promise<Pkcs11ObjectSlotsResponse>;
    token(slotId: string, callback?: (error: T1CLibException, data: Pkcs11ObjectTokenResponse) => void): Promise<Pkcs11ObjectTokenResponse>;
}
export declare class Pkcs11ObjectInfoResponse extends DataObjectResponse {
    data: Pkcs11Info;
    success: boolean;
    constructor(data: Pkcs11Info, success: boolean);
}
export declare class Pkcs11ObjectSign {
    data: string;
    constructor(data: string);
}
export declare class Pkcs11ObjectSignResponse {
    data: Pkcs11ObjectSign;
    success: boolean;
    constructor(data: Pkcs11ObjectSign, success: boolean);
}
export declare class Pkcs11ObjectSlots {
    slots: Pkcs11Slot[];
    constructor(slots: Pkcs11Slot[]);
}
export declare class Pkcs11ObjectSlotsResponse {
    data: Pkcs11ObjectSlots;
    success: boolean;
    constructor(data: Pkcs11ObjectSlots, success: boolean);
}
export declare class Pkcs11ObjectCertificates {
    certificates: Pkcs11ObjectCertificate[];
    constructor(certificates: Pkcs11ObjectCertificate[]);
}
export declare class Pkcs11ObjectCertificate {
    id: string;
    certificate: string;
    parsed?: Certificate | undefined;
    constructor(id: string, certificate: string, parsed?: Certificate | undefined);
}
export declare class Pkcs11ObjectCertificatesResponse {
    data: Pkcs11ObjectCertificates;
    success: boolean;
    constructor(data: Pkcs11ObjectCertificates, success: boolean);
}
export declare class Pkcs11SignData {
    slotId: string;
    certificateId: string;
    algorithm: string;
    data: string;
    pin?: string | undefined;
    osDialog?: boolean | undefined;
    constructor(slotId: string, certificateId: string, algorithm: string, data: string, pin?: string | undefined, osDialog?: boolean | undefined);
}
export declare class Pkcs11ObjectTokenResponse {
    data: Pkcs11TokenInfo;
    success: boolean;
    constructor(data: Pkcs11TokenInfo, success: boolean);
}
export declare class Pkcs11SetConfigResponse {
    data: string;
    success: boolean;
    constructor(data: string, success: boolean);
}
