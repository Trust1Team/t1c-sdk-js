export declare class Pinutil {
    private static pubKey;
    static getPubKey(): string;
    static setPubKey(key: string): void;
    static encryptPin(pin: string | undefined): string | undefined;
}
