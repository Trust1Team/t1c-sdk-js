import { Options } from "../modules/smartcards/Card";
export declare class RequestOptions {
    parseCerts?: boolean | undefined;
    params?: {
        [key: string]: string;
    } | undefined;
    callback?: (() => void) | undefined;
    constructor(parseCerts?: boolean | undefined, params?: {
        [key: string]: string;
    } | undefined, callback?: (() => void) | undefined);
}
export declare class RequestHandler {
    static determineOptions(firstParam: any, secondParam: any): RequestOptions;
    static determineOptionsWithFilter(firstParam: string[] | Options): RequestOptions;
}
