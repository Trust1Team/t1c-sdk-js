export declare class ObjectUtil {
    static removeNullAndUndefinedFields(obj: any): any;
}
