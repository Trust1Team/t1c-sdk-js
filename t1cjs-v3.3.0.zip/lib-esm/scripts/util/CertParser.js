import * as asn1js from 'asn1js';
import Certificate from 'pkijs/src/Certificate';
import { TokenCertificateResponse, TokenCertificate, TokenAllCerts, TokenAllCertsResponse, PaymentAllCertsResponse, PaymentCertificateResponse, PaymentCertificate, PaymentAllCerts } from '../core/service/CoreModel';
import { ResponseHandler } from './ResponseHandler';
var CertParser = (function () {
    function CertParser() {
    }
    CertParser.processTokenAllCertificates = function (response, parseCerts, callback) {
        var updatedCerts = new TokenAllCerts();
        if (response.data.authenticationCertificate) {
            updatedCerts = new TokenAllCerts(this.processTokenCert(response.data.authenticationCertificate, parseCerts));
        }
        if (response.data.intermediateCertificates) {
            updatedCerts = new TokenAllCerts(updatedCerts.authenticationCertificate, this.processTokenCert(response.data.intermediateCertificates, parseCerts));
        }
        if (response.data.nonRepudiationCertificate) {
            updatedCerts = new TokenAllCerts(updatedCerts.authenticationCertificate, updatedCerts.intermediateCertificates, this.processTokenCert(response.data.nonRepudiationCertificate, parseCerts));
        }
        if (response.data.rootCertificate) {
            updatedCerts = new TokenAllCerts(updatedCerts.authenticationCertificate, updatedCerts.intermediateCertificates, updatedCerts.nonRepudiationCertificate, this.processTokenCert(response.data.rootCertificate, parseCerts));
        }
        if (response.data.encryptionCertificate) {
            updatedCerts = new TokenAllCerts(updatedCerts.authenticationCertificate, updatedCerts.intermediateCertificates, updatedCerts.nonRepudiationCertificate, updatedCerts.rootCertificate, this.processTokenCert(response.data.encryptionCertificate, parseCerts));
        }
        if (response.data.issuerCertificate) {
            updatedCerts = new TokenAllCerts(updatedCerts.authenticationCertificate, updatedCerts.intermediateCertificates, updatedCerts.nonRepudiationCertificate, updatedCerts.rootCertificate, updatedCerts.encryptionCertificate, this.processTokenCert(response.data.issuerCertificate, parseCerts));
        }
        return ResponseHandler.response(new TokenAllCertsResponse(updatedCerts, response.success), callback);
    };
    CertParser.processTokenCertificate = function (response, parseCerts, callback) {
        return ResponseHandler.response(new TokenCertificateResponse(this.processTokenCert(response.data, parseCerts), response.success), callback);
    };
    CertParser.processTokenCert = function (certificate, parseCert) {
        if (parseCert && parseCert === true) {
            var parsedCertificates_1 = undefined;
            var parsedCertificate = undefined;
            if (certificate.certificates) {
                parsedCertificates_1 = new Array();
                certificate.certificates.forEach(function (_cert) {
                    parsedCertificates_1.push(CertParser.processCert(_cert));
                });
            }
            if (certificate.certificate) {
                parsedCertificate = CertParser.processCert(certificate.certificate);
            }
            return new TokenCertificate(certificate.certificate, certificate.certificates, certificate.certificateType, certificate.id, parsedCertificate, parsedCertificates_1);
        }
        else {
            return certificate;
        }
    };
    CertParser.processPaymentAllCertificates = function (response, parseCerts, callback) {
        var updatedCerts = new PaymentAllCerts();
        if (response.data.issuerPublicCertificate) {
            updatedCerts = new PaymentAllCerts(this.processPaymentCert(response.data.issuerPublicCertificate, parseCerts));
        }
        if (response.data.iccPublicCertificate) {
            updatedCerts = new PaymentAllCerts(updatedCerts.issuerPublicCertificate, this.processPaymentCert(response.data.iccPublicCertificate, parseCerts));
        }
        return ResponseHandler.response(new PaymentAllCertsResponse(updatedCerts, response.success), callback);
    };
    CertParser.processPaymentCertificate = function (response, parseCerts, callback) {
        return ResponseHandler.response(new PaymentCertificateResponse(this.processPaymentCert(response.data, parseCerts), response.success), callback);
    };
    CertParser.processPaymentCert = function (certificate, parseCert) {
        if (parseCert && parseCert === true) {
            var parsedCertificate = undefined;
            if (certificate.certificate) {
                parsedCertificate = CertParser.processCert(certificate.certificate);
            }
            return new PaymentCertificate(certificate.certificate, certificate.exponent, certificate.remainder, parsedCertificate);
        }
        else {
            return certificate;
        }
    };
    CertParser.processCert = function (certificate) {
        var rawCert = atob(certificate);
        var buffer = CertParser.str2ab(rawCert);
        var asn1 = asn1js.fromBER(buffer);
        return new Certificate({ schema: asn1.result });
    };
    CertParser.str2ab = function (str) {
        var buf = new ArrayBuffer(str.length);
        var bufView = new Uint8Array(buf);
        for (var i = 0, strLen = str.length; i < strLen; i++) {
            bufView[i] = str.charCodeAt(i);
        }
        return buf;
    };
    return CertParser;
}());
export { CertParser };
//# sourceMappingURL=CertParser.js.map