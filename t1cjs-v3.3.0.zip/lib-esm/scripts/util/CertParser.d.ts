/// <reference types="pkijs" />
import Certificate from 'pkijs/src/Certificate';
import { T1CLibException } from '../..';
import { TokenCertificateResponse, TokenAllCertsResponse, PaymentAllCertsResponse, PaymentCertificateResponse } from '../core/service/CoreModel';
export declare class CertParser {
    static processTokenAllCertificates(response: TokenAllCertsResponse, parseCerts: boolean | undefined, callback?: (error: T1CLibException, data: TokenAllCertsResponse) => void): Promise<TokenAllCertsResponse>;
    static processTokenCertificate(response: TokenCertificateResponse, parseCerts: boolean | undefined, callback?: (error: T1CLibException, data: TokenCertificateResponse) => void): Promise<TokenCertificateResponse>;
    private static processTokenCert;
    static processPaymentAllCertificates(response: PaymentAllCertsResponse, parseCerts: boolean | undefined, callback?: (error: T1CLibException, data: PaymentAllCertsResponse) => void): Promise<PaymentAllCertsResponse>;
    static processPaymentCertificate(response: PaymentCertificateResponse, parseCerts: boolean | undefined, callback?: (error: T1CLibException, data: PaymentCertificateResponse) => void): Promise<PaymentCertificateResponse>;
    private static processPaymentCert;
    static processCert(certificate: string): Certificate;
    private static str2ab;
}
