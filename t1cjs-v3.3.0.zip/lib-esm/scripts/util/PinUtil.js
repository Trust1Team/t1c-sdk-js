import { JSEncrypt } from 'jsencrypt';
var Pinutil = (function () {
    function Pinutil() {
    }
    Pinutil.getPubKey = function () {
        return Pinutil.pubKey;
    };
    Pinutil.setPubKey = function (key) {
        Pinutil.pubKey = key;
    };
    Pinutil.encryptPin = function (pin) {
        if (pin && pin.length) {
            var pubKey = Pinutil.getPubKey();
            if (pubKey != null || pubKey != undefined) {
                var crypt = new JSEncrypt();
                crypt.setKey(pubKey);
                return crypt.encrypt(pin);
            }
            else {
                return pin;
            }
        }
        else {
            return undefined;
        }
    };
    return Pinutil;
}());
export { Pinutil };
//# sourceMappingURL=PinUtil.js.map