export declare class DSException {
    description: string;
    constructor(description: string);
}
