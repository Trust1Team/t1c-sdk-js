var DSException = (function () {
    function DSException(description) {
        this.description = description;
    }
    return DSException;
}());
export { DSException };
//# sourceMappingURL=DSException.js.map