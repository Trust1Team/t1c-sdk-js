var T1CConfigOptions = (function () {
    function T1CConfigOptions(t1cApiUrl, t1cApiPort, t1cProxyUrl, t1cProxyPort, jwt) {
        this.t1cApiUrl = t1cApiUrl;
        this.t1cApiPort = t1cApiPort;
        this.t1cProxyUrl = t1cProxyUrl;
        this.t1cProxyPort = t1cProxyPort;
        this.jwt = jwt;
    }
    return T1CConfigOptions;
}());
export { T1CConfigOptions };
var T1CConfig = (function () {
    function T1CConfig(options) {
        this._t1cApiUrl = 'https://t1c.t1t.io';
        this._t1cApiPort = '51983';
        this._t1cProxyUrl = 'https://t1c.t1t.io';
        this._t1cProxyPort = '51983';
        this._jwt = '';
        if (options) {
            if (options.t1cApiUrl) {
                this._t1cApiUrl = options.t1cApiUrl;
            }
            if (options.t1cApiPort) {
                this._t1cApiPort = options.t1cApiPort;
            }
            if (options.t1cProxyUrl) {
                this._t1cProxyUrl = options.t1cProxyUrl;
            }
            if (options.t1cProxyPort) {
                this._t1cProxyPort = options.t1cProxyPort;
            }
            if (options.jwt) {
                this._jwt = options.jwt;
            }
        }
    }
    Object.defineProperty(T1CConfig.prototype, "t1cApiPort", {
        set: function (value) {
            this._t1cApiPort = value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(T1CConfig.prototype, "t1cApiUrl", {
        get: function () {
            return this._t1cApiUrl + ":" + this._t1cApiPort;
        },
        set: function (value) {
            this._t1cApiUrl = value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(T1CConfig.prototype, "t1cProxyUrl", {
        get: function () {
            return this._t1cProxyUrl + ":" + this._t1cProxyPort;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(T1CConfig.prototype, "t1cJwt", {
        get: function () {
            return this._jwt;
        },
        set: function (value) {
            this._jwt = value;
        },
        enumerable: true,
        configurable: true
    });
    return T1CConfig;
}());
export { T1CConfig };
//# sourceMappingURL=T1CConfig.js.map