import { CoreService } from './service/CoreService';
import { LocalConnection, RemoteJwtConnection, LocalAuthConnection, LocalTestConnection, RemoteApiKeyConnection, LocalAuthAdminConnection, LocalAdminConnection, } from './client/Connection';
import { T1CLibException } from './exceptions/CoreExceptions';
import { Polyfills } from "../util/Polyfills";
import { ModuleFactory } from "../modules/ModuleFactory";
import axios from 'axios';
var urlVersion = "/v3";
var T1CClient = (function () {
    function T1CClient(cfg) {
        var _this = this;
        this.core = function () {
            return _this.coreService;
        };
        this.config = function () {
            return _this.localConfig;
        };
        this.mf = function () {
            return _this.moduleFactory;
        };
        this.generic = function (reader_id, pin, pinType) {
            return _this.moduleFactory.createEidGeneric(reader_id, pin, pinType);
        };
        this.genericMeta = function () {
            return _this.moduleFactory.createEidGenericMeta();
        };
        this.paymentGeneric = function (reader_id) {
            return _this.moduleFactory.createPaymentGeneric(reader_id);
        };
        this.paymentGenericMeta = function () {
            return _this.moduleFactory.createPaymentGenericMeta();
        };
        this.pkcs11Generic = function () {
            return _this.moduleFactory.createPKCS11Generic();
        };
        this.pkcs11 = function (modulePath) {
            return _this.moduleFactory.createPKCS11(modulePath);
        };
        this.fileex = function () {
            return _this.moduleFactory.createFileExchange();
        };
        this.rawprint = function () {
            return _this.moduleFactory.createRawPrint();
        };
        this.beid = function (reader_id) {
            return _this.moduleFactory.createEidBE(reader_id);
        };
        this.remoteloading = function (reader_id) {
            return _this.moduleFactory.createRemoteLoading(reader_id);
        };
        this.emv = function (reader_id) {
            return _this.moduleFactory.createEmv(reader_id);
        };
        this.crelan = function (reader_id) {
            return _this.moduleFactory.createCrelan(reader_id);
        };
        this.aventra = function (reader_id) {
            return _this.moduleFactory.createAventra(reader_id);
        };
        this.oberthur = function (reader_id) {
            return _this.moduleFactory.createOberthur(reader_id);
        };
        this.idemia = function (reader_id) {
            return _this.moduleFactory.createIdemia(reader_id);
        };
        this.luxeid = function (reader_id, pin, pin_type) {
            return _this.moduleFactory.createEidLUX(reader_id, pin, pin_type);
        };
        this.wacom = function () {
            return _this.moduleFactory.createWacom();
        };
        this.diplad = function (reader_id) {
            return _this.moduleFactory.createEidDiplad(reader_id);
        };
        this.localConfig = cfg;
        this.connection = new LocalConnection(this.localConfig);
        this.authConnection = new LocalAuthConnection(this.localConfig);
        this.authAdminConnection = new LocalAuthAdminConnection(this.localConfig);
        this.adminConnection = new LocalAdminConnection(this.localConfig);
        this.remoteConnection = new RemoteJwtConnection(this.localConfig);
        this.remoteApiKeyConnection = new RemoteApiKeyConnection(this.localConfig);
        this.moduleFactory = new ModuleFactory(this.localConfig.t1cApiUrl + urlVersion, this.connection);
        this.localTestConnection = new LocalTestConnection(this.localConfig);
        this.coreService = new CoreService(this.localConfig.t1cApiUrl, this.authConnection);
        this.coreService.version().then(function (info) { return console.log("Running T1C-sdk-js version: " + info); });
    }
    T1CClient.checkPolyfills = function () {
        Polyfills.check();
    };
    T1CClient.initialize = function (cfg, callback) {
        return new Promise(function (resolve, reject) {
            axios.get(cfg.t1cApiUrl + "/info", {
                withCredentials: true, headers: {
                    Authorization: "Bearer " + cfg.t1cJwt,
                    "X-CSRF-Token": "t1c-js"
                }
            }).then(function (res) {
                if (res.status >= 200 && res.status < 300) {
                    if (res.data.t1CInfoAPI.service.deviceType && res.data.t1CInfoAPI.service.deviceType == "PROXY") {
                        console.info("Proxy detected");
                        axios.get(cfg.t1cProxyUrl + "/consent", {
                            withCredentials: true, headers: {
                                Authorization: "Bearer " + cfg.t1cJwt,
                                "X-CSRF-Token": "t1c-js"
                            }
                        }).then(function (res) {
                            cfg.t1cApiPort = res.data.data.apiPort;
                            var client = new T1CClient(cfg);
                            client.t1cInstalled = true;
                            client.coreService.getDevicePublicKey();
                            if (callback && typeof callback === 'function') {
                                callback(null, client);
                            }
                            resolve(client);
                        }, function (err) {
                            var _a, _b;
                            var client = new T1CClient(cfg);
                            reject(new T1CLibException((_a = err.response) === null || _a === void 0 ? void 0 : _a.data.code, (_b = err.response) === null || _b === void 0 ? void 0 : _b.data.description, client));
                        });
                    }
                    else {
                        var client = new T1CClient(cfg);
                        client.coreService.getDevicePublicKey();
                        if (callback && typeof callback === 'function') {
                            callback(null, client);
                        }
                        resolve(client);
                    }
                }
                else {
                    var client = new T1CClient(cfg);
                    client.coreService.getDevicePublicKey();
                    var error = new T1CLibException("112999", res.statusText, client);
                    if (callback && typeof callback === 'function') {
                        callback(error, client);
                    }
                    reject(error);
                }
            }, function (err) {
                var client = new T1CClient(cfg);
                reject(new T1CLibException("112999", "Failed to contact the Trust1Connector API", client));
                console.error(err);
            });
        });
    };
    Object.defineProperty(T1CClient.prototype, "t1cInstalled", {
        set: function (value) {
            this._t1cInstalled = value;
        },
        enumerable: true,
        configurable: true
    });
    return T1CClient;
}());
export { T1CClient };
//# sourceMappingURL=T1CSdk.js.map