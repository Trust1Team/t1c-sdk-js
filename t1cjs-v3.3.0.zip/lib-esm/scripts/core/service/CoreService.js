import { T1CLibException } from '../exceptions/CoreExceptions';
import { T1CClient } from '../../..';
import { ResponseHandler } from "../../util/ResponseHandler";
import { Pinutil } from "../../util/PinUtil";
var CORE_CONSENT = '/consent';
var CORE_INFO = '/info';
var CORE_VERSION = '/v3';
var CORE_READERS = '/readers';
var CORE_CONSENT_IMPLICIT = '/agents/consent';
var CoreService = (function () {
    function CoreService(url, connection) {
        this.url = url;
        this.connection = connection;
    }
    CoreService.prototype.getDevicePublicKey = function (callback) {
        this.connection.get(this.connection.cfg.t1cApiUrl, "/device-key", undefined, undefined).then(function (res) {
            Pinutil.setPubKey(res.data);
        }, function (err) {
        });
    };
    CoreService.cardInsertedFilter = function (inserted) {
        return { cardInserted: inserted };
    };
    CoreService.prototype.getImplicitConsent = function (codeWord, durationInDays, callback) {
        var _this = this;
        return new Promise(function (resolve, reject) {
            var days = 365;
            if (durationInDays) {
                days = durationInDays;
            }
            return _this.connection.get(_this.connection.cfg.t1cProxyUrl, CORE_CONSENT_IMPLICIT + "/" + codeWord, { ttl: days * 24 * 60 * 60 }, undefined).then(function (res) {
                _this.connection.cfg.t1cApiPort = res.data.apiPort;
                var newClient = new T1CClient(_this.connection.cfg);
                if (!callback || typeof callback !== 'function') {
                    callback = function () {
                    };
                }
                callback(undefined, newClient);
                resolve(newClient);
            }, function (err) {
                if (!callback || typeof callback !== 'function') {
                    callback = function () {
                    };
                }
                callback(err, undefined);
                reject(err);
            });
        });
    };
    CoreService.prototype.updateJWT = function (jwt, callback) {
        if (jwt.length <= 0)
            return ResponseHandler.error(new T1CLibException('121', 'JWT may not be empty'), callback);
        this.connection.cfg.t1cJwt = jwt;
        var newClient = new T1CClient(this.connection.cfg);
        return ResponseHandler.response(newClient, callback);
    };
    CoreService.prototype.info = function (callback) {
        return this.connection.get(this.url, CORE_INFO, undefined, undefined, callback);
    };
    CoreService.prototype.reader = function (reader_id, callback) {
        return this.connection.get(this.url, CORE_VERSION + CORE_READERS + '/' + reader_id, undefined, undefined, callback);
    };
    CoreService.prototype.readers = function (callback) {
        return this.connection.get(this.url, CORE_VERSION + CORE_READERS, undefined, undefined, callback);
    };
    CoreService.prototype.readersCardAvailable = function (callback) {
        return this.connection.get(this.url, CORE_VERSION + CORE_READERS, { 'cardInserted': true }, undefined, callback);
    };
    CoreService.prototype.readersCardsUnavailable = function (callback) {
        return this.connection.get(this.url, CORE_VERSION + CORE_READERS, { 'cardInserted': false }, undefined, callback);
    };
    CoreService.prototype.getUrl = function () {
        return this.url;
    };
    CoreService.prototype.version = function () {
        return Promise.resolve(VERSION);
    };
    return CoreService;
}());
export { CoreService };
//# sourceMappingURL=CoreService.js.map