/// <reference types="pkijs" />
import { T1CLibException } from '../exceptions/CoreExceptions';
import { T1CClient } from '../T1CSdk';
import Certificate from 'pkijs/src/Certificate';
export interface AbstractCore {
    getImplicitConsent(codeWord: string, durationInDays?: number, callback?: (error?: T1CLibException, data?: T1CClient) => void): Promise<T1CClient>;
    updateJWT(jwt: string, callback?: (error: T1CLibException, data?: T1CClient) => void): Promise<T1CClient>;
    info(callback?: (error: T1CLibException, data: InfoResponse) => void): void | Promise<InfoResponse>;
    reader(reader_id: string, callback?: (error: T1CLibException, data: SingleReaderResponse) => void): Promise<SingleReaderResponse>;
    readers(callback?: (error: T1CLibException, data: CardReadersResponse) => void): Promise<CardReadersResponse>;
    readersCardAvailable(callback?: (error: T1CLibException, data: CardReadersResponse) => void): Promise<CardReadersResponse>;
    readersCardsUnavailable(callback?: (error: T1CLibException, data: CardReadersResponse) => void): Promise<CardReadersResponse>;
    getUrl(): string;
    getDevicePublicKey(): void;
    version(): Promise<string>;
}
export declare class T1CResponse {
    success: boolean;
    data: any;
    constructor(success: boolean, data: any);
}
export declare class BoolDataResponse extends T1CResponse {
    data: boolean;
    success: boolean;
    constructor(data: boolean, success: boolean);
}
export declare class DataResponse extends T1CResponse {
    data: string;
    success: boolean;
    constructor(data: string, success: boolean);
}
export declare class DataArrayResponse extends T1CResponse {
    data: any[];
    success: boolean;
    constructor(data: any[], success: boolean);
}
export declare class DataObjectResponse extends T1CResponse {
    data: {
        [key: string]: any;
    };
    success: boolean;
    constructor(data: {
        [key: string]: any;
    }, success: boolean);
}
export declare class InfoOS {
    architecture: String;
    os: String;
    version: String;
    constructor(architecture: String, os: String, version: String);
}
export declare class InfoJava {
    runtime: String;
    spec: String;
    java: String;
    constructor(runtime: String, spec: String, java: String);
}
export declare class InfoUser {
    timezone: String;
    country: String;
    language: String;
    home: String;
    tempDir: String;
    constructor(timezone: String, country: String, language: String, home: String, tempDir: String);
}
export declare class InfoService {
    url: String;
    apiPort: String;
    gRpcPort: String;
    constructor(url: String, apiPort: String, gRpcPort: String);
}
export declare class InfoApi {
    service: InfoService;
    activated: boolean;
    citrix: boolean;
    uid: String;
    modules: Array<String>;
    version: String;
    logLevel: String;
    constructor(service: InfoService, activated: boolean, citrix: boolean, uid: String, modules: Array<String>, version: String, logLevel: String);
}
export declare class InfoResponse {
    t1CInfoOS: InfoOS;
    t1CInfoJava: InfoJava;
    t1CInfoUser: InfoUser;
    t1CInfoAPI: InfoApi;
    constructor(t1CInfoOS: InfoOS, t1CInfoJava: InfoJava, t1CInfoUser: InfoUser, t1CInfoAPI: InfoApi);
}
export declare class T1CInfo {
    activated: boolean;
    citrix: boolean;
    managed: boolean;
    arch: string;
    os: string;
    uid: string;
    containers: T1CContainer[];
    version: string;
    constructor(activated: boolean, citrix: boolean, managed: boolean, arch: string, os: string, uid: string, containers: T1CContainer[], version: string);
}
export declare class T1CContainer {
    name: string;
    version: string;
    status: string;
    constructor(name: string, version: string, status: string);
}
export declare class T1CContainerid {
    name: string;
    constructor(name: string);
}
export declare class BrowserInfoResponse extends T1CResponse {
    data: BrowserInfo;
    success: boolean;
    constructor(data: BrowserInfo, success: boolean);
}
export declare class BrowserInfo {
    browser: {
        name: string;
        version: string;
    };
    manufacturer: string;
    os: {
        name: string;
        version: string;
        architecture: string;
    };
    ua: string;
    constructor(browser: {
        name: string;
        version: string;
    }, manufacturer: string, os: {
        name: string;
        version: string;
        architecture: string;
    }, ua: string);
}
export declare class SmartCard {
    atr?: string | undefined;
    description?: string[] | undefined;
    constructor(atr?: string | undefined, description?: string[] | undefined);
}
export declare class CardReader {
    id: string;
    name: string;
    pinpad: boolean;
    card?: SmartCard | undefined;
    constructor(id: string, name: string, pinpad: boolean, card?: SmartCard | undefined);
}
export declare class CardReadersResponse extends T1CResponse {
    data: CardReader[];
    success: boolean;
    constructor(data: CardReader[], success: boolean);
}
export declare class TokenCertificateResponse extends T1CResponse {
    data: TokenCertificate;
    success: boolean;
    constructor(data: TokenCertificate, success: boolean);
}
export declare class TokenCertificate {
    certificate?: string | undefined;
    certificates?: string[] | undefined;
    certificateType?: string | undefined;
    id?: string | undefined;
    parsedCertificate?: Certificate | undefined;
    parsedCertificates?: Certificate[] | undefined;
    constructor(certificate?: string | undefined, certificates?: string[] | undefined, certificateType?: string | undefined, id?: string | undefined, parsedCertificate?: Certificate | undefined, parsedCertificates?: Certificate[] | undefined);
}
export declare class TokenAllCertsResponse extends DataObjectResponse {
    data: TokenAllCerts;
    success: boolean;
    constructor(data: TokenAllCerts, success: boolean);
}
export declare class TokenAllCerts {
    authenticationCertificate?: TokenCertificate | undefined;
    intermediateCertificates?: TokenCertificate | undefined;
    nonRepudiationCertificate?: TokenCertificate | undefined;
    rootCertificate?: TokenCertificate | undefined;
    encryptionCertificate?: TokenCertificate | undefined;
    issuerCertificate?: TokenCertificate | undefined;
    constructor(authenticationCertificate?: TokenCertificate | undefined, intermediateCertificates?: TokenCertificate | undefined, nonRepudiationCertificate?: TokenCertificate | undefined, rootCertificate?: TokenCertificate | undefined, encryptionCertificate?: TokenCertificate | undefined, issuerCertificate?: TokenCertificate | undefined);
}
export declare class PaymentCertificateResponse extends DataObjectResponse {
    data: PaymentCertificate;
    success: boolean;
    constructor(data: PaymentCertificate, success: boolean);
}
export declare class PaymentCertificate {
    certificate?: string | undefined;
    exponent?: string | undefined;
    remainder?: string | undefined;
    parsed?: Certificate | undefined;
    constructor(certificate?: string | undefined, exponent?: string | undefined, remainder?: string | undefined, parsed?: Certificate | undefined);
}
export declare class PaymentAllCertsResponse extends DataObjectResponse {
    data: PaymentAllCerts;
    success: boolean;
    constructor(data: PaymentAllCerts, success: boolean);
}
export declare class PaymentAllCerts {
    issuerPublicCertificate?: PaymentCertificate | undefined;
    iccPublicCertificate?: PaymentCertificate | undefined;
    constructor(issuerPublicCertificate?: PaymentCertificate | undefined, iccPublicCertificate?: PaymentCertificate | undefined);
}
export declare class SingleReaderResponse extends T1CResponse {
    data: CardReader;
    success: boolean;
    constructor(data: CardReader, success: boolean);
}
export declare class CheckT1CVersion {
    outDated: boolean;
    downloadLink?: string | undefined;
    constructor(outDated: boolean, downloadLink?: string | undefined);
}
export declare class CheckT1CVersionResponse extends T1CResponse {
    data: CheckT1CVersion;
    success: boolean;
    constructor(data: CheckT1CVersion, success: boolean);
}
