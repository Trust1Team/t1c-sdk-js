import { LocalAuthConnection } from '../client/Connection';
import { AbstractCore, CardReadersResponse, InfoResponse, SingleReaderResponse } from './CoreModel';
import { T1CLibException } from '../exceptions/CoreExceptions';
import { T1CClient } from '../../..';
export declare class CoreService implements AbstractCore {
    private url;
    private connection;
    constructor(url: string, connection: LocalAuthConnection);
    getDevicePublicKey(callback?: (error?: T1CLibException, data?: string) => void): void;
    private static cardInsertedFilter;
    getImplicitConsent(codeWord: string, durationInDays?: number, callback?: (error?: T1CLibException, data?: T1CClient) => void): Promise<T1CClient>;
    updateJWT(jwt: string, callback?: (error: T1CLibException, data?: T1CClient) => void): Promise<T1CClient>;
    info(callback?: (error: T1CLibException, data: InfoResponse) => void): Promise<InfoResponse>;
    reader(reader_id: string, callback?: (error: T1CLibException, data: SingleReaderResponse) => void): Promise<SingleReaderResponse>;
    readers(callback?: (error: T1CLibException, data: CardReadersResponse) => void): Promise<CardReadersResponse>;
    readersCardAvailable(callback?: (error: T1CLibException, data: CardReadersResponse) => void): Promise<CardReadersResponse>;
    readersCardsUnavailable(callback?: (error: T1CLibException, data: CardReadersResponse) => void): Promise<CardReadersResponse>;
    getUrl(): string;
    version(): Promise<string>;
}
