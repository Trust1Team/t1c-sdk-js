import { CoreService } from './service/CoreService';
import { LocalConnection, RemoteJwtConnection, LocalAuthConnection, LocalTestConnection, RemoteApiKeyConnection, LocalAuthAdminConnection, LocalAdminConnection, } from './client/Connection';
import { T1CLibException } from './exceptions/CoreExceptions';
import { Polyfills } from "../util/Polyfills";
import { ModuleFactory } from "../modules/ModuleFactory";
import axios from 'axios';
import { ConsentUtil } from "../util/ConsentUtil";
var urlVersion = "/v3";
var semver = require('semver');
var T1CClient = (function () {
    function T1CClient(cfg) {
        var _this = this;
        this.core = function () {
            return _this.coreService;
        };
        this.config = function () {
            return _this.localConfig;
        };
        this.mf = function () {
            return _this.moduleFactory;
        };
        this.generic = function (reader_id, pin, pinType) {
            return _this.moduleFactory.createEidGeneric(reader_id, pin, pinType);
        };
        this.paymentGeneric = function (reader_id) {
            return _this.moduleFactory.createPaymentGeneric(reader_id);
        };
        this.fileex = function () {
            return _this.moduleFactory.createFileExchange();
        };
        this.rawprint = function () {
            return _this.moduleFactory.createRawPrint();
        };
        this.beid = function (reader_id) {
            return _this.moduleFactory.createEidBE(reader_id);
        };
        this.remoteloading = function (reader_id) {
            return _this.moduleFactory.createRemoteLoading(reader_id);
        };
        this.emv = function (reader_id) {
            return _this.moduleFactory.createEmv(reader_id);
        };
        this.crelan = function (reader_id) {
            return _this.moduleFactory.createCrelan(reader_id);
        };
        this.aventra = function (reader_id) {
            return _this.moduleFactory.createAventra(reader_id);
        };
        this.oberthur = function (reader_id) {
            return _this.moduleFactory.createOberthur(reader_id);
        };
        this.idemia = function (reader_id) {
            return _this.moduleFactory.createIdemia(reader_id);
        };
        this.luxeid = function (reader_id, pin, pin_type) {
            return _this.moduleFactory.createEidLUX(reader_id, pin, pin_type);
        };
        this.wacom = function () {
            return _this.moduleFactory.createWacom();
        };
        this.diplad = function (reader_id) {
            return _this.moduleFactory.createEidDiplad(reader_id);
        };
        this.certigna = function (reader_id) {
            return _this.moduleFactory.createCertigna(reader_id);
        };
        this.certinomis = function (reader_id) {
            return _this.moduleFactory.createCertinomis(reader_id);
        };
        this.dnie = function (reader_id) {
            return _this.moduleFactory.createDNIe(reader_id);
        };
        this.safenet = function (reader_id) {
            return _this.moduleFactory.createSafenet(reader_id);
        };
        this.eherkenning = function (reader_id) {
            return _this.moduleFactory.createEherkenning(reader_id);
        };
        this.jcop = function (reader_id) {
            return _this.moduleFactory.createJcop(reader_id);
        };
        this.airbus = function (reader_id) {
            return _this.moduleFactory.createAirbus(reader_id);
        };
        this.localConfig = cfg;
        this.connection = new LocalConnection(this.localConfig);
        this.authConnection = new LocalAuthConnection(this.localConfig);
        this.authAdminConnection = new LocalAuthAdminConnection(this.localConfig);
        this.adminConnection = new LocalAdminConnection(this.localConfig);
        this.remoteConnection = new RemoteJwtConnection(this.localConfig);
        this.remoteApiKeyConnection = new RemoteApiKeyConnection(this.localConfig);
        this.moduleFactory = new ModuleFactory(this.localConfig.t1cApiUrl + urlVersion, this.connection);
        this.localTestConnection = new LocalTestConnection(this.localConfig);
        this.coreService = new CoreService(this.localConfig.t1cApiUrl, this.authConnection);
    }
    T1CClient.checkPolyfills = function () {
        Polyfills.check();
    };
    T1CClient.initialize = function (cfg, callback) {
        var _this = this;
        return new Promise(function (resolve, reject) {
            var _client = new T1CClient(cfg);
            _client.core().info().then(function (infoRes) {
                var _a;
                _client.config().version = (_a = infoRes.t1CInfoAPI) === null || _a === void 0 ? void 0 : _a.version;
                if (infoRes.t1CInfoAPI && semver.lt(semver.coerce(infoRes.t1CInfoAPI.version).version, '3.5.0')) {
                    _this._init(resolve, reject, cfg, callback);
                }
                else {
                    _this.init(resolve, reject, cfg, callback);
                }
            }, function (err) {
                console.error(err);
                if (callback && typeof callback === 'function') {
                    callback(new T1CLibException("112999", "Failed to contact the Trust1Connector", _client), _client);
                }
                reject(new T1CLibException("112999", "Failed to contact the Trust1Connector", _client));
            });
        });
    };
    Object.defineProperty(T1CClient.prototype, "t1cInstalled", {
        set: function (value) {
            this._t1cInstalled = value;
        },
        enumerable: true,
        configurable: true
    });
    T1CClient.init = function (resolve, reject, cfg, callback) {
        var _client = new T1CClient(cfg);
        var currentConsent = ConsentUtil.getRawConsent(cfg.applicationDomain + "::" + cfg.t1cApiUrl);
        if (currentConsent != null) {
            _client.core().validateConsent(currentConsent).then(function (validateRes) {
                resolve(validateRes);
            }, function (err) {
                if (!callback || typeof callback !== 'function') {
                    callback = function () { };
                }
                callback(new T1CLibException("814501", err.description ? err.description : "No valid consent", _client), undefined);
                reject(new T1CLibException("814501", err.description ? err.description : "No valid consent", _client));
            });
        }
        else {
            var error = new T1CLibException("814501", "Consent required", _client);
            if (callback && typeof callback === 'function') {
                callback(error, undefined);
            }
            reject(error);
        }
    };
    T1CClient._init = function (resolve, reject, cfg, callback) {
        axios.get(cfg.t1cApiUrl + "/info", {
            withCredentials: true, headers: {
                Authorization: "Bearer " + cfg.t1cJwt,
                "X-CSRF-Token": "t1c-js"
            }
        }).then(function (infoRes) {
            if (infoRes.status >= 200 && infoRes.status < 300) {
                if (infoRes.data.t1CInfoAPI.service.deviceType && infoRes.data.t1CInfoAPI.service.deviceType == "PROXY") {
                    console.info("Proxy detected");
                    axios.get(cfg.t1cApiUrl + "/consent", {
                        withCredentials: true, headers: {
                            Authorization: "Bearer " + cfg.t1cJwt,
                            "X-CSRF-Token": "t1c-js"
                        }
                    }).then(function (res) {
                        cfg.t1cApiPort = res.data.data.apiPort;
                        var client = new T1CClient(cfg);
                        client.t1cInstalled = true;
                        client.coreService.getDevicePublicKey();
                        if (callback && typeof callback === 'function') {
                            callback(undefined, client);
                        }
                        resolve(client);
                    }, function (err) {
                        var _a, _b;
                        var client = new T1CClient(cfg);
                        reject(new T1CLibException((_a = err.response) === null || _a === void 0 ? void 0 : _a.data.code, (_b = err.response) === null || _b === void 0 ? void 0 : _b.data.description, client));
                    });
                }
                else {
                    cfg.version = infoRes.data.t1CInfoAPI.version;
                    var client = new T1CClient(cfg);
                    client.coreService.getDevicePublicKey();
                    if (callback && typeof callback === 'function') {
                        callback(undefined, client);
                    }
                    resolve(client);
                }
            }
            else {
                var client = new T1CClient(cfg);
                client.coreService.getDevicePublicKey();
                var error = new T1CLibException("112999", infoRes.statusText, client);
                if (callback && typeof callback === 'function') {
                    callback(error, client);
                }
                reject(error);
            }
        }, function (err) {
            var client = new T1CClient(cfg);
            reject(new T1CLibException("112999", "Failed to contact the Trust1Connector API", client));
            console.error(err);
        });
    };
    return T1CClient;
}());
export { T1CClient };
//# sourceMappingURL=T1CSdk.js.map