export declare class T1CConfigOptions {
    t1cApiUrl?: string | undefined;
    t1cApiPort?: string | undefined;
    t1cProxyUrl?: string | undefined;
    t1cProxyPort?: string | undefined;
    jwt?: string | undefined;
    applicationDomain?: string | undefined;
    constructor(t1cApiUrl?: string | undefined, t1cApiPort?: string | undefined, t1cProxyUrl?: string | undefined, t1cProxyPort?: string | undefined, jwt?: string | undefined, applicationDomain?: string | undefined);
}
export declare class T1CConfig {
    private _t1cApiUrl;
    private _t1cApiPort;
    private _t1cProxyUrl;
    private _t1cProxyPort;
    private _jwt;
    private _applicationDomain;
    private _version;
    constructor(options: T1CConfigOptions);
    get applicationDomain(): string;
    set applicationDomain(value: string);
    set t1cApiPort(value: string);
    get t1cApiUrl(): string;
    set t1cApiUrl(value: string);
    get t1cProxyUrl(): string;
    get t1cJwt(): string;
    set t1cJwt(value: string);
    get version(): any;
    set version(value: any);
}
