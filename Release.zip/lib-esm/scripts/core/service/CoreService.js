import { T1CLibException } from '../exceptions/CoreExceptions';
import { T1CClient } from '../../..';
import { ResponseHandler } from "../../util/ResponseHandler";
import { Pinutil } from "../../util/PinUtil";
import { ConsentUtil } from "../../util/ConsentUtil";
var semver = require('semver');
var CORE_CONSENT = '/consent';
var CORE_VALIDATE = '/validate';
var CORE_INFO = '/info';
var CORE_VERSION = '/v3';
var CORE_READERS = '/readers';
var CORE_CONSENT_IMPLICIT = '/agents/consent';
var CoreService = (function () {
    function CoreService(url, connection) {
        this.url = url;
        this.connection = connection;
    }
    CoreService.prototype.getDevicePublicKey = function (callback) {
        this.connection.get(this.connection.cfg.t1cApiUrl, "/device-key", undefined, undefined).then(function (res) {
            Pinutil.setPubKey(res.data);
        }, function (err) {
        });
    };
    CoreService.prototype.validateConsent = function (consent, callback) {
        var _this = this;
        return new Promise(function (resolve, reject) {
            return _this.connection.post(_this.connection.cfg.t1cApiUrl, CORE_VERSION + CORE_VALIDATE, {
                data: consent
            }, undefined).then(function (res) {
                ConsentUtil.setConsent(res.data, _this.connection.cfg.applicationDomain + "::" + _this.connection.cfg.t1cApiUrl);
                var parsed_response = ConsentUtil.getConsent(_this.connection.cfg.applicationDomain + "::" + _this.connection.cfg.t1cApiUrl);
                if (parsed_response != null) {
                    _this.connection.cfg.t1cApiPort = parsed_response === null || parsed_response === void 0 ? void 0 : parsed_response.agent.apiPort;
                    var newClient = new T1CClient(_this.connection.cfg);
                    if (!callback || typeof callback !== 'function') {
                        callback = function () { };
                    }
                    callback(undefined, newClient);
                    resolve(newClient);
                }
                else {
                    ConsentUtil.removeConsent(_this.connection.cfg.applicationDomain + "::" + _this.connection.cfg.t1cApiUrl);
                    console.error("Unable to parse consent");
                    if (!callback || typeof callback !== 'function') {
                        callback = function () { };
                    }
                    callback(new T1CLibException("814501", "No valid consent", new T1CClient(_this.connection.cfg)), undefined);
                    reject(new T1CLibException("814501", "No valid consent", new T1CClient(_this.connection.cfg)));
                }
            }, function (err) {
                ConsentUtil.removeConsent(_this.connection.cfg.applicationDomain + "::" + _this.connection.cfg.t1cApiUrl);
                if (!callback || typeof callback !== 'function') {
                    callback = function () { };
                }
                callback(new T1CLibException("814501", err.description ? err.description : "No valid consent", new T1CClient(_this.connection.cfg)), undefined);
                reject(new T1CLibException("814501", err.description ? err.description : "No valid consent", new T1CClient(_this.connection.cfg)));
            });
        });
    };
    CoreService.prototype.getImplicitConsent = function (codeWord, durationInDays, callback) {
        var _this = this;
        return new Promise(function (resolve, reject) {
            var days = 365;
            if (durationInDays) {
                days = durationInDays;
            }
            if (semver.lt(semver.coerce(_this.connection.cfg.version).version, '3.5.0')) {
                return _this._getImplicitConsent(resolve, reject, codeWord, days, callback);
            }
            else {
                return _this.connection.post(_this.connection.cfg.t1cApiUrl, CORE_VERSION + CORE_CONSENT, {
                    codeWord: codeWord,
                    durationInDays: days
                }, undefined).then(function (res) {
                    ConsentUtil.setConsent(res.data, _this.connection.cfg.applicationDomain + "::" + _this.connection.cfg.t1cApiUrl);
                    var parsed_response = ConsentUtil.getConsent(_this.connection.cfg.applicationDomain + "::" + _this.connection.cfg.t1cApiUrl);
                    if (parsed_response != null) {
                        _this.connection.cfg.t1cApiPort = parsed_response.agent.apiPort;
                    }
                    else {
                        if (!callback || typeof callback !== 'function') {
                            callback = function () { };
                        }
                        callback(new T1CLibException("814501", "No valid consent", new T1CClient(_this.connection.cfg)), undefined);
                        reject(new T1CLibException("814501", "No valid consent", new T1CClient(_this.connection.cfg)));
                    }
                    var newClient = new T1CClient(_this.connection.cfg);
                    if (!callback || typeof callback !== 'function') {
                        callback = function () { };
                    }
                    callback(undefined, newClient);
                    resolve(newClient);
                }, function (err) {
                    if (!callback || typeof callback !== 'function') {
                        callback = function () { };
                    }
                    callback(new T1CLibException("814500", err.description ? err.description : "No valid consent", new T1CClient(_this.connection.cfg)), undefined);
                    reject(new T1CLibException("814500", err.description ? err.description : "No valid consent", new T1CClient(_this.connection.cfg)));
                });
            }
        });
    };
    CoreService.prototype._getImplicitConsent = function (resolve, reject, codeWord, durationInDays, callback) {
        var _this = this;
        return this.connection.get(this.connection.cfg.t1cProxyUrl, CORE_CONSENT_IMPLICIT + "/" + codeWord, { ttl: durationInDays * 24 * 60 * 60 }, undefined).then(function (res) {
            _this.connection.cfg.t1cApiPort = res.data.apiPort;
            var newClient = new T1CClient(_this.connection.cfg);
            if (!callback || typeof callback !== 'function') {
                callback = function () { };
            }
            callback(undefined, newClient);
            resolve(newClient);
        }, function (err) {
            if (!callback || typeof callback !== 'function') {
                callback = function () { };
            }
            callback(err, undefined);
            reject(err);
        });
    };
    CoreService.prototype.updateJWT = function (jwt, callback) {
        if (jwt.length <= 0)
            return ResponseHandler.error(new T1CLibException('121', 'JWT may not be empty'), callback);
        this.connection.cfg.t1cJwt = jwt;
        var newClient = new T1CClient(this.connection.cfg);
        return ResponseHandler.response(newClient, callback);
    };
    CoreService.prototype.info = function (callback) {
        return this.connection.get(this.url, CORE_INFO, undefined, undefined, callback);
    };
    CoreService.prototype.reader = function (reader_id, callback) {
        return this.connection.get(this.url, CORE_VERSION + CORE_READERS + '/' + reader_id, undefined, undefined, callback);
    };
    CoreService.prototype.readers = function (callback) {
        return this.connection.get(this.url, CORE_VERSION + CORE_READERS, undefined, undefined, callback);
    };
    CoreService.prototype.readersCardAvailable = function (callback) {
        return this.connection.get(this.url, CORE_VERSION + CORE_READERS, { 'cardInserted': true }, undefined, callback);
    };
    CoreService.prototype.readersCardsUnavailable = function (callback) {
        return this.connection.get(this.url, CORE_VERSION + CORE_READERS, { 'cardInserted': false }, undefined, callback);
    };
    CoreService.prototype.getUrl = function () {
        return this.url;
    };
    CoreService.prototype.version = function () {
        return Promise.resolve(VERSION);
    };
    return CoreService;
}());
export { CoreService };
//# sourceMappingURL=CoreService.js.map