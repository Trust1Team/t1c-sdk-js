var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
import axios from 'axios';
import { T1CLibException } from '../exceptions/CoreExceptions';
import * as store from 'store2';
import { UrlUtil } from '../../util/UrlUtil';
var GenericConnection = (function () {
    function GenericConnection(cfg) {
        this.cfg = cfg;
    }
    GenericConnection.extractAccessToken = function (headers, config) {
        if (headers && headers.access_token) {
            config.t1cJwt = headers.access_token;
        }
    };
    GenericConnection.prototype.get = function (basePath, suffix, queryParams, headers, callback) {
        var securityConfig = this.getSecurityConfig();
        return this.handleRequest(basePath, suffix, 'GET', this.cfg, securityConfig, undefined, queryParams, headers, callback);
    };
    GenericConnection.prototype.post = function (basePath, suffix, body, queryParams, headers, callback) {
        var securityConfig = this.getSecurityConfig();
        return this.handleRequest(basePath, suffix, 'POST', this.cfg, securityConfig, body, queryParams, headers, callback);
    };
    GenericConnection.prototype.postFile = function (basePath, suffix, body, queryParams, headers, callback) {
        var securityConfig = this.getSecurityConfig();
        return this.handleFileRequest(basePath, suffix, 'POST', this.cfg, securityConfig, body, queryParams, headers, callback);
    };
    GenericConnection.prototype.put = function (basePath, suffix, body, queryParams, headers, callback) {
        var securityConfig = this.getSecurityConfig();
        return this.handleRequest(basePath, suffix, 'PUT', this.cfg, securityConfig, body, queryParams, headers, callback);
    };
    GenericConnection.prototype.delete = function (basePath, suffix, queryParams, headers, callback) {
        var securityConfig = this.getSecurityConfig();
        return this.handleRequest(basePath, suffix, 'DELETE', this.cfg, securityConfig, undefined, queryParams, headers, callback);
    };
    GenericConnection.prototype.getRequestHeaders = function (headers) {
        var reqHeaders = headers || {};
        reqHeaders['Accept-Language'] = 'en-US';
        reqHeaders['X-CSRF-Token'] = 't1c-js';
        return reqHeaders;
    };
    GenericConnection.prototype.getSecurityConfig = function () {
        return {
            sendJWT: true
        };
    };
    GenericConnection.prototype.handleRequest = function (basePath, suffix, method, t1cConfig, securityConfig, body, params, headers, callback) {
        if (!callback || typeof callback !== 'function') {
            callback = function () {
            };
        }
        var config = {
            withCredentials: true,
            url: UrlUtil.create(basePath, suffix),
            method: method,
            headers: this.getRequestHeaders(headers),
            responseType: 'json',
        };
        if (body) {
            config.data = body;
        }
        if (params) {
            config.params = params;
        }
        if (securityConfig.sendJWT) {
            config.headers.Authorization = 'Bearer ' + t1cConfig.t1cJwt;
        }
        return new Promise(function (resolve, reject) {
            var securityPromise;
            if (securityConfig.sendJWT) {
                securityPromise = Promise.resolve(t1cConfig.t1cJwt);
            }
            else {
                securityPromise = Promise.resolve('');
            }
            securityPromise.then(function (jwt) {
                if (securityConfig.sendJWT) {
                    config.headers.Authorization = 'Bearer ' + jwt;
                }
                axios
                    .request(config)
                    .then(function (response) {
                    GenericConnection.extractAccessToken(response.headers, t1cConfig);
                    callback(undefined, response.data);
                    return resolve(response.data);
                })
                    .catch(function (error) {
                    var _a, _b, _c, _d;
                    if (!error.code && !error.response) {
                        var thrownError = new T1CLibException("112999", 'Internal error');
                        callback(thrownError, null);
                        return reject(thrownError);
                    }
                    else {
                        callback(new T1CLibException((_a = error.response) === null || _a === void 0 ? void 0 : _a.data.code, (_b = error.response) === null || _b === void 0 ? void 0 : _b.data.description), null);
                        return reject(new T1CLibException((_c = error.response) === null || _c === void 0 ? void 0 : _c.data.code, (_d = error.response) === null || _d === void 0 ? void 0 : _d.data.description));
                    }
                });
            }, function (err) {
                return reject(err);
            });
        });
    };
    GenericConnection.prototype.handleFileRequest = function (basePath, suffix, method, t1cConfig, securityConfig, body, params, headers, callback) {
        if (!callback || typeof callback !== 'function') {
            callback = function () {
            };
        }
        var config = {
            withCredentials: true,
            url: UrlUtil.create(basePath, suffix),
            method: method,
            headers: this.getRequestHeaders(headers),
            responseType: 'blob',
        };
        if (body) {
            config.data = body;
        }
        if (params) {
            config.params = params;
        }
        if (securityConfig.sendJWT) {
            config.headers.Authorization = 'Bearer ' + t1cConfig.t1cJwt;
        }
        return new Promise(function (resolve, reject) {
            var securityPromise;
            if (securityConfig.sendJWT) {
                securityPromise = Promise.resolve(t1cConfig.t1cJwt);
            }
            else {
                securityPromise = Promise.resolve('');
            }
            securityPromise.then(function (jwt) {
                if (securityConfig.sendJWT) {
                    config.headers.Authorization = 'Bearer ' + jwt;
                }
                axios
                    .request(config)
                    .then(function (response) {
                    GenericConnection.extractAccessToken(response.headers, t1cConfig);
                    callback(undefined, response.data);
                    return resolve(response.data);
                })
                    .catch(function (error) {
                    var _a, _b, _c, _d;
                    if (!error.code && !error.response) {
                        var thrownError = new T1CLibException("112999", 'Internal error');
                        callback(thrownError, null);
                        return reject(thrownError);
                    }
                    else {
                        callback(new T1CLibException((_a = error.response) === null || _a === void 0 ? void 0 : _a.data.code, (_b = error.response) === null || _b === void 0 ? void 0 : _b.data.description), null);
                        return reject(new T1CLibException((_c = error.response) === null || _c === void 0 ? void 0 : _c.data.code, (_d = error.response) === null || _d === void 0 ? void 0 : _d.data.description));
                    }
                });
            }, function (err) {
                return reject(err);
            });
        });
    };
    GenericConnection.AUTH_TOKEN_HEADER = 'X-Authentication-Token';
    GenericConnection.BROWSER_AUTH_TOKEN = 't1c-js-browser-id-token';
    GenericConnection.RELAY_STATE_HEADER_PREFIX = 'X-Relay-State-';
    GenericConnection.HEADER_GCL_LANG = 'X-Language-Code';
    return GenericConnection;
}());
export { GenericConnection };
var LocalAdminConnection = (function (_super) {
    __extends(LocalAdminConnection, _super);
    function LocalAdminConnection(cfg) {
        var _this = _super.call(this, cfg) || this;
        _this.cfg = cfg;
        return _this;
    }
    LocalAdminConnection.prototype.getSecurityConfig = function () {
        return {
            sendJWT: true
        };
    };
    return LocalAdminConnection;
}(GenericConnection));
export { LocalAdminConnection };
var LocalAuthAdminConnection = (function (_super) {
    __extends(LocalAuthAdminConnection, _super);
    function LocalAuthAdminConnection(cfg) {
        var _this = _super.call(this, cfg) || this;
        _this.cfg = cfg;
        return _this;
    }
    LocalAuthAdminConnection.prototype.getRequestHeaders = function (headers) {
        var reqHeaders = _super.prototype.getRequestHeaders.call(this, headers);
        reqHeaders.Authorization = 'Bearer ' + this.cfg.t1cJwt;
        return reqHeaders;
    };
    LocalAuthAdminConnection.prototype.getSecurityConfig = function () {
        return {
            sendJWT: true
        };
    };
    LocalAuthAdminConnection.prototype.requestLogFile = function (basePath, suffix, callback) {
        if (!callback || typeof callback !== 'function') {
            callback = function () {
            };
        }
        var headers = this.getRequestHeaders({});
        return new Promise(function (resolve, reject) {
            axios
                .get(UrlUtil.create(basePath, suffix), {
                responseType: 'blob',
                headers: headers,
            })
                .then(function (response) {
                callback(null, response);
                return resolve(response);
            }, function (error) {
                if (error.response) {
                    if (error.response.data) {
                        callback(error.response.data, null);
                        return reject(error.response.data);
                    }
                    else {
                        callback(error.response, null);
                        return reject(error.response);
                    }
                }
                else {
                    callback(error, null);
                    return reject(error);
                }
            });
        });
    };
    return LocalAuthAdminConnection;
}(GenericConnection));
export { LocalAuthAdminConnection };
var LocalAuthConnection = (function (_super) {
    __extends(LocalAuthConnection, _super);
    function LocalAuthConnection(cfg) {
        var _this = _super.call(this, cfg) || this;
        _this.cfg = cfg;
        return _this;
    }
    LocalAuthConnection.prototype.getRequestHeaders = function (headers) {
        var reqHeaders = _super.prototype.getRequestHeaders.call(this, headers);
        reqHeaders.Authorization = 'Bearer ' + this.cfg.t1cJwt;
        return reqHeaders;
    };
    LocalAuthConnection.prototype.getSecurityConfig = function () {
        return {
            sendJWT: true
        };
    };
    LocalAuthConnection.prototype.getSkipCitrix = function (basePath, suffix, queryParams, headers, callback) {
        var securityConfig = this.getSecurityConfig();
        return this.handleRequest(basePath, suffix, 'GET', this.cfg, securityConfig, undefined, queryParams, this.getRequestHeaders(headers), callback);
    };
    LocalAuthConnection.prototype.postSkipCitrix = function (basePath, suffix, queryParams, body, headers, callback) {
        var securityConfig = this.getSecurityConfig();
        return this.handleRequest(basePath, suffix, 'POST', this.cfg, securityConfig, body, queryParams, this.getRequestHeaders(headers), callback);
    };
    LocalAuthConnection.prototype.requestLogFile = function (basePath, suffix, callback) {
        var _this = this;
        if (!callback || typeof callback !== 'function') {
            callback = function () {
            };
        }
        return new Promise(function (resolve, reject) {
            var headers = _this.getRequestHeaders({});
            axios
                .get(UrlUtil.create(basePath, suffix), {
                responseType: 'blob',
                headers: headers,
            })
                .then(function (response) {
                callback(null, response);
                return resolve(response);
            }, function (error) {
                if (error.response) {
                    if (error.response.data) {
                        callback(error.response.data, null);
                        return reject(error.response.data);
                    }
                    else {
                        callback(error.response, null);
                        return reject(error.response);
                    }
                }
                else {
                    callback(error, null);
                    return reject(error);
                }
            });
        });
    };
    return LocalAuthConnection;
}(GenericConnection));
export { LocalAuthConnection };
var LocalConnection = (function (_super) {
    __extends(LocalConnection, _super);
    function LocalConnection(cfg) {
        var _this = _super.call(this, cfg) || this;
        _this.cfg = cfg;
        return _this;
    }
    LocalConnection.prototype.getRequestHeaders = function (headers) {
        var reqHeaders = _super.prototype.getRequestHeaders.call(this, headers);
        return reqHeaders;
    };
    LocalConnection.prototype.getSecurityConfig = function () {
        return {
            sendJWT: true
        };
    };
    LocalConnection.prototype.getSkipCitrix = function (basePath, suffix, queryParams, headers, callback) {
        var securityConfig = this.getSecurityConfig();
        return this.handleRequest(basePath, suffix, 'GET', this.cfg, securityConfig, undefined, queryParams, headers, callback);
    };
    return LocalConnection;
}(GenericConnection));
export { LocalConnection };
var RemoteApiKeyConnection = (function (_super) {
    __extends(RemoteApiKeyConnection, _super);
    function RemoteApiKeyConnection(cfg) {
        var _this = _super.call(this, cfg) || this;
        _this.cfg = cfg;
        return _this;
    }
    RemoteApiKeyConnection.prototype.getSecurityConfig = function () {
        return {
            sendJWT: true
        };
    };
    return RemoteApiKeyConnection;
}(GenericConnection));
export { RemoteApiKeyConnection };
var RemoteJwtConnection = (function (_super) {
    __extends(RemoteJwtConnection, _super);
    function RemoteJwtConnection(cfg) {
        var _this = _super.call(this, cfg) || this;
        _this.cfg = cfg;
        return _this;
    }
    RemoteJwtConnection.prototype.getSecurityConfig = function () {
        return {
            sendJWT: true
        };
    };
    return RemoteJwtConnection;
}(GenericConnection));
export { RemoteJwtConnection };
var LocalTestConnection = (function (_super) {
    __extends(LocalTestConnection, _super);
    function LocalTestConnection() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.config = undefined;
        return _this;
    }
    LocalTestConnection.prototype.get = function (basePath, suffix, queryParams, headers, callback) {
        return this.handleTestRequest(basePath, suffix, 'GET', this.config, undefined, queryParams, headers, callback);
    };
    LocalTestConnection.prototype.post = function (basePath, suffix, body, queryParams, headers, callback) {
        return this.handleTestRequest(basePath, suffix, 'POST', this.config, body, queryParams, headers, callback);
    };
    LocalTestConnection.prototype.put = function (basePath, suffix, body, queryParams, headers, callback) {
        return this.handleTestRequest(basePath, suffix, 'PUT', this.config, body, queryParams, headers, callback);
    };
    LocalTestConnection.prototype.delete = function (basePath, suffix, queryParams, headers, callback) {
        return this.handleTestRequest(basePath, suffix, 'DELETE', this.config, undefined, queryParams, headers, callback);
    };
    LocalTestConnection.prototype.getRequestHeaders = function (headers) {
        var reqHeaders = headers || {};
        reqHeaders['Accept-Language'] = 'en-US';
        reqHeaders['X-Consumer-Username'] = 'testorg.testapp.v1';
        reqHeaders[GenericConnection.AUTH_TOKEN_HEADER] = store.get(GenericConnection.BROWSER_AUTH_TOKEN);
        return reqHeaders;
    };
    LocalTestConnection.prototype.handleTestRequest = function (basePath, suffix, method, gclConfig, body, params, headers, callback) {
        if (!callback || typeof callback !== 'function') {
            callback = function () {
            };
        }
        var config = {
            url: UrlUtil.create(basePath, suffix),
            method: method,
            headers: this.getRequestHeaders(headers),
            responseType: 'json',
        };
        if (body) {
            config.data = body;
        }
        if (params) {
            config.params = params;
        }
        if (gclConfig.t1cJwt) {
            config.headers.Authorization = 'Bearer ' + gclConfig.t1cJwt;
        }
        return new Promise(function (resolve, reject) {
            axios
                .request(config)
                .then(function (response) {
                callback(null, response.data);
                return resolve(response.data);
            })
                .catch(function (error) {
                if (error.response) {
                    callback(error.response, null);
                    return reject(error.response);
                }
                else {
                    callback(error, null);
                    return reject(error);
                }
            });
        });
    };
    return LocalTestConnection;
}(GenericConnection));
export { LocalTestConnection };
//# sourceMappingURL=Connection.js.map