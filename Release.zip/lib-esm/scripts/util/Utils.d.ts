export declare class Util {
    static includes(array: any[], searchElement: any, fromIndex?: number): boolean;
    static isEmpty(value: any): boolean;
}
