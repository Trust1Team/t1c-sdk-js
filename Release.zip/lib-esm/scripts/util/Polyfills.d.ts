export declare class Polyfills {
    static check(): void;
}
