export declare class ConsentUtil {
    private static consentKey;
    static removeConsent(domain: string): void;
    static getRawConsent(domain: string): string | null;
    static getConsent(domain: string): Consent | null;
    static setConsent(consentValue: string, domain: string): void;
}
export declare class Consent {
    agent: ConsentAgent;
    signedHash?: string | undefined;
    constructor(agent: ConsentAgent, signedHash?: string | undefined);
}
export declare class ConsentAgent {
    username: string;
    apiIp: string;
    apiPort: string;
    apiPid: string;
    sandboxIp: number;
    sandboxPort: number;
    sandboxPid: string;
    apiLastUsed: string;
    clientLastUsed: string;
    validityInDays: string;
    connectionState: string;
    constructor(username: string, apiIp: string, apiPort: string, apiPid: string, sandboxIp: number, sandboxPort: number, sandboxPid: string, apiLastUsed: string, clientLastUsed: string, validityInDays: string, connectionState: string);
}
