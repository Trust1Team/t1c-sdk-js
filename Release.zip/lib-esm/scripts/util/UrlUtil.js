export { UrlUtil };
var UrlUtil = (function () {
    function UrlUtil() {
    }
    UrlUtil.create = function (base, suffix) {
        return encodeURI(base + suffix);
    };
    return UrlUtil;
}());
//# sourceMappingURL=UrlUtil.js.map