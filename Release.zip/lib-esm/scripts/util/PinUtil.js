import { JSEncrypt } from 'jsencrypt';
var semver = require('semver');
var Pinutil = (function () {
    function Pinutil() {
    }
    Pinutil.getPubKey = function () {
        return Pinutil.pubKey;
    };
    Pinutil.setPubKey = function (key) {
        Pinutil.pubKey = key;
    };
    Pinutil.encryptPin = function (pin, version) {
        if (pin && pin.length) {
            var pubKey = Pinutil.getPubKey();
            if (pubKey != null || pubKey != undefined) {
                var crypt = new JSEncrypt();
                crypt.setKey(pubKey);
                return crypt.encrypt(pin);
            }
            else {
                if (version != undefined && semver.lt(version, '3.5.0'))
                    return btoa(pin);
                else
                    return pin;
            }
        }
        else {
            return undefined;
        }
    };
    return Pinutil;
}());
export { Pinutil };
//# sourceMappingURL=PinUtil.js.map