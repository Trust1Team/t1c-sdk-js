export { UrlUtil };
declare class UrlUtil {
    constructor();
    static create(base: string, suffix: string): string;
}
