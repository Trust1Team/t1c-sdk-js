var ConsentUtil = (function () {
    function ConsentUtil() {
    }
    ConsentUtil.removeConsent = function (domain) {
        localStorage.removeItem(ConsentUtil.consentKey + domain);
    };
    ConsentUtil.getRawConsent = function (domain) {
        var localConsent = localStorage.getItem(ConsentUtil.consentKey + domain);
        if (localConsent != null) {
            return localConsent;
        }
        else {
            return null;
        }
    };
    ConsentUtil.getConsent = function (domain) {
        var localConsent = localStorage.getItem(ConsentUtil.consentKey + domain);
        if (localConsent != null) {
            try {
                var obj = JSON.parse(atob(localConsent));
                return new Consent(new ConsentAgent(obj.agent.username, obj.agent.apiIp, obj.agent.apiPort, obj.agent.apiPid, obj.agent.sandboxIp, obj.agent.sandboxPort, obj.agent.sandboxPid, obj.agent.apiLastUsed, obj.agent.clientLastUsed, obj.agent.validityInDays, obj.agent.connectionState), obj.signedHash);
            }
            catch (error) {
                console.error(error);
                localStorage.removeItem(ConsentUtil.consentKey + domain);
                return null;
            }
        }
        else {
            console.error("No consent present");
            return null;
        }
    };
    ConsentUtil.setConsent = function (consentValue, domain) {
        localStorage.setItem(ConsentUtil.consentKey + domain, consentValue);
    };
    ConsentUtil.consentKey = "t1c-consent-";
    return ConsentUtil;
}());
export { ConsentUtil };
var Consent = (function () {
    function Consent(agent, signedHash) {
        this.agent = agent;
        this.signedHash = signedHash;
    }
    return Consent;
}());
export { Consent };
var ConsentAgent = (function () {
    function ConsentAgent(username, apiIp, apiPort, apiPid, sandboxIp, sandboxPort, sandboxPid, apiLastUsed, clientLastUsed, validityInDays, connectionState) {
        this.username = username;
        this.apiIp = apiIp;
        this.apiPort = apiPort;
        this.apiPid = apiPid;
        this.sandboxIp = sandboxIp;
        this.sandboxPort = sandboxPort;
        this.sandboxPid = sandboxPid;
        this.apiLastUsed = apiLastUsed;
        this.clientLastUsed = clientLastUsed;
        this.validityInDays = validityInDays;
        this.connectionState = connectionState;
    }
    return ConsentAgent;
}());
export { ConsentAgent };
//# sourceMappingURL=ConsentUtil.js.map