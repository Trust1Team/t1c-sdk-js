export declare class Options {
    filters?: string[] | undefined;
    parseCerts?: boolean | undefined;
    constructor(filters?: string[] | undefined, parseCerts?: boolean | undefined);
}
