export declare class TokenAuthenticateOrSignData {
    algorithm: string;
    data: string;
    pin?: string | undefined;
    pace?: string | undefined;
    id?: string | undefined;
    osDialog?: boolean | undefined;
    txId?: string | undefined;
    language?: string | undefined;
    base64Encoded?: boolean | undefined;
    constructor(algorithm: string, data: string, pin?: string | undefined, pace?: string | undefined, id?: string | undefined, osDialog?: boolean | undefined, txId?: string | undefined, language?: string | undefined, base64Encoded?: boolean | undefined);
}
export declare class TokenVerifyPinData {
    pin?: string | undefined;
    pace?: string | undefined;
    osDialog?: boolean | undefined;
    base64Encoded?: boolean | undefined;
    constructor(pin?: string | undefined, pace?: string | undefined, osDialog?: boolean | undefined, base64Encoded?: boolean | undefined);
}
export declare enum TokenResetPinReferenceType {
    issign = "issign",
    isauthenticate = "isauthenticate",
    isencrypt = "isencrypt"
}
export declare class TokenResetPinData {
    puk: string;
    pin?: string | undefined;
    resetOnly?: boolean | undefined;
    osDialog?: boolean | undefined;
    reference?: TokenResetPinReferenceType | undefined;
    base64Encoded?: boolean | undefined;
    constructor(puk: string, pin?: string | undefined, resetOnly?: boolean | undefined, osDialog?: boolean | undefined, reference?: TokenResetPinReferenceType | undefined, base64Encoded?: boolean | undefined);
}
export declare class TokenChangePinData {
    pin?: string | undefined;
    newPin?: string | undefined;
    osDialog?: boolean | undefined;
    constructor(pin?: string | undefined, newPin?: string | undefined, osDialog?: boolean | undefined);
}
export declare class TokenPinTryCounterData {
    reference: string;
    constructor(reference: string);
}
