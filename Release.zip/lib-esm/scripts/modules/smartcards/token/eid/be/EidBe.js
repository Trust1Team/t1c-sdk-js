import { RequestHandler } from '../../../../../util/RequestHandler';
import { ResponseHandler } from "../../../../../util/ResponseHandler";
import { CertParser } from "../../../../../util/CertParser";
import { Pinutil } from "../../../../../..";
var semver = require('semver');
var EidBe = (function () {
    function EidBe(baseUrl, containerUrl, connection, reader_id) {
        this.baseUrl = baseUrl;
        this.containerUrl = containerUrl;
        this.connection = connection;
        this.reader_id = reader_id;
    }
    EidBe.prototype.allData = function (options, callback) {
        var requestOptions = RequestHandler.determineOptionsWithFilter(options);
        return this.connection.get(this.baseUrl, this.tokenApp(EidBe.ALL_DATA, true), requestOptions.params, callback);
    };
    EidBe.prototype.biometric = function (callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(EidBe.RN_DATA, true), undefined, undefined, callback);
    };
    EidBe.prototype.address = function (callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(EidBe.ADDRESS, true), undefined, undefined, callback);
    };
    EidBe.prototype.tokenData = function (callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(EidBe.TOKEN, true), undefined, undefined, callback);
    };
    EidBe.prototype.picture = function (callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(EidBe.PHOTO, true), undefined, undefined, callback);
    };
    EidBe.prototype.rootCertificate = function (parseCerts, callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(EidBe.CERT_ROOT, true), undefined, undefined, callback);
    };
    EidBe.prototype.intermediateCertificates = function (parseCerts, callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(EidBe.CERT_INTERMEDIATE, true), undefined, undefined, callback).then(function (res) {
            return CertParser.processTokenCertificate(res, parseCerts, callback);
        }).catch(function (error) {
            return ResponseHandler.error(error, callback);
        });
    };
    EidBe.prototype.authenticationCertificate = function (parseCerts, callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(EidBe.CERT_AUTHENTICATION, true), undefined, undefined, callback).then(function (res) {
            return CertParser.processTokenCertificate(res, parseCerts, callback);
        }).catch(function (error) {
            return ResponseHandler.error(error, callback);
        });
    };
    EidBe.prototype.nonRepudiationCertificate = function (parseCerts, callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(EidBe.CERT_NON_REPUDIATION, true), undefined, undefined, callback).then(function (res) {
            return CertParser.processTokenCertificate(res, parseCerts, callback);
        }).catch(function (error) {
            return ResponseHandler.error(error, callback);
        });
    };
    EidBe.prototype.encryptionCertificate = function (parseCerts, callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(EidBe.CERT_ENCRYPTION, true), undefined, undefined, callback).then(function (res) {
            return CertParser.processTokenCertificate(res, parseCerts, callback);
        }).catch(function (error) {
            return ResponseHandler.error(error, callback);
        });
    };
    EidBe.prototype.allAlgoRefs = function (callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(EidBe.SUPPORTED_ALGOS, true), undefined, undefined, callback);
    };
    EidBe.prototype.allCerts = function (parseCerts, options, callback) {
        var reqOptions = RequestHandler.determineOptionsWithFilter(options);
        return this.connection.get(this.baseUrl, this.tokenApp(EidBe.ALL_CERTIFICATES, true), reqOptions.params, callback).then(function (res) {
            return CertParser.processTokenAllCertificates(res, parseCerts, callback);
        }).catch(function (error) {
            return ResponseHandler.error(error, callback);
        });
    };
    EidBe.prototype.verifyPin = function (body, callback) {
        body.pin = Pinutil.encryptPin(body.pin, this.connection.cfg.version);
        body.base64Encoded = true;
        return this.connection.post(this.baseUrl, this.tokenApp(EidBe.VERIFY_PIN, true), body, undefined, undefined, callback);
    };
    EidBe.prototype.authenticate = function (body, callback) {
        body.pin = Pinutil.encryptPin(body.pin, this.connection.cfg.version);
        body.base64Encoded = true;
        return this.connection.post(this.baseUrl, this.tokenApp(EidBe.AUTHENTICATE, true), body, undefined, undefined, callback);
    };
    EidBe.prototype.sign = function (body, bulk, callback) {
        body.pin = Pinutil.encryptPin(body.pin, this.connection.cfg.version);
        body.base64Encoded = true;
        return this.connection.post(this.baseUrl, this.tokenApp(EidBe.SIGN_DATA, true), body, this.getBulkSignQueryParams(bulk), undefined, callback);
    };
    EidBe.prototype.resetBulkPin = function (callback) {
        if (semver.lt(this.connection.cfg.version, '3.5.0')) {
            return this.connection.get(this.baseUrl, this.tokenApp(EidBe.RESET_BULK_PIN, false), undefined, undefined, callback);
        }
        else {
            return this.connection.post(this.baseUrl, this.tokenApp(EidBe.RESET_BULK_PIN), null, undefined, undefined, callback);
        }
    };
    EidBe.prototype.tokenApp = function (path, includeReaderId) {
        var suffix = this.containerUrl;
        suffix += EidBe.PATH_TOKEN_APP;
        if (this.reader_id && this.reader_id.length && includeReaderId) {
            suffix += EidBe.PATH_READERS + '/' + this.reader_id;
        }
        if (path && path.length) {
            suffix += path.startsWith('/') ? path : '/' + path;
        }
        return suffix;
    };
    EidBe.prototype.getBulkSignQueryParams = function (bulk) {
        if (bulk) {
            return { bulk: true };
        }
    };
    EidBe.PATH_TOKEN_APP = '/apps/token';
    EidBe.PATH_READERS = '/readers';
    EidBe.ALL_DATA = '/all-data';
    EidBe.ALL_CERTIFICATES = '/cert-list';
    EidBe.CERT_ROOT = '/root-cert';
    EidBe.CERT_AUTHENTICATION = '/authentication-cert';
    EidBe.CERT_NON_REPUDIATION = '/nonrepudiation-cert';
    EidBe.CERT_ENCRYPTION = '/encryption-cert';
    EidBe.CERT_INTERMEDIATE = '/intermediate-certs';
    EidBe.RN_DATA = '/biometric';
    EidBe.ADDRESS = '/address';
    EidBe.PHOTO = '/picture';
    EidBe.TOKEN = '/info';
    EidBe.VERIFY_PIN = '/verify-pin';
    EidBe.SIGN_DATA = '/sign';
    EidBe.AUTHENTICATE = '/authenticate';
    EidBe.VERIFY_PRIV_KEY_REF = 'non-repudiation';
    EidBe.SUPPORTED_ALGOS = '/supported-algorithms';
    EidBe.RESET_BULK_PIN = "/reset-bulk-pin";
    return EidBe;
}());
export { EidBe };
//# sourceMappingURL=EidBe.js.map