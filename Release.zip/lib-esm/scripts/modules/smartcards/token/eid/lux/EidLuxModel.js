var PinType = (function () {
    function PinType() {
    }
    PinType.PIN = 'Pin';
    PinType.CAN = 'Can';
    return PinType;
}());
export { PinType };
//# sourceMappingURL=EidLuxModel.js.map