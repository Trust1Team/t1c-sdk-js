import { T1CLibException } from '../../../../../core/exceptions/CoreExceptions';
import { BoolDataResponse, TokenCertificateResponse, DataObjectResponse, TokenAllCertsResponse } from '../../../../../core/service/CoreModel';
import { TokenAuthenticateOrSignData } from "../../TokenCard";
import { TokenVerifyPinData } from "../../TokenCard";
import { Options } from "../../../Card";
export interface AbstractEidGeneric {
    getModuleDescription(module: string, callback?: (error: T1CLibException, data: DataObjectResponse) => void): Promise<DataObjectResponse>;
    allData(module: string, filters?: string[] | Options, callback?: (error: T1CLibException, data: TokenAllDataResponse) => void): Promise<TokenAllDataResponse>;
    allCerts(module: string, parseCerts?: boolean, filters?: string[] | Options, callback?: (error: T1CLibException, data: TokenAllCertsResponse) => void): Promise<TokenAllCertsResponse>;
    biometric(module: string, callback?: (error: T1CLibException, data: TokenBiometricDataResponse) => void): Promise<TokenBiometricDataResponse>;
    tokenData(module: string, callback?: (error: T1CLibException, data: TokenDataResponse) => void): Promise<TokenDataResponse>;
    address(module: string, callback?: (error: T1CLibException, data: TokenAddressResponse) => void): Promise<TokenAddressResponse>;
    picture(module: string, callback?: (error: T1CLibException, data: TokenPictureResponse) => void): Promise<TokenPictureResponse>;
    rootCertificate(module: string, parseCerts?: boolean, callback?: (error: T1CLibException, data: TokenCertificateResponse) => void): Promise<TokenCertificateResponse>;
    intermediateCertificates(module: string, parseCerts?: boolean, callback?: (error: T1CLibException, data: TokenCertificateResponse) => void): Promise<TokenCertificateResponse>;
    authenticationCertificate(module: string, parseCerts?: boolean, callback?: (error: T1CLibException, data: TokenCertificateResponse) => void): Promise<TokenCertificateResponse>;
    nonRepudiationCertificate(module: string, parseCerts?: boolean, callback?: (error: T1CLibException, data: TokenCertificateResponse) => void): Promise<TokenCertificateResponse>;
    encryptionCertificate(module: string, parseCerts?: boolean, callback?: (error: T1CLibException, data: TokenCertificateResponse) => void): Promise<TokenCertificateResponse>;
    issuerCertificate(module: string, parseCerts?: boolean, callback?: (error: T1CLibException, data: TokenCertificateResponse) => void): Promise<TokenCertificateResponse>;
    verifyPin(module: string, body: TokenVerifyPinData, callback?: (error: T1CLibException, data: TokenVerifyPinResponse) => void): Promise<TokenVerifyPinResponse>;
    authenticate(module: string, body: TokenAuthenticateOrSignData, callback?: (error: T1CLibException, data: TokenAuthenticateResponse) => void): Promise<TokenAuthenticateResponse>;
    sign(module: string, body: TokenAuthenticateOrSignData, bulk?: boolean, callback?: (error: T1CLibException, data: TokenSignResponse) => void): Promise<TokenSignResponse>;
    allAlgoRefs(module: string, callback?: (error: T1CLibException, data: TokenAlgorithmReferencesResponse) => void): Promise<TokenAlgorithmReferencesResponse>;
    resetBulkPin(module: string, callback?: (error: T1CLibException, data: BoolDataResponse) => void): Promise<BoolDataResponse>;
}
export declare class ModuleDescriptionResponse extends DataObjectResponse {
    data: TokenModuleDescription;
    success: boolean;
    constructor(data: TokenModuleDescription, success: boolean);
}
export declare class TokenAddressResponse extends DataObjectResponse {
    data: TokenAddressData;
    success: boolean;
    constructor(data: TokenAddressData, success: boolean);
}
export declare class TokenPictureResponse extends DataObjectResponse {
    data: TokenPictureData;
    success: boolean;
    constructor(data: TokenPictureData, success: boolean);
}
export declare class TokenVerifyPinResponse extends DataObjectResponse {
    data: TokenVerifyPinResponseData;
    success: boolean;
    constructor(data: TokenVerifyPinResponseData, success: boolean);
}
export declare class TokenVerifyPinResponseData {
    verified: boolean;
    constructor(verified: boolean);
}
export declare class TokenSignResponse extends DataObjectResponse {
    data: TokenSignResponseData;
    success: boolean;
    constructor(data: TokenSignResponseData, success: boolean);
}
export declare class TokenSignResponseData {
    data?: string | undefined;
    constructor(data?: string | undefined);
}
export declare class TokenAuthenticateResponse extends DataObjectResponse {
    data: TokenAuthenticateResponseData;
    success: boolean;
    constructor(data: TokenAuthenticateResponseData, success: boolean);
}
export declare class TokenAuthenticateResponseData {
    data?: string | undefined;
    constructor(data?: string | undefined);
}
export declare class TokenModuleDescription {
    desc: string;
    constructor(desc: string);
}
export declare class TokenAddressData {
    municipality?: string | undefined;
    rawData?: string | undefined;
    signature?: string | undefined;
    streetAndNumber?: string | undefined;
    version?: number | undefined;
    zipcode?: string | undefined;
    constructor(municipality?: string | undefined, rawData?: string | undefined, signature?: string | undefined, streetAndNumber?: string | undefined, version?: number | undefined, zipcode?: string | undefined);
}
export declare class TokenAllDataResponse extends DataObjectResponse {
    data: TokenAllData;
    success: boolean;
    constructor(data: TokenAllData, success: boolean);
}
export declare class TokenAllData {
    picture?: TokenPictureData | undefined;
    biometric?: TokenBiometricData | undefined;
    address?: TokenAddressData | undefined;
    constructor(picture?: TokenPictureData | undefined, biometric?: TokenBiometricData | undefined, address?: TokenAddressData | undefined);
}
export declare class TokenPictureData {
    picture?: string | undefined;
    signature?: string | undefined;
    width?: number | undefined;
    height?: number | undefined;
    constructor(picture?: string | undefined, signature?: string | undefined, width?: number | undefined, height?: number | undefined);
}
export declare class TokenData {
    rawData?: string | undefined;
    version?: string | undefined;
    serialNumber?: string | undefined;
    label?: string | undefined;
    prnGeneration?: string | undefined;
    eidCompliant?: string | undefined;
    graphicalPersoVersion?: string | undefined;
    versionRfu?: string | undefined;
    electricalPersoVersion?: string | undefined;
    electricalPersoInterfaceVersion?: string | undefined;
    changeCounter?: number | undefined;
    activated?: string | undefined;
    constructor(rawData?: string | undefined, version?: string | undefined, serialNumber?: string | undefined, label?: string | undefined, prnGeneration?: string | undefined, eidCompliant?: string | undefined, graphicalPersoVersion?: string | undefined, versionRfu?: string | undefined, electricalPersoVersion?: string | undefined, electricalPersoInterfaceVersion?: string | undefined, changeCounter?: number | undefined, activated?: string | undefined);
}
export declare class TokenDataResponse extends DataObjectResponse {
    data: TokenData;
    success: boolean;
    constructor(data: TokenData, success: boolean);
}
export declare class TokenBiometricData {
    birthDate?: string | undefined;
    birthLocation?: string | undefined;
    cardDeliveryMunicipality?: string | undefined;
    cardNumber?: string | undefined;
    cardValidityDateBegin?: string | undefined;
    cardValidityDateEnd?: string | undefined;
    chipNumber?: string | undefined;
    documentType?: string | undefined;
    firstNames?: string | undefined;
    name?: string | undefined;
    nationalNumber?: string | undefined;
    nationality?: string | undefined;
    nobleCondition?: string | undefined;
    pictureHash?: string | undefined;
    rawData?: string | undefined;
    sex?: string | undefined;
    signature?: string | undefined;
    specialStatus?: string | undefined;
    thirdName?: string | undefined;
    version?: number | undefined;
    issuer?: string | undefined;
    constructor(birthDate?: string | undefined, birthLocation?: string | undefined, cardDeliveryMunicipality?: string | undefined, cardNumber?: string | undefined, cardValidityDateBegin?: string | undefined, cardValidityDateEnd?: string | undefined, chipNumber?: string | undefined, documentType?: string | undefined, firstNames?: string | undefined, name?: string | undefined, nationalNumber?: string | undefined, nationality?: string | undefined, nobleCondition?: string | undefined, pictureHash?: string | undefined, rawData?: string | undefined, sex?: string | undefined, signature?: string | undefined, specialStatus?: string | undefined, thirdName?: string | undefined, version?: number | undefined, issuer?: string | undefined);
}
export declare class TokenBiometricDataResponse extends DataObjectResponse {
    data: TokenBiometricData;
    success: boolean;
    constructor(data: TokenBiometricData, success: boolean);
}
export declare class TokenAlgorithmReferencesResponse {
    data: TokenAlgorithmReferences;
    success: boolean;
    constructor(data: TokenAlgorithmReferences, success: boolean);
}
export declare class TokenAlgorithmReferences {
    ref: Array<string>;
    constructor(ref: Array<string>);
}
export declare class TokenResetPinResponse {
    data: TokenResetPin;
    success: boolean;
    constructor(data: TokenResetPin, success: boolean);
}
export declare class TokenResetPin {
    verified: boolean;
    constructor(verified: boolean);
}
