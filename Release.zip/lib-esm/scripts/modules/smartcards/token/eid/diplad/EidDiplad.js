import { RequestHandler } from '../../../../../util/RequestHandler';
import { CertParser } from "../../../../../util/CertParser";
import { ResponseHandler } from "../../../../../util/ResponseHandler";
import { Pinutil } from "../../../../../..";
var semver = require('semver');
var EidDiplad = (function () {
    function EidDiplad(baseUrl, containerUrl, connection, reader_id) {
        this.baseUrl = baseUrl;
        this.containerUrl = containerUrl;
        this.connection = connection;
        this.reader_id = reader_id;
    }
    EidDiplad.prototype.allData = function (options, callback) {
        var requestOptions = RequestHandler.determineOptionsWithFilter(options);
        return this.connection.get(this.baseUrl, this.tokenApp(EidDiplad.ALL_DATA, true), requestOptions.params, callback);
    };
    EidDiplad.prototype.biometric = function (callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(EidDiplad.RN_DATA, true), undefined, undefined, callback);
    };
    EidDiplad.prototype.address = function (callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(EidDiplad.ADDRESS, true), undefined, undefined, callback);
    };
    EidDiplad.prototype.tokenData = function (callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(EidDiplad.TOKEN, true), undefined, undefined, callback);
    };
    EidDiplad.prototype.picture = function (callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(EidDiplad.PHOTO, true), undefined, undefined, callback);
    };
    EidDiplad.prototype.rootCertificate = function (parseCerts, callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(EidDiplad.CERT_ROOT, true), undefined, undefined, callback).then(function (res) {
            return CertParser.processTokenCertificate(res, parseCerts, callback);
        }).catch(function (error) {
            return ResponseHandler.error(error, callback);
        });
    };
    EidDiplad.prototype.intermediateCertificates = function (parseCerts, callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(EidDiplad.CERT_INTERMEDIATE, true), undefined, undefined, callback).then(function (res) {
            return CertParser.processTokenCertificate(res, parseCerts, callback);
        }).catch(function (error) {
            return ResponseHandler.error(error, callback);
        });
    };
    EidDiplad.prototype.authenticationCertificate = function (parseCerts, callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(EidDiplad.CERT_AUTHENTICATION, true), undefined, undefined, callback).then(function (res) {
            return CertParser.processTokenCertificate(res, parseCerts, callback);
        }).catch(function (error) {
            return ResponseHandler.error(error, callback);
        });
    };
    EidDiplad.prototype.nonRepudiationCertificate = function (parseCerts, callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(EidDiplad.CERT_NON_REPUDIATION, true), undefined, undefined, callback).then(function (res) {
            return CertParser.processTokenCertificate(res, parseCerts, callback);
        }).catch(function (error) {
            return ResponseHandler.error(error, callback);
        });
    };
    EidDiplad.prototype.encryptionCertificate = function (parseCerts, callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(EidDiplad.CERT_ENCRYPTION, true), undefined, undefined, callback).then(function (res) {
            return CertParser.processTokenCertificate(res, parseCerts, callback);
        }).catch(function (error) {
            return ResponseHandler.error(error, callback);
        });
    };
    EidDiplad.prototype.allAlgoRefs = function (callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(EidDiplad.SUPPORTED_ALGOS, true), undefined, undefined, callback);
    };
    EidDiplad.prototype.allCerts = function (parseCerts, options, callback) {
        var reqOptions = RequestHandler.determineOptionsWithFilter(options);
        return this.connection.get(this.baseUrl, this.tokenApp(EidDiplad.ALL_CERTIFICATES, true), reqOptions.params, callback).then(function (res) {
            return CertParser.processTokenAllCertificates(res, parseCerts, callback);
        }).catch(function (error) {
            return ResponseHandler.error(error, callback);
        });
    };
    EidDiplad.prototype.verifyPin = function (body, callback) {
        body.pin = Pinutil.encryptPin(body.pin, this.connection.cfg.version);
        body.base64Encoded = true;
        return this.connection.post(this.baseUrl, this.tokenApp(EidDiplad.VERIFY_PIN, true), body, undefined, undefined, callback);
    };
    EidDiplad.prototype.authenticate = function (body, callback) {
        body.pin = Pinutil.encryptPin(body.pin, this.connection.cfg.version);
        body.base64Encoded = true;
        return this.connection.post(this.baseUrl, this.tokenApp(EidDiplad.AUTHENTICATE, true), body, undefined, undefined, callback);
    };
    EidDiplad.prototype.sign = function (body, bulk, callback) {
        body.pin = Pinutil.encryptPin(body.pin, this.connection.cfg.version);
        body.base64Encoded = true;
        return this.connection.post(this.baseUrl, this.tokenApp(EidDiplad.SIGN_DATA, true), body, this.getBulkSignQueryParams(bulk), undefined, callback);
    };
    EidDiplad.prototype.resetBulkPin = function (callback) {
        if (semver.lt(this.connection.cfg.version, '3.5.0')) {
            return this.connection.get(this.baseUrl, this.tokenApp(EidDiplad.RESET_BULK_PIN, false), undefined, undefined, callback);
        }
        else {
            return this.connection.post(this.baseUrl, this.tokenApp(EidDiplad.RESET_BULK_PIN), null, undefined, undefined, callback);
        }
    };
    EidDiplad.prototype.tokenApp = function (path, includeReaderId) {
        var suffix = this.containerUrl;
        suffix += EidDiplad.PATH_TOKEN_APP;
        if (this.reader_id && this.reader_id.length && includeReaderId) {
            suffix += EidDiplad.PATH_READERS + '/' + this.reader_id;
        }
        if (path && path.length) {
            suffix += path.startsWith('/') ? path : '/' + path;
        }
        return suffix;
    };
    EidDiplad.prototype.getBulkSignQueryParams = function (bulk) {
        if (bulk) {
            return { bulk: true };
        }
    };
    EidDiplad.PATH_TOKEN_APP = '/apps/token';
    EidDiplad.PATH_READERS = '/readers';
    EidDiplad.ALL_DATA = '/all-data';
    EidDiplad.ALL_CERTIFICATES = '/cert-list';
    EidDiplad.CERT_ROOT = '/root-cert';
    EidDiplad.CERT_AUTHENTICATION = '/authentication-cert';
    EidDiplad.CERT_NON_REPUDIATION = '/nonrepudiation-cert';
    EidDiplad.CERT_ENCRYPTION = '/encryption-cert';
    EidDiplad.CERT_INTERMEDIATE = '/intermediate-certs';
    EidDiplad.RN_DATA = '/biometric';
    EidDiplad.ADDRESS = '/address';
    EidDiplad.PHOTO = '/picture';
    EidDiplad.TOKEN = '/info';
    EidDiplad.VERIFY_PIN = '/verify-pin';
    EidDiplad.SIGN_DATA = '/sign';
    EidDiplad.AUTHENTICATE = '/authenticate';
    EidDiplad.VERIFY_PRIV_KEY_REF = 'non-repudiation';
    EidDiplad.SUPPORTED_ALGOS = '/supported-algorithms';
    EidDiplad.RESET_BULK_PIN = "/reset-bulk-pin";
    return EidDiplad;
}());
export { EidDiplad };
//# sourceMappingURL=EidDiplad.js.map