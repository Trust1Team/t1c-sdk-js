var TokenAuthenticateOrSignData = (function () {
    function TokenAuthenticateOrSignData(algorithm, data, pin, pace, id, osDialog, txId, language, base64Encoded) {
        this.algorithm = algorithm;
        this.data = data;
        this.pin = pin;
        this.pace = pace;
        this.id = id;
        this.osDialog = osDialog;
        this.txId = txId;
        this.language = language;
        this.base64Encoded = base64Encoded;
    }
    return TokenAuthenticateOrSignData;
}());
export { TokenAuthenticateOrSignData };
var TokenVerifyPinData = (function () {
    function TokenVerifyPinData(pin, pace, osDialog, base64Encoded) {
        this.pin = pin;
        this.pace = pace;
        this.osDialog = osDialog;
        this.base64Encoded = base64Encoded;
    }
    return TokenVerifyPinData;
}());
export { TokenVerifyPinData };
export var TokenResetPinReferenceType;
(function (TokenResetPinReferenceType) {
    TokenResetPinReferenceType["issign"] = "issign";
    TokenResetPinReferenceType["isauthenticate"] = "isauthenticate";
    TokenResetPinReferenceType["isencrypt"] = "isencrypt";
})(TokenResetPinReferenceType || (TokenResetPinReferenceType = {}));
var TokenResetPinData = (function () {
    function TokenResetPinData(puk, pin, resetOnly, osDialog, reference, base64Encoded) {
        this.puk = puk;
        this.pin = pin;
        this.resetOnly = resetOnly;
        this.osDialog = osDialog;
        this.reference = reference;
        this.base64Encoded = base64Encoded;
    }
    return TokenResetPinData;
}());
export { TokenResetPinData };
var TokenChangePinData = (function () {
    function TokenChangePinData(pin, newPin, osDialog) {
        this.pin = pin;
        this.newPin = newPin;
        this.osDialog = osDialog;
    }
    return TokenChangePinData;
}());
export { TokenChangePinData };
var TokenPinTryCounterData = (function () {
    function TokenPinTryCounterData(reference) {
        this.reference = reference;
    }
    return TokenPinTryCounterData;
}());
export { TokenPinTryCounterData };
//# sourceMappingURL=TokenCard.js.map