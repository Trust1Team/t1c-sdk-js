import { CertParser } from "../../../../../util/CertParser";
import { ResponseHandler } from "../../../../../util/ResponseHandler";
import { Pinutil } from "../../../../../..";
var semver = require('semver');
var Idemia = (function () {
    function Idemia(baseUrl, containerUrl, connection, reader_id) {
        this.baseUrl = baseUrl;
        this.containerUrl = containerUrl;
        this.connection = connection;
        this.reader_id = reader_id;
    }
    Idemia.prototype.rootCertificate = function (parseCerts, callback) {
        return this.getCertificate(Idemia.CERT_ROOT, parseCerts, callback);
    };
    Idemia.prototype.issuerCertificate = function (parseCerts, callback) {
        return this.getCertificate(Idemia.CERT_ISSUER, parseCerts, callback);
    };
    Idemia.prototype.authenticationCertificate = function (parseCerts, callback) {
        return this.getCertificate(Idemia.CERT_AUTHENTICATION, parseCerts, callback);
    };
    Idemia.prototype.nonRepudiationCertificate = function (parseCerts, callback) {
        return this.getCertificate(Idemia.CERT_NON_REPUDIATION, parseCerts, callback);
    };
    Idemia.prototype.encryptionCertificate = function (parseCerts, callback) {
        return this.getCertificate(Idemia.CERT_ENCRYPTION, parseCerts, callback);
    };
    Idemia.prototype.verifyPin = function (body, callback) {
        body.pin = Pinutil.encryptPin(body.pin, this.connection.cfg.version);
        body.base64Encoded = true;
        return this.connection.post(this.baseUrl, this.tokenApp(Idemia.VERIFY_PIN, true), body, undefined, undefined, callback);
    };
    Idemia.prototype.allAlgoRefs = function (callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(Idemia.SUPPORTED_ALGOS, true), undefined, undefined, callback);
    };
    Idemia.prototype.allCerts = function (parseCerts, filters, callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(Idemia.ALL_CERTIFICATES, true), filters, undefined, callback).then(function (res) {
            return CertParser.processTokenAllCertificates(res, parseCerts, callback);
        }).catch(function (error) {
            return ResponseHandler.error(error, callback);
        });
    };
    Idemia.prototype.authenticate = function (body, callback) {
        body.algorithm = body.algorithm.toLowerCase();
        body.pin = Pinutil.encryptPin(body.pin, this.connection.cfg.version);
        body.base64Encoded = true;
        return this.connection.post(this.baseUrl, this.tokenApp(Idemia.AUTHENTICATE, true), body, undefined, undefined, callback);
    };
    Idemia.prototype.sign = function (body, bulk, callback) {
        if (body.algorithm) {
            body.algorithm = body.algorithm.toLowerCase();
        }
        body.pin = Pinutil.encryptPin(body.pin, this.connection.cfg.version);
        body.base64Encoded = true;
        return this.connection.post(this.baseUrl, this.tokenApp(Idemia.SIGN_DATA, true), body, this.getBulkSignQueryParams(bulk), undefined, callback);
    };
    Idemia.prototype.getCertificate = function (certUrl, parseCerts, callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(certUrl, true), undefined, undefined, callback).then(function (res) {
            return CertParser.processTokenCertificate(res, parseCerts, callback);
        }).catch(function (error) {
            return ResponseHandler.error(error, callback);
        });
    };
    Idemia.prototype.tokenData = function (callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(Idemia.INFO, true), undefined, undefined, callback);
    };
    Idemia.prototype.resetBulkPin = function (callback) {
        if (semver.lt(this.connection.cfg.version, '3.5.0')) {
            return this.connection.get(this.baseUrl, this.tokenApp(Idemia.RESET_BULK_PIN, false), undefined, undefined, callback);
        }
        else {
            return this.connection.post(this.baseUrl, this.tokenApp(Idemia.RESET_BULK_PIN), null, undefined, undefined, callback);
        }
    };
    Idemia.prototype.tokenApp = function (path, includeReaderId) {
        var suffix = this.containerUrl;
        suffix += Idemia.PATH_TOKEN_APP;
        if (this.reader_id && this.reader_id.length && includeReaderId) {
            suffix += Idemia.PATH_READERS + '/' + this.reader_id;
        }
        if (path && path.length) {
            suffix += path.startsWith('/') ? path : '/' + path;
        }
        return suffix;
    };
    Idemia.prototype.getBulkSignQueryParams = function (bulk) {
        if (bulk) {
            return { bulk: true };
        }
    };
    Idemia.CONTAINER_PREFIX = 'idemia_cosmo_82';
    Idemia.PATH_TOKEN_APP = '/apps/token';
    Idemia.PATH_READERS = '/readers';
    Idemia.RESET_PIN = '/reset-pin';
    Idemia.INFO = '/info';
    Idemia.ALL_CERTIFICATES = '/cert-list';
    Idemia.AUTHENTICATE = '/authenticate';
    Idemia.CERT_ROOT = '/root-cert';
    Idemia.CERT_AUTHENTICATION = '/authentication-cert';
    Idemia.CERT_NON_REPUDIATION = '/nonrepudiation-cert';
    Idemia.CERT_ISSUER = '/issuer-cert';
    Idemia.CERT_ENCRYPTION = '/encryption-cert';
    Idemia.CERT_RRN = '/encryption-cert';
    Idemia.SIGN_DATA = '/sign';
    Idemia.VERIFY_PIN = '/verify-pin';
    Idemia.SUPPORTED_ALGOS = '/supported-algorithms';
    Idemia.RESET_BULK_PIN = "/reset-bulk-pin";
    return Idemia;
}());
export { Idemia };
//# sourceMappingURL=Idemia.js.map