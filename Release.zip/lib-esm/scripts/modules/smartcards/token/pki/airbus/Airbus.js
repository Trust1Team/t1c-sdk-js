import { CertParser } from "../../../../../util/CertParser";
import { ResponseHandler } from "../../../../../util/ResponseHandler";
import { Pinutil } from "../../../../../../index";
var semver = require('semver');
var Airbus = (function () {
    function Airbus(baseUrl, containerUrl, connection, reader_id) {
        this.baseUrl = baseUrl;
        this.containerUrl = containerUrl;
        this.connection = connection;
        this.reader_id = reader_id;
    }
    Airbus.prototype.authenticationCertificate = function (parseCerts, callback) {
        return this.getCertificate(Airbus.CERT_AUTHENTICATION, parseCerts, callback);
    };
    Airbus.prototype.nonRepudiationCertificate = function (parseCerts, callback) {
        return this.getCertificate(Airbus.CERT_NON_REPUDIATION, parseCerts, callback);
    };
    Airbus.prototype.encryptionCertificate = function (parseCerts, callback) {
        return this.getCertificate(Airbus.CERT_ENC, parseCerts, callback);
    };
    Airbus.prototype.rootCertificate = function (parseCerts, callback) {
        return this.getCertificate(Airbus.CERT_ROOT, parseCerts, callback);
    };
    Airbus.prototype.issuerCertificate = function (parseCerts, callback) {
        return this.getCertificate(Airbus.CERT_ISS, parseCerts, callback);
    };
    Airbus.prototype.verifyPin = function (body, callback) {
        body.pin = Pinutil.encryptPin(body.pin, this.connection.cfg.version);
        body.base64Encoded = true;
        return this.connection.post(this.baseUrl, this.tokenApp(Airbus.VERIFY_PIN, true), body, undefined, undefined, callback);
    };
    Airbus.prototype.allAlgoRefs = function (callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(Airbus.SUPPORTED_ALGOS, true), undefined, undefined, callback);
    };
    Airbus.prototype.allCerts = function (parseCerts, filters, callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(Airbus.ALL_CERTIFICATES, true), filters, undefined, callback).then(function (res) {
            return CertParser.processTokenAllCertificates(res, parseCerts, callback);
        }).catch(function (error) {
            return ResponseHandler.error(error, callback);
        });
    };
    Airbus.prototype.authenticate = function (body, callback) {
        body.algorithm = body.algorithm.toLowerCase();
        body.pin = Pinutil.encryptPin(body.pin, this.connection.cfg.version);
        body.base64Encoded = true;
        return this.connection.post(this.baseUrl, this.tokenApp(Airbus.AUTHENTICATE, true), body, undefined, undefined, callback);
    };
    Airbus.prototype.sign = function (body, bulk, callback) {
        if (body.algorithm) {
            body.algorithm = body.algorithm.toLowerCase();
        }
        body.pin = Pinutil.encryptPin(body.pin, this.connection.cfg.version);
        body.base64Encoded = true;
        return this.connection.post(this.baseUrl, this.tokenApp(Airbus.SIGN_DATA, true), body, this.getBulkSignQueryParams(bulk), undefined, callback);
    };
    Airbus.prototype.getCertificate = function (certUrl, parseCerts, callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(certUrl, true), undefined, undefined, callback).then(function (res) {
            return CertParser.processTokenCertificate(res, parseCerts, callback);
        }).catch(function (error) {
            return ResponseHandler.error(error, callback);
        });
    };
    Airbus.prototype.resetBulkPin = function (callback) {
        if (semver.lt(this.connection.cfg.version, '3.5.0')) {
            return this.connection.get(this.baseUrl, this.tokenApp(Airbus.RESET_BULK_PIN, false), undefined, undefined, callback);
        }
        else {
            return this.connection.post(this.baseUrl, this.tokenApp(Airbus.RESET_BULK_PIN), null, undefined, undefined, callback);
        }
    };
    Airbus.prototype.tokenApp = function (path, includeReaderId) {
        var suffix = this.containerUrl;
        suffix += Airbus.PATH_TOKEN_APP;
        if (this.reader_id && this.reader_id.length && includeReaderId) {
            suffix += Airbus.PATH_READERS + '/' + this.reader_id;
        }
        if (path && path.length) {
            suffix += path.startsWith('/') ? path : '/' + path;
        }
        return suffix;
    };
    Airbus.prototype.getBulkSignQueryParams = function (bulk) {
        if (bulk) {
            return { bulk: true };
        }
    };
    Airbus.CONTAINER_PREFIX = 'airbus';
    Airbus.PATH_TOKEN_APP = '/apps/token';
    Airbus.PATH_READERS = '/readers';
    Airbus.INFO = '/info';
    Airbus.ALL_CERTIFICATES = '/cert-list';
    Airbus.CERT_AUTHENTICATION = '/authentication-cert';
    Airbus.CERT_NON_REPUDIATION = '/nonrepudiation-cert';
    Airbus.CERT_ENC = '/encryption-cert';
    Airbus.CERT_ROOT = '/root-cert';
    Airbus.CERT_ISS = '/issuer-cert';
    Airbus.SIGN_DATA = '/sign';
    Airbus.VERIFY_PIN = '/verify-pin';
    Airbus.AUTHENTICATE = '/authenticate';
    Airbus.RESET_PIN = '/reset-pin';
    Airbus.RESET_BULK_PIN = "/reset-bulk-pin";
    Airbus.SUPPORTED_ALGOS = '/supported-algorithms';
    return Airbus;
}());
export { Airbus };
//# sourceMappingURL=Airbus.js.map