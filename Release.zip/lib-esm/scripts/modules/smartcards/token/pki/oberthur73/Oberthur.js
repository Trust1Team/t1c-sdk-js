import { CertParser } from "../../../../../util/CertParser";
import { ResponseHandler } from "../../../../../util/ResponseHandler";
import { Pinutil } from "../../../../../..";
var semver = require('semver');
var Oberthur = (function () {
    function Oberthur(baseUrl, containerUrl, connection, reader_id) {
        this.baseUrl = baseUrl;
        this.containerUrl = containerUrl;
        this.connection = connection;
        this.reader_id = reader_id;
    }
    Oberthur.prototype.rootCertificate = function (parseCerts, callback) {
        return this.getCertificate(Oberthur.CERT_ROOT, parseCerts, callback);
    };
    Oberthur.prototype.issuerCertificate = function (parseCerts, callback) {
        return this.getCertificate(Oberthur.CERT_ISSUER, parseCerts, callback);
    };
    Oberthur.prototype.authenticationCertificate = function (parseCerts, callback) {
        return this.getCertificate(Oberthur.CERT_AUTHENTICATION, parseCerts, callback);
    };
    Oberthur.prototype.nonRepudiationCertificate = function (parseCerts, callback) {
        return this.getCertificate(Oberthur.CERT_NON_REPUDIATION, parseCerts, callback);
    };
    Oberthur.prototype.encryptionCertificate = function (parseCerts, callback) {
        return this.getCertificate(Oberthur.CERT_ENCRYPTION, parseCerts, callback);
    };
    Oberthur.prototype.verifyPin = function (body, callback) {
        body.pin = Pinutil.encryptPin(body.pin, this.connection.cfg.version);
        body.base64Encoded = true;
        return this.connection.post(this.baseUrl, this.tokenApp(Oberthur.VERIFY_PIN, true), body, undefined, undefined, callback);
    };
    Oberthur.prototype.allAlgoRefs = function (callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(Oberthur.SUPPORTED_ALGOS, true), undefined, undefined, callback);
    };
    Oberthur.prototype.allCerts = function (parseCerts, filters, callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(Oberthur.ALL_CERTIFICATES, true), filters, undefined, callback).then(function (res) {
            return CertParser.processTokenAllCertificates(res, parseCerts, callback);
        }).catch(function (error) {
            return ResponseHandler.error(error, callback);
        });
    };
    Oberthur.prototype.authenticate = function (body, callback) {
        body.pin = Pinutil.encryptPin(body.pin, this.connection.cfg.version);
        body.base64Encoded = true;
        body.algorithm = body.algorithm.toLowerCase();
        return this.connection.post(this.baseUrl, this.tokenApp(Oberthur.AUTHENTICATE, true), body, undefined, undefined, callback);
    };
    Oberthur.prototype.sign = function (body, bulk, callback) {
        body.pin = Pinutil.encryptPin(body.pin, this.connection.cfg.version);
        body.base64Encoded = true;
        if (body.algorithm) {
            body.algorithm = body.algorithm.toLowerCase();
        }
        return this.connection.post(this.baseUrl, this.tokenApp(Oberthur.SIGN_DATA, true), body, this.getBulkSignQueryParams(bulk), undefined, callback);
    };
    Oberthur.prototype.getCertificate = function (certUrl, parseCerts, callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(certUrl, true), undefined, undefined, callback).then(function (res) {
            return CertParser.processTokenCertificate(res, parseCerts, callback);
        }).catch(function (error) {
            return ResponseHandler.error(error, callback);
        });
    };
    Oberthur.prototype.tokenData = function (callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(Oberthur.INFO, true), undefined, undefined, callback);
    };
    Oberthur.prototype.resetBulkPin = function (callback) {
        if (semver.lt(this.connection.cfg.version, '3.5.0')) {
            return this.connection.get(this.baseUrl, this.tokenApp(Oberthur.RESET_BULK_PIN, false), undefined, undefined, callback);
        }
        else {
            return this.connection.post(this.baseUrl, this.tokenApp(Oberthur.RESET_BULK_PIN), null, undefined, undefined, callback);
        }
    };
    Oberthur.prototype.tokenApp = function (path, includeReaderId) {
        var suffix = this.containerUrl;
        suffix += Oberthur.PATH_TOKEN_APP;
        if (this.reader_id && this.reader_id.length && includeReaderId) {
            suffix += Oberthur.PATH_READERS + '/' + this.reader_id;
        }
        if (path && path.length) {
            suffix += path.startsWith('/') ? path : '/' + path;
        }
        return suffix;
    };
    Oberthur.prototype.getBulkSignQueryParams = function (bulk) {
        if (bulk) {
            return { bulk: true };
        }
    };
    Oberthur.PATH_TOKEN_APP = '/apps/token';
    Oberthur.PATH_READERS = '/readers';
    Oberthur.CONTAINER_PREFIX = 'oberthur_73';
    Oberthur.RESET_PIN = '/reset-pin';
    Oberthur.INFO = '/info';
    Oberthur.ALL_CERTIFICATES = '/cert-list';
    Oberthur.AUTHENTICATE = '/authenticate';
    Oberthur.CERT_ROOT = '/root-cert';
    Oberthur.CERT_AUTHENTICATION = '/authentication-cert';
    Oberthur.CERT_NON_REPUDIATION = '/nonrepudiation-cert';
    Oberthur.CERT_ISSUER = '/issuer-cert';
    Oberthur.CERT_ENCRYPTION = '/encryption-cert';
    Oberthur.CERT_RRN = '/encryption-cert';
    Oberthur.SIGN_DATA = '/sign';
    Oberthur.VERIFY_PIN = '/verify-pin';
    Oberthur.SUPPORTED_ALGOS = '/supported-algorithms';
    Oberthur.RESET_BULK_PIN = "/reset-bulk-pin";
    return Oberthur;
}());
export { Oberthur };
//# sourceMappingURL=Oberthur.js.map