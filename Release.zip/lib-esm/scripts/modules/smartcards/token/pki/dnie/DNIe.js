import { CertParser } from "../../../../../util/CertParser";
import { ResponseHandler } from "../../../../../util/ResponseHandler";
import { Pinutil } from "../../../../../..";
var semver = require('semver');
var DNIe = (function () {
    function DNIe(baseUrl, containerUrl, connection, reader_id) {
        this.baseUrl = baseUrl;
        this.containerUrl = containerUrl;
        this.connection = connection;
        this.reader_id = reader_id;
    }
    DNIe.prototype.authenticationCertificate = function (parseCerts, callback) {
        return this.getCertificate(DNIe.CERT_AUTHENTICATION, parseCerts, callback);
    };
    DNIe.prototype.nonRepudiationCertificate = function (parseCerts, callback) {
        return this.getCertificate(DNIe.CERT_NON_REPUDIATION, parseCerts, callback);
    };
    DNIe.prototype.verifyPin = function (body, callback) {
        body.pin = Pinutil.encryptPin(body.pin, this.connection.cfg.version);
        body.base64Encoded = true;
        return this.connection.post(this.baseUrl, this.tokenApp(DNIe.VERIFY_PIN, true), body, undefined, undefined, callback);
    };
    DNIe.prototype.allAlgoRefs = function (callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(DNIe.SUPPORTED_ALGOS, true), undefined, undefined, callback);
    };
    DNIe.prototype.allCerts = function (parseCerts, filters, callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(DNIe.ALL_CERTIFICATES, true), filters, undefined, callback).then(function (res) {
            return CertParser.processTokenAllCertificates(res, parseCerts, callback);
        }).catch(function (error) {
            return ResponseHandler.error(error, callback);
        });
    };
    DNIe.prototype.authenticate = function (body, callback) {
        body.algorithm = body.algorithm.toLowerCase();
        body.pin = Pinutil.encryptPin(body.pin, this.connection.cfg.version);
        body.base64Encoded = true;
        return this.connection.post(this.baseUrl, this.tokenApp(DNIe.AUTHENTICATE, true), body, undefined, undefined, callback);
    };
    DNIe.prototype.sign = function (body, bulk, callback) {
        if (body.algorithm) {
            body.algorithm = body.algorithm.toLowerCase();
        }
        body.pin = Pinutil.encryptPin(body.pin, this.connection.cfg.version);
        body.base64Encoded = true;
        return this.connection.post(this.baseUrl, this.tokenApp(DNIe.SIGN_DATA, true), body, this.getBulkSignQueryParams(bulk), undefined, callback);
    };
    DNIe.prototype.getCertificate = function (certUrl, parseCerts, callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(certUrl, true), undefined, undefined, callback).then(function (res) {
            return CertParser.processTokenCertificate(res, parseCerts, callback);
        }).catch(function (error) {
            return ResponseHandler.error(error, callback);
        });
    };
    DNIe.prototype.resetBulkPin = function (callback) {
        if (semver.lt(this.connection.cfg.version, '3.5.0')) {
            return this.connection.get(this.baseUrl, this.tokenApp(DNIe.RESET_BULK_PIN, false), undefined, undefined, callback);
        }
        else {
            return this.connection.post(this.baseUrl, this.tokenApp(DNIe.RESET_BULK_PIN), null, undefined, undefined, callback);
        }
    };
    DNIe.prototype.tokenApp = function (path, includeReaderId) {
        var suffix = this.containerUrl;
        suffix += DNIe.PATH_TOKEN_APP;
        if (this.reader_id && this.reader_id.length && includeReaderId) {
            suffix += DNIe.PATH_READERS + '/' + this.reader_id;
        }
        if (path && path.length) {
            suffix += path.startsWith('/') ? path : '/' + path;
        }
        return suffix;
    };
    DNIe.prototype.getBulkSignQueryParams = function (bulk) {
        if (bulk) {
            return { bulk: true };
        }
    };
    DNIe.CONTAINER_PREFIX = 'dni';
    DNIe.PATH_TOKEN_APP = '/apps/token';
    DNIe.PATH_READERS = '/readers';
    DNIe.INFO = '/info';
    DNIe.ALL_CERTIFICATES = '/cert-list';
    DNIe.CERT_AUTHENTICATION = '/authentication-cert';
    DNIe.CERT_NON_REPUDIATION = '/nonrepudiation-cert';
    DNIe.SIGN_DATA = '/sign';
    DNIe.VERIFY_PIN = '/verify-pin';
    DNIe.AUTHENTICATE = '/authenticate';
    DNIe.RESET_PIN = '/reset-pin';
    DNIe.RESET_BULK_PIN = "/reset-bulk-pin";
    DNIe.SUPPORTED_ALGOS = '/supported-algorithms';
    return DNIe;
}());
export { DNIe };
//# sourceMappingURL=DNIe.js.map