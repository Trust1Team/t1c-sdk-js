import { CertParser } from "../../../../../util/CertParser";
import { ResponseHandler } from "../../../../../util/ResponseHandler";
import { Pinutil } from "../../../../../../index";
var semver = require('semver');
var EHerkenning = (function () {
    function EHerkenning(baseUrl, containerUrl, connection, reader_id) {
        this.baseUrl = baseUrl;
        this.containerUrl = containerUrl;
        this.connection = connection;
        this.reader_id = reader_id;
    }
    EHerkenning.prototype.authenticationCertificate = function (parseCerts, callback) {
        return this.getCertificate(EHerkenning.CERT_AUTHENTICATION, parseCerts, callback);
    };
    EHerkenning.prototype.nonRepudiationCertificate = function (parseCerts, callback) {
        return this.getCertificate(EHerkenning.CERT_NON_REPUDIATION, parseCerts, callback);
    };
    EHerkenning.prototype.verifyPin = function (body, callback) {
        body.pin = Pinutil.encryptPin(body.pin, this.connection.cfg.version);
        body.base64Encoded = true;
        return this.connection.post(this.baseUrl, this.tokenApp(EHerkenning.VERIFY_PIN, true), body, undefined, undefined, callback);
    };
    EHerkenning.prototype.allAlgoRefs = function (callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(EHerkenning.SUPPORTED_ALGOS, true), undefined, undefined, callback);
    };
    EHerkenning.prototype.allCerts = function (parseCerts, filters, callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(EHerkenning.ALL_CERTIFICATES, true), filters, undefined, callback).then(function (res) {
            return CertParser.processTokenAllCertificates(res, parseCerts, callback);
        }).catch(function (error) {
            return ResponseHandler.error(error, callback);
        });
    };
    EHerkenning.prototype.authenticate = function (body, callback) {
        body.algorithm = body.algorithm.toLowerCase();
        body.pin = Pinutil.encryptPin(body.pin, this.connection.cfg.version);
        body.base64Encoded = true;
        return this.connection.post(this.baseUrl, this.tokenApp(EHerkenning.AUTHENTICATE, true), body, undefined, undefined, callback);
    };
    EHerkenning.prototype.sign = function (body, bulk, callback) {
        if (body.algorithm) {
            body.algorithm = body.algorithm.toLowerCase();
        }
        body.pin = Pinutil.encryptPin(body.pin, this.connection.cfg.version);
        body.base64Encoded = true;
        return this.connection.post(this.baseUrl, this.tokenApp(EHerkenning.SIGN_DATA, true), body, this.getBulkSignQueryParams(bulk), undefined, callback);
    };
    EHerkenning.prototype.getCertificate = function (certUrl, parseCerts, callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(certUrl, true), undefined, undefined, callback).then(function (res) {
            return CertParser.processTokenCertificate(res, parseCerts, callback);
        }).catch(function (error) {
            return ResponseHandler.error(error, callback);
        });
    };
    EHerkenning.prototype.resetBulkPin = function (callback) {
        if (semver.lt(this.connection.cfg.version, '3.5.0')) {
            return this.connection.get(this.baseUrl, this.tokenApp(EHerkenning.RESET_BULK_PIN, false), undefined, undefined, callback);
        }
        else {
            return this.connection.post(this.baseUrl, this.tokenApp(EHerkenning.RESET_BULK_PIN), null, undefined, undefined, callback);
        }
    };
    EHerkenning.prototype.tokenApp = function (path, includeReaderId) {
        var suffix = this.containerUrl;
        suffix += EHerkenning.PATH_TOKEN_APP;
        if (this.reader_id && this.reader_id.length && includeReaderId) {
            suffix += EHerkenning.PATH_READERS + '/' + this.reader_id;
        }
        if (path && path.length) {
            suffix += path.startsWith('/') ? path : '/' + path;
        }
        return suffix;
    };
    EHerkenning.prototype.getBulkSignQueryParams = function (bulk) {
        if (bulk) {
            return { bulk: true };
        }
    };
    EHerkenning.CONTAINER_PREFIX = 'eHerkenning';
    EHerkenning.PATH_TOKEN_APP = '/apps/token';
    EHerkenning.PATH_READERS = '/readers';
    EHerkenning.INFO = '/info';
    EHerkenning.ALL_CERTIFICATES = '/cert-list';
    EHerkenning.CERT_AUTHENTICATION = '/authentication-cert';
    EHerkenning.CERT_NON_REPUDIATION = '/nonrepudiation-cert';
    EHerkenning.SIGN_DATA = '/sign';
    EHerkenning.VERIFY_PIN = '/verify-pin';
    EHerkenning.AUTHENTICATE = '/authenticate';
    EHerkenning.RESET_PIN = '/reset-pin';
    EHerkenning.RESET_BULK_PIN = "/reset-bulk-pin";
    EHerkenning.SUPPORTED_ALGOS = '/supported-algorithms';
    return EHerkenning;
}());
export { EHerkenning };
//# sourceMappingURL=eHerkenning.js.map