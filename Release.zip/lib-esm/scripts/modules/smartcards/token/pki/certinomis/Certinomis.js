import { CertParser } from "../../../../../util/CertParser";
import { ResponseHandler } from "../../../../../util/ResponseHandler";
import { Pinutil } from "../../../../../../index";
var semver = require('semver');
var Certinomis = (function () {
    function Certinomis(baseUrl, containerUrl, connection, reader_id) {
        this.baseUrl = baseUrl;
        this.containerUrl = containerUrl;
        this.connection = connection;
        this.reader_id = reader_id;
    }
    Certinomis.prototype.authenticationCertificate = function (parseCerts, callback) {
        return this.getCertificate(Certinomis.CERT_AUTHENTICATION, parseCerts, callback);
    };
    Certinomis.prototype.nonRepudiationCertificate = function (parseCerts, callback) {
        return this.getCertificate(Certinomis.CERT_NON_REPUDIATION, parseCerts, callback);
    };
    Certinomis.prototype.verifyPin = function (body, callback) {
        body.pin = Pinutil.encryptPin(body.pin, this.connection.cfg.version);
        body.base64Encoded = true;
        return this.connection.post(this.baseUrl, this.tokenApp(Certinomis.VERIFY_PIN, true), body, undefined, undefined, callback);
    };
    Certinomis.prototype.allAlgoRefs = function (callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(Certinomis.SUPPORTED_ALGOS, true), undefined, undefined, callback);
    };
    Certinomis.prototype.allCerts = function (parseCerts, filters, callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(Certinomis.ALL_CERTIFICATES, true), filters, undefined, callback).then(function (res) {
            return CertParser.processTokenAllCertificates(res, parseCerts, callback);
        }).catch(function (error) {
            return ResponseHandler.error(error, callback);
        });
    };
    Certinomis.prototype.authenticate = function (body, callback) {
        body.algorithm = body.algorithm.toLowerCase();
        body.pin = Pinutil.encryptPin(body.pin, this.connection.cfg.version);
        body.base64Encoded = true;
        return this.connection.post(this.baseUrl, this.tokenApp(Certinomis.AUTHENTICATE, true), body, undefined, undefined, callback);
    };
    Certinomis.prototype.sign = function (body, bulk, callback) {
        if (body.algorithm) {
            body.algorithm = body.algorithm.toLowerCase();
        }
        body.pin = Pinutil.encryptPin(body.pin, this.connection.cfg.version);
        body.base64Encoded = true;
        return this.connection.post(this.baseUrl, this.tokenApp(Certinomis.SIGN_DATA, true), body, this.getBulkSignQueryParams(bulk), undefined, callback);
    };
    Certinomis.prototype.getCertificate = function (certUrl, parseCerts, callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(certUrl, true), undefined, undefined, callback).then(function (res) {
            return CertParser.processTokenCertificate(res, parseCerts, callback);
        }).catch(function (error) {
            return ResponseHandler.error(error, callback);
        });
    };
    Certinomis.prototype.resetBulkPin = function (callback) {
        if (semver.lt(this.connection.cfg.version, '3.5.0')) {
            return this.connection.get(this.baseUrl, this.tokenApp(Certinomis.RESET_BULK_PIN, false), undefined, undefined, callback);
        }
        else {
            return this.connection.post(this.baseUrl, this.tokenApp(Certinomis.RESET_BULK_PIN), null, undefined, undefined, callback);
        }
    };
    Certinomis.prototype.tokenApp = function (path, includeReaderId) {
        var suffix = this.containerUrl;
        suffix += Certinomis.PATH_TOKEN_APP;
        if (this.reader_id && this.reader_id.length && includeReaderId) {
            suffix += Certinomis.PATH_READERS + '/' + this.reader_id;
        }
        if (path && path.length) {
            suffix += path.startsWith('/') ? path : '/' + path;
        }
        return suffix;
    };
    Certinomis.prototype.getBulkSignQueryParams = function (bulk) {
        if (bulk) {
            return { bulk: true };
        }
    };
    Certinomis.CONTAINER_PREFIX = 'certinomis';
    Certinomis.PATH_TOKEN_APP = '/apps/token';
    Certinomis.PATH_READERS = '/readers';
    Certinomis.INFO = '/info';
    Certinomis.ALL_CERTIFICATES = '/cert-list';
    Certinomis.CERT_AUTHENTICATION = '/authentication-cert';
    Certinomis.CERT_NON_REPUDIATION = '/nonrepudiation-cert';
    Certinomis.SIGN_DATA = '/sign';
    Certinomis.VERIFY_PIN = '/verify-pin';
    Certinomis.AUTHENTICATE = '/authenticate';
    Certinomis.RESET_PIN = '/reset-pin';
    Certinomis.RESET_BULK_PIN = "/reset-bulk-pin";
    Certinomis.SUPPORTED_ALGOS = '/supported-algorithms';
    return Certinomis;
}());
export { Certinomis };
//# sourceMappingURL=Certinomis.js.map