import { CertParser } from "../../../../../util/CertParser";
import { ResponseHandler } from "../../../../../util/ResponseHandler";
import { Pinutil } from "../../../../../..";
var semver = require('semver');
var Aventra = (function () {
    function Aventra(baseUrl, containerUrl, connection, reader_id) {
        this.baseUrl = baseUrl;
        this.containerUrl = containerUrl;
        this.connection = connection;
        this.reader_id = reader_id;
    }
    Aventra.prototype.rootCertificate = function (parseCerts, callback) {
        return this.getCertificate(Aventra.CERT_ROOT, parseCerts, callback);
    };
    Aventra.prototype.issuerCertificate = function (parseCerts, callback) {
        return this.getCertificate(Aventra.CERT_ISSUER, parseCerts, callback);
    };
    Aventra.prototype.authenticationCertificate = function (parseCerts, callback) {
        return this.getCertificate(Aventra.CERT_AUTHENTICATION, parseCerts, callback);
    };
    Aventra.prototype.nonRepudiationCertificate = function (parseCerts, callback) {
        return this.getCertificate(Aventra.CERT_NON_REPUDIATION, parseCerts, callback);
    };
    Aventra.prototype.encryptionCertificate = function (parseCerts, callback) {
        return this.getCertificate(Aventra.CERT_ENCRYPTION, parseCerts, callback);
    };
    Aventra.prototype.verifyPin = function (body, callback) {
        body.pin = Pinutil.encryptPin(body.pin, this.connection.cfg.version);
        body.base64Encoded = true;
        return this.connection.post(this.baseUrl, this.tokenApp(Aventra.VERIFY_PIN, true), body, undefined, undefined, callback);
    };
    Aventra.prototype.resetPin = function (body, callback) {
        body.pin = Pinutil.encryptPin(body.pin, this.connection.cfg.version);
        body.base64Encoded = true;
        body.puk = Pinutil.encryptPin(body.puk);
        return this.connection.post(this.baseUrl, this.tokenApp(Aventra.RESET_PIN, true), body, undefined, undefined, callback);
    };
    Aventra.prototype.allAlgoRefs = function (callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(Aventra.SUPPORTED_ALGOS, true), undefined, undefined, callback);
    };
    Aventra.prototype.allCerts = function (parseCerts, filters, callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(Aventra.ALL_CERTIFICATES, true), filters, undefined, callback).then(function (res) {
            return CertParser.processTokenAllCertificates(res, parseCerts, callback);
        }).catch(function (error) {
            return ResponseHandler.error(error, callback);
        });
    };
    Aventra.prototype.authenticate = function (body, callback) {
        body.algorithm = body.algorithm.toLowerCase();
        body.pin = Pinutil.encryptPin(body.pin, this.connection.cfg.version);
        body.base64Encoded = true;
        return this.connection.post(this.baseUrl, this.tokenApp(Aventra.AUTHENTICATE, true), body, undefined, undefined, callback);
    };
    Aventra.prototype.sign = function (body, bulk, callback) {
        if (body.algorithm) {
            body.algorithm = body.algorithm.toLowerCase();
        }
        body.pin = Pinutil.encryptPin(body.pin, this.connection.cfg.version);
        body.base64Encoded = true;
        return this.connection.post(this.baseUrl, this.tokenApp(Aventra.SIGN_DATA, true), body, this.getBulkSignQueryParams(bulk), undefined, callback);
    };
    Aventra.prototype.getCertificate = function (certUrl, parseCerts, callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(certUrl, true), undefined, undefined, callback).then(function (res) {
            return CertParser.processTokenCertificate(res, parseCerts, callback);
        }).catch(function (error) {
            return ResponseHandler.error(error, callback);
        });
    };
    Aventra.prototype.tokenData = function (callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(Aventra.INFO, true), undefined, undefined, callback);
    };
    Aventra.prototype.resetBulkPin = function (callback) {
        if (semver.lt(this.connection.cfg.version, '3.5.0')) {
            return this.connection.get(this.baseUrl, this.tokenApp(Aventra.RESET_BULK_PIN, false), undefined, undefined, callback);
        }
        else {
            return this.connection.post(this.baseUrl, this.tokenApp(Aventra.RESET_BULK_PIN), null, undefined, undefined, callback);
        }
    };
    Aventra.prototype.tokenApp = function (path, includeReaderId) {
        var suffix = this.containerUrl;
        suffix += Aventra.PATH_TOKEN_APP;
        if (this.reader_id && this.reader_id.length && includeReaderId) {
            suffix += Aventra.PATH_READERS + '/' + this.reader_id;
        }
        if (path && path.length) {
            suffix += path.startsWith('/') ? path : '/' + path;
        }
        return suffix;
    };
    Aventra.prototype.getBulkSignQueryParams = function (bulk) {
        if (bulk) {
            return { bulk: true };
        }
    };
    Aventra.CONTAINER_PREFIX = 'aventra_myid_4';
    Aventra.PATH_TOKEN_APP = '/apps/token';
    Aventra.PATH_READERS = '/readers';
    Aventra.INFO = '/info';
    Aventra.ALL_CERTIFICATES = '/cert-list';
    Aventra.CERT_ROOT = '/root-cert';
    Aventra.CERT_AUTHENTICATION = '/authentication-cert';
    Aventra.CERT_NON_REPUDIATION = '/nonrepudiation-cert';
    Aventra.CERT_ISSUER = '/issuer-cert';
    Aventra.CERT_ENCRYPTION = '/encryption-cert';
    Aventra.SIGN_DATA = '/sign';
    Aventra.VERIFY_PIN = '/verify-pin';
    Aventra.AUTHENTICATE = '/authenticate';
    Aventra.RESET_PIN = '/reset-pin';
    Aventra.RESET_BULK_PIN = "/reset-bulk-pin";
    Aventra.SUPPORTED_ALGOS = '/supported-algorithms';
    return Aventra;
}());
export { Aventra };
//# sourceMappingURL=Aventra.js.map