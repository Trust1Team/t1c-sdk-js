import { CertParser } from "../../../../../util/CertParser";
import { ResponseHandler } from "../../../../../util/ResponseHandler";
import { Pinutil } from "../../../../../../index";
var semver = require('semver');
var Safenet = (function () {
    function Safenet(baseUrl, containerUrl, connection, reader_id) {
        this.baseUrl = baseUrl;
        this.containerUrl = containerUrl;
        this.connection = connection;
        this.reader_id = reader_id;
    }
    Safenet.prototype.authenticationCertificate = function (parseCerts, callback) {
        return this.getCertificate(Safenet.CERT_AUTHENTICATION, parseCerts, callback);
    };
    Safenet.prototype.nonRepudiationCertificate = function (parseCerts, callback) {
        return this.getCertificate(Safenet.CERT_NON_REPUDIATION, parseCerts, callback);
    };
    Safenet.prototype.verifyPin = function (body, callback) {
        body.pin = Pinutil.encryptPin(body.pin, this.connection.cfg.version);
        body.base64Encoded = true;
        return this.connection.post(this.baseUrl, this.tokenApp(Safenet.VERIFY_PIN, true), body, undefined, undefined, callback);
    };
    Safenet.prototype.allAlgoRefs = function (callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(Safenet.SUPPORTED_ALGOS, true), undefined, undefined, callback);
    };
    Safenet.prototype.allCerts = function (parseCerts, filters, callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(Safenet.ALL_CERTIFICATES, true), filters, undefined, callback).then(function (res) {
            return CertParser.processTokenAllCertificates(res, parseCerts, callback);
        }).catch(function (error) {
            return ResponseHandler.error(error, callback);
        });
    };
    Safenet.prototype.authenticate = function (body, callback) {
        body.algorithm = body.algorithm.toLowerCase();
        body.pin = Pinutil.encryptPin(body.pin, this.connection.cfg.version);
        body.base64Encoded = true;
        return this.connection.post(this.baseUrl, this.tokenApp(Safenet.AUTHENTICATE, true), body, undefined, undefined, callback);
    };
    Safenet.prototype.sign = function (body, bulk, callback) {
        if (body.algorithm) {
            body.algorithm = body.algorithm.toLowerCase();
        }
        body.pin = Pinutil.encryptPin(body.pin, this.connection.cfg.version);
        body.base64Encoded = true;
        return this.connection.post(this.baseUrl, this.tokenApp(Safenet.SIGN_DATA, true), body, this.getBulkSignQueryParams(bulk), undefined, callback);
    };
    Safenet.prototype.getCertificate = function (certUrl, parseCerts, callback) {
        return this.connection.get(this.baseUrl, this.tokenApp(certUrl, true), undefined, undefined, callback).then(function (res) {
            return CertParser.processTokenCertificate(res, parseCerts, callback);
        }).catch(function (error) {
            return ResponseHandler.error(error, callback);
        });
    };
    Safenet.prototype.resetBulkPin = function (callback) {
        if (semver.lt(this.connection.cfg.version, '3.5.0')) {
            return this.connection.get(this.baseUrl, this.tokenApp(Safenet.RESET_BULK_PIN, false), undefined, undefined, callback);
        }
        else {
            return this.connection.post(this.baseUrl, this.tokenApp(Safenet.RESET_BULK_PIN), null, undefined, undefined, callback);
        }
    };
    Safenet.prototype.tokenApp = function (path, includeReaderId) {
        var suffix = this.containerUrl;
        suffix += Safenet.PATH_TOKEN_APP;
        if (this.reader_id && this.reader_id.length && includeReaderId) {
            suffix += Safenet.PATH_READERS + '/' + this.reader_id;
        }
        if (path && path.length) {
            suffix += path.startsWith('/') ? path : '/' + path;
        }
        return suffix;
    };
    Safenet.prototype.getBulkSignQueryParams = function (bulk) {
        if (bulk) {
            return { bulk: true };
        }
    };
    Safenet.CONTAINER_PREFIX = 'safenet';
    Safenet.PATH_TOKEN_APP = '/apps/token';
    Safenet.PATH_READERS = '/readers';
    Safenet.INFO = '/info';
    Safenet.ALL_CERTIFICATES = '/cert-list';
    Safenet.CERT_AUTHENTICATION = '/authentication-cert';
    Safenet.CERT_NON_REPUDIATION = '/nonrepudiation-cert';
    Safenet.SIGN_DATA = '/sign';
    Safenet.VERIFY_PIN = '/verify-pin';
    Safenet.AUTHENTICATE = '/authenticate';
    Safenet.RESET_PIN = '/reset-pin';
    Safenet.RESET_BULK_PIN = "/reset-bulk-pin";
    Safenet.SUPPORTED_ALGOS = '/supported-algorithms';
    return Safenet;
}());
export { Safenet };
//# sourceMappingURL=Safenet.js.map