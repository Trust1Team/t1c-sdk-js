import { LocalConnection, PaymentAllCertsResponse, PaymentCertificateResponse, PaymentReadApplicationDataResponse, PaymentReadDataResponse, PaymentVerifyPinResponse, T1CLibException } from "../../../../../index";
import { AbstractEmv } from "./EmvModel";
import { PaymentVerifyPinData } from "../PaymentCard";
import { Options } from "../../Card";
export declare class Emv implements AbstractEmv {
    protected baseUrl: string;
    protected containerUrl: string;
    protected connection: LocalConnection;
    protected reader_id: string;
    static PATH_PAYMENT_APP: string;
    static PATH_READERS: string;
    static ALL_CERTIFICATES: string;
    static CERT_ISSUER: string;
    static CERT_ICC: string;
    static READ_DATA: string;
    static READ_APPLICATION_DATA: string;
    static VERIFY_PIN: string;
    constructor(baseUrl: string, containerUrl: string, connection: LocalConnection, reader_id: string);
    allCerts(aid: string, filters: string[] | Options, callback?: (error: T1CLibException, data: PaymentAllCertsResponse) => void): Promise<PaymentAllCertsResponse>;
    iccPublicCertificate(aid: string, callback?: (error: T1CLibException, data: PaymentCertificateResponse) => void): Promise<PaymentCertificateResponse>;
    issuerPublicCertificate(aid: string, callback?: (error: T1CLibException, data: PaymentCertificateResponse) => void): Promise<PaymentCertificateResponse>;
    readApplicationData(callback?: (error: T1CLibException, data: PaymentReadApplicationDataResponse) => void): Promise<PaymentReadApplicationDataResponse>;
    readData(callback?: (error: T1CLibException, data: PaymentReadDataResponse) => void): Promise<PaymentReadDataResponse>;
    verifyPin(body: PaymentVerifyPinData, callback?: (error: T1CLibException, data: PaymentVerifyPinResponse) => void): Promise<PaymentVerifyPinResponse>;
    protected paymentApp(path?: string, aid?: string): string;
}
