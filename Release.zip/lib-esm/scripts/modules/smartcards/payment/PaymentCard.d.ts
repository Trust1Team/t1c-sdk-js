export declare class PaymentVerifyPinData {
    pin?: string | undefined;
    osDialog?: boolean | undefined;
    base64Encoded?: boolean | undefined;
    constructor(pin?: string | undefined, osDialog?: boolean | undefined, base64Encoded?: boolean | undefined);
}
export declare class PaymentSignData {
    txId: string;
    language: string;
    data: string;
    constructor(txId: string, language: string, data: string);
}
