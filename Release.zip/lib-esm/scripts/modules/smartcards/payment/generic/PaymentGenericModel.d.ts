import { PaymentSignData, PaymentVerifyPinData } from "../PaymentCard";
import { BoolDataResponse, DataObjectResponse, PaymentAllCertsResponse, PaymentCertificateResponse, T1CLibException } from "../../../../../index";
import { Options } from "../../Card";
export interface AbstractPaymentGeneric {
    allCerts(module: string, aid: string, filters: string[] | Options, callback?: (error: T1CLibException, data: PaymentAllCertsResponse) => void): Promise<PaymentAllCertsResponse>;
    readApplicationData(module: string, callback?: (error: T1CLibException, data: PaymentReadApplicationDataResponse) => void): Promise<PaymentReadApplicationDataResponse>;
    readData(module: string, callback?: (error: T1CLibException, data: PaymentReadDataResponse) => void): Promise<PaymentReadDataResponse>;
    issuerPublicCertificate(module: string, aid: string, callback?: (error: T1CLibException, data: PaymentCertificateResponse) => void): Promise<PaymentCertificateResponse>;
    iccPublicCertificate(module: string, aid: string, callback?: (error: T1CLibException, data: PaymentCertificateResponse) => void): Promise<PaymentCertificateResponse>;
    verifyPin(module: string, body: PaymentVerifyPinData, callback?: (error: T1CLibException, data: PaymentVerifyPinResponse) => void): Promise<PaymentVerifyPinResponse>;
    getModuleDescription(module: string, callback?: (error: T1CLibException, data: DataObjectResponse) => void): Promise<DataObjectResponse>;
    resetBulkPin(module: string, callback?: (error: T1CLibException, data: BoolDataResponse) => void): Promise<BoolDataResponse>;
    sign(module: string, body: PaymentSignData, bulk?: boolean, callback?: (error: T1CLibException, data: PaymentSignResponse) => void): Promise<PaymentSignResponse>;
}
export declare class PaymentModuleDescriptionResponse extends DataObjectResponse {
    data: PaymentModuleDescription;
    success: boolean;
    constructor(data: PaymentModuleDescription, success: boolean);
}
export declare class PaymentModuleDescription {
    desc: string;
    constructor(desc: string);
}
export declare class PaymentVerifyPinResponse extends DataObjectResponse {
    data: PaymentVerifyPinResponseData;
    success: boolean;
    constructor(data: PaymentVerifyPinResponseData, success: boolean);
}
export declare class PaymentVerifyPinResponseData {
    verified: boolean;
    constructor(verified: boolean);
}
export declare class PaymentReadData {
    applications: Array<PaymentApplication>;
    constructor(applications: Array<PaymentApplication>);
}
export declare class PaymentApplication {
    aid?: string | undefined;
    name?: string | undefined;
    priority?: number | undefined;
    constructor(aid?: string | undefined, name?: string | undefined, priority?: number | undefined);
}
export declare class PaymentReadDataResponse extends DataObjectResponse {
    data: PaymentReadData;
    success: boolean;
    constructor(data: PaymentReadData, success: boolean);
}
export declare class PaymentReadApplicationData {
    country?: string | undefined;
    countryCode?: string | undefined;
    effectiveDate?: string | undefined;
    expirationDate?: string | undefined;
    language?: string | undefined;
    name?: string | undefined;
    pan?: string | undefined;
    constructor(country?: string | undefined, countryCode?: string | undefined, effectiveDate?: string | undefined, expirationDate?: string | undefined, language?: string | undefined, name?: string | undefined, pan?: string | undefined);
}
export declare class PaymentReadApplicationDataResponse extends DataObjectResponse {
    data: PaymentReadApplicationData;
    success: boolean;
    constructor(data: PaymentReadApplicationData, success: boolean);
}
export declare class PaymentSignResponseData {
    success: boolean;
    data?: string | undefined;
    cardSignature?: string | undefined;
    readerSignature?: string | undefined;
    constructor(success: boolean, data?: string | undefined, cardSignature?: string | undefined, readerSignature?: string | undefined);
}
export declare class PaymentSignResponse {
    data: PaymentSignResponseData;
    success: boolean;
    constructor(data: PaymentSignResponseData, success: boolean);
}
