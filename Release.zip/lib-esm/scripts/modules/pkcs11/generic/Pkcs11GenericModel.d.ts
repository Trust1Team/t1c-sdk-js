import { BoolDataResponse, DataResponse, T1CLibException } from "../../../..";
export interface AbstractPkcs11Generic {
    uploadConfig(config: string, callback?: (error: T1CLibException, data: Pkcs11UploadConfigResponse) => void): Promise<Pkcs11UploadConfigResponse>;
    getConfig(callback?: (error: T1CLibException, data: Pkcs11GetConfigResponse) => void): Promise<Pkcs11GetConfigResponse>;
    clearConfig(callback?: (error: T1CLibException, data: Pkcs11ClearConfigResponse) => void): Promise<Pkcs11ClearConfigResponse>;
    os(callback?: (error: T1CLibException, data: OsResponse) => void): Promise<OsResponse>;
    info(callback?: (error: T1CLibException, data: Pkcs11InfoResponse) => void): Promise<Pkcs11InfoResponse>;
    slots(callback?: (error: T1CLibException, data: Pkcs11SlotsResponse) => void): Promise<Pkcs11SlotsResponse>;
    slotsWithTokenPresent(callback?: (error: T1CLibException, data: Pkcs11SlotsResponse) => void): Promise<Pkcs11SlotsResponse>;
    slotInfo(slotId: number, callback?: (error: T1CLibException, data: Pkcs11SlotInfoResponse) => void): Promise<Pkcs11SlotInfoResponse>;
    token(slotId: number, callback?: (error: T1CLibException, data: Pkcs11TokenResponse) => void): Promise<Pkcs11TokenResponse>;
    getAliases(slotId: number, data: Pkcs11VerifyPinRequest, callback?: (error: T1CLibException, data: AliasesResponse) => void): Promise<AliasesResponse>;
    getPrivateKeyType(slotId: number, alias: string, data: Pkcs11VerifyPinRequest, callback?: (error: T1CLibException, data: PrivateKeyTypeResponse) => void): Promise<PrivateKeyTypeResponse>;
    getCertificates(slotId: number, alias: string, data: Pkcs11VerifyPinRequest, callback?: (error: T1CLibException, data: Pkcs11CertificatesResponse) => void): Promise<Pkcs11CertificatesResponse>;
    sign(slotId: number, alias: string, data: Pkcs11SignRequest, callback?: (error: T1CLibException, data: DataResponse) => void): Promise<DataResponse>;
    verifyPin(slotId: number, alias: string, data: Pkcs11VerifyPinRequest, callback?: (error: T1CLibException, data: BoolDataResponse) => void): Promise<BoolDataResponse>;
}
export declare class Pkcs11VerifyPinRequest {
    pin?: string | undefined;
    constructor(pin?: string | undefined);
}
export declare class OsResponse {
    data: Os;
    success: boolean;
    constructor(data: Os, success: boolean);
}
export declare class Os {
    id: string;
    version: string;
    constructor(id: string, version: string);
}
export declare class PrivateKeyTypeResponse {
    data: PrivateKeyType;
    success: boolean;
    constructor(data: PrivateKeyType, success: boolean);
}
export declare class PrivateKeyType {
    data: string;
    algorithms?: string[] | undefined;
    constructor(data: string, algorithms?: string[] | undefined);
}
export declare class Certificate {
    certificate?: string | undefined;
    constructor(certificate?: string | undefined, certSn?: string);
}
export declare class AliasesResponse {
    data: Aliases;
    success: boolean;
    constructor(data: Aliases, success: boolean);
}
export declare class Aliases {
    aliases: Alias[];
    constructor(aliases: Alias[]);
}
export declare class Alias {
    ref: string;
    constructor(ref: string);
}
export declare class Pkcs11UploadConfigResponse {
    data: string;
    success: boolean;
    constructor(data: string, success: boolean);
}
export declare class Pkcs11ClearConfigResponse {
    data: string;
    success: boolean;
    constructor(data: string, success: boolean);
}
export declare class Pkcs11GetConfigResponse {
    data: Pkcs11GetConfig;
    success: boolean;
    constructor(data: Pkcs11GetConfig, success: boolean);
}
export declare class Pkcs11GetConfig {
    sessionRef?: string | undefined;
    tempPath?: string | undefined;
    constructor(sessionRef?: string | undefined, tempPath?: string | undefined);
}
export declare class Pkcs11InfoResponse {
    data: Pkcs11Info;
    success: boolean;
    constructor(data: Pkcs11Info, success: boolean);
}
export declare class Pkcs11SlotInfoResponse {
    data: Pkcs11Slot;
    success: boolean;
    constructor(data: Pkcs11Slot, success: boolean);
}
export declare class Pkcs11Info {
    cryptokiVersion: string;
    manufacturerId: string;
    libraryDescription: string;
    libraryVersion: string;
    constructor(cryptokiVersion: string, manufacturerId: string, libraryDescription: string, libraryVersion: string);
}
export declare class Pkcs11Slots {
    slots: Pkcs11Slot[];
    constructor(slots: Pkcs11Slot[]);
}
export declare class Pkcs11Slot {
    slot: number;
    description: string;
    constructor(slot: number, description: string);
}
export declare class Pkcs11SlotsResponse {
    data: Pkcs11Slots;
    success: boolean;
    constructor(data: Pkcs11Slots, success: boolean);
}
export declare class Pkcs11Certificates {
    certificates: Pkcs11Certificate[];
    constructor(certificates: Pkcs11Certificate[]);
}
export declare class Pkcs11Certificate {
    cert: string;
    certSn: string;
    parsed?: object | undefined;
    constructor(cert: string, certSn: string, parsed?: object | undefined);
}
export declare class Pkcs11CertificatesResponse {
    data: Pkcs11Certificates;
    success: boolean;
    constructor(data: Pkcs11Certificates, success: boolean);
}
export declare class Pkcs11SignRequest {
    algorithm: string;
    data: string;
    pin?: string | undefined;
    constructor(algorithm: string, data: string, pin?: string | undefined);
}
export declare class Pkcs11Config {
    config: string;
    constructor(config: string);
}
export declare class Pkcs11TokenInfo {
    slot: string;
    label: string;
    manufacturerId: string;
    model: string;
    serialNumber: string;
    flags: string;
    ulMaxSessionCount: number;
    ulSessionCount: number;
    ulMaxRwSessionCount: number;
    ulMaxPinLen: number;
    ulMinPinLen: number;
    ulTotalPublicMemory: number;
    ulFreePublicMemory: number;
    ulTotalPrivateMemory: number;
    ulFreePrivateMemory: number;
    hardwareVersion: string;
    firmwareVersion: string;
    mechanisms: Array<Mechanism>;
    constructor(slot: string, label: string, manufacturerId: string, model: string, serialNumber: string, flags: string, ulMaxSessionCount: number, ulSessionCount: number, ulMaxRwSessionCount: number, ulMaxPinLen: number, ulMinPinLen: number, ulTotalPublicMemory: number, ulFreePublicMemory: number, ulTotalPrivateMemory: number, ulFreePrivateMemory: number, hardwareVersion: string, firmwareVersion: string, mechanisms: Array<Mechanism>);
}
export declare class Mechanism {
    mechanism: string;
    flags: Array<string>;
    ulMinKeySize: number;
    ulMaxKeySize: number;
    constructor(mechanism: string, flags: Array<string>, ulMinKeySize: number, ulMaxKeySize: number);
}
export declare class Pkcs11TokenResponse {
    data: Pkcs11TokenInfo;
    success: boolean;
    constructor(data: Pkcs11TokenInfo, success: boolean);
}
export declare class Pkcs11ModuleConfig {
    linux: string;
    mac: string;
    win: string;
    constructor(linux: string, mac: string, win: string);
}
