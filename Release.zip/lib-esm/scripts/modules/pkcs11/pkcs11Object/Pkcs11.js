import { Pkcs11ObjectCertificate, Pkcs11ObjectCertificates, Pkcs11ObjectCertificatesResponse, } from './Pkcs11Model';
import { ResponseHandler } from "../../../util/ResponseHandler";
import { CertParser } from "../../../util/CertParser";
import { Pinutil } from "../../../..";
var PKCS11 = (function () {
    function PKCS11(baseUrl, containerUrl, connection, configPath) {
        this.baseUrl = baseUrl;
        this.containerUrl = containerUrl;
        this.connection = connection;
        this.configPath = configPath;
        this.modulePath = '';
    }
    PKCS11.prototype.certificates = function (slotId, parseCerts, callback) {
        var _this = this;
        return this.setLibrary().then(function (_) {
            return _this.connection.get(_this.baseUrl, _this.pkcs11Path(PKCS11.ALL_CERTIFICATES, slotId), undefined)
                .then(function (res) {
                if (parseCerts) {
                    var newRes_1 = new Pkcs11ObjectCertificates([]);
                    res.data.certificates.forEach(function (cert) {
                        newRes_1.certificates.push(new Pkcs11ObjectCertificate(cert.id, cert.certificate, CertParser.processCert(cert.certificate)));
                    });
                    return ResponseHandler.response(new Pkcs11ObjectCertificatesResponse(newRes_1, res.success), callback);
                }
                else {
                    return ResponseHandler.response(res, callback);
                }
            })
                .catch(function (error) {
                return ResponseHandler.error(error, callback);
            });
        });
    };
    PKCS11.prototype.signData = function (signData, callback) {
        var _this = this;
        signData.pin = Pinutil.encryptPin(signData.pin, this.connection.cfg.version);
        return this.setLibrary().then(function (res) {
            var req = {
                certificateId: signData.certificateId,
                slotId: signData.slotId,
                pin: signData.pin,
                data: signData.data,
                algorithm: signData.algorithm,
                osDialog: signData.osDialog,
                base64Encoded: true
            };
            return _this.connection.post(_this.baseUrl, _this.pkcs11Path(PKCS11.SIGN, signData.slotId), req, undefined, undefined, callback);
        });
    };
    PKCS11.prototype.slots = function (callback) {
        var _this = this;
        return this.setLibrary().then(function (res) {
            return _this.connection.get(_this.baseUrl, _this.pkcs11Path(PKCS11.SLOTS), undefined, undefined, callback);
        });
    };
    PKCS11.prototype.slotsWithTokenPresent = function (callback) {
        var _this = this;
        return this.setLibrary().then(function (res) {
            return _this.connection.get(_this.baseUrl, _this.pkcs11Path(PKCS11.SLOTS), undefined, { 'token-present': 'true' }, callback);
        });
    };
    PKCS11.prototype.token = function (slotId, callback) {
        var _this = this;
        return this.setLibrary().then(function (res) {
            return _this.connection.get(_this.baseUrl, _this.pkcs11Path(PKCS11.TOKEN, slotId), undefined, undefined, callback);
        });
    };
    PKCS11.prototype.setLibrary = function (callback) {
        var req = Object.assign({ path: this.configPath });
        return this.connection.post(this.baseUrl, this.pkcs11Path(PKCS11.CONFIG), req, undefined, undefined, callback);
    };
    PKCS11.prototype.pkcs11Path = function (path, slotNumber) {
        var suffix = this.containerUrl;
        if (slotNumber != null || slotNumber != undefined) {
            suffix += PKCS11.PATH_SLOT_ID + slotNumber;
        }
        if (path && path.length) {
            suffix += path.startsWith('/') ? path : '/' + path;
        }
        return suffix;
    };
    PKCS11.PATH_SLOT_ID = '/slots/';
    PKCS11.ALL_CERTIFICATES = '/certificates';
    PKCS11.CONFIG = '/config';
    PKCS11.INFO = '/info';
    PKCS11.SIGN = '/sign';
    PKCS11.SLOTS = '/slots';
    PKCS11.TOKEN = '/token-info';
    return PKCS11;
}());
export { PKCS11 };
//# sourceMappingURL=Pkcs11.js.map