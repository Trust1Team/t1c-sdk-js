var Wacom = (function () {
    function Wacom(baseUrl, containerUrl, connection) {
        this.baseUrl = baseUrl;
        this.containerUrl = containerUrl;
        this.connection = connection;
    }
    Wacom.prototype.getDevices = function (callback) {
        return this.connection.get(this.baseUrl, this.wacomApp(Wacom.DEVICES), undefined, undefined, callback);
    };
    Wacom.prototype.signData = function (body, callback) {
        return this.connection.post(this.baseUrl, this.wacomApp(Wacom.SIGN), body, undefined, undefined, callback);
    };
    Wacom.prototype.systemInfo = function (callback) {
        return this.connection.get(this.baseUrl, this.wacomApp(Wacom.SYSTEM_INFO), undefined, undefined, callback);
    };
    Wacom.prototype.wacomApp = function (path) {
        var suffix = this.containerUrl;
        if (path && path.length) {
            suffix += path.startsWith('/') ? path : '/' + path;
        }
        return suffix;
    };
    Wacom.CONTAINER_PREFIX = 'wacom-stu';
    Wacom.GET = '/get-key';
    Wacom.DEVICES = '/devices';
    Wacom.SIGN = '/sign';
    Wacom.SYSTEM_INFO = '/system-info';
    return Wacom;
}());
export { Wacom };
//# sourceMappingURL=Wacom.js.map