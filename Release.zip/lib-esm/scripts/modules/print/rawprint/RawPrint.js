var RawPrint = (function () {
    function RawPrint(baseUrl, containerUrl, connection) {
        this.baseUrl = baseUrl;
        this.containerUrl = containerUrl;
        this.connection = connection;
    }
    RawPrint.prototype.list = function (callback) {
        return this.connection.get(this.baseUrl, this.printApp(RawPrint.LIST), undefined, undefined, callback);
    };
    RawPrint.prototype.print = function (name, job, data, callback) {
        var body = { name: name, job: job, data: data };
        return this.connection.post(this.baseUrl, this.printApp(RawPrint.PRINT), body, undefined, undefined, callback);
    };
    RawPrint.prototype.printApp = function (path) {
        var suffix = this.containerUrl;
        suffix += RawPrint.PATHPRINTAPP;
        if (path && path.length) {
            suffix += path.startsWith('/') ? path : '/' + path;
        }
        return suffix;
    };
    RawPrint.PATHPRINTAPP = '/apps/print';
    RawPrint.LIST = '/printer-list';
    RawPrint.PRINT = '/print';
    return RawPrint;
}());
export { RawPrint };
//# sourceMappingURL=RawPrint.js.map