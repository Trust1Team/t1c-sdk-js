import { PrintResponse, PrinterListResponse, AbstractRawPrint } from "./RawPrintModel";
import { LocalConnection, T1CLibException } from "../../../..";
export declare class RawPrint implements AbstractRawPrint {
    protected baseUrl: string;
    protected containerUrl: string;
    protected connection: LocalConnection;
    static PATHPRINTAPP: string;
    static LIST: string;
    static PRINT: string;
    constructor(baseUrl: string, containerUrl: string, connection: LocalConnection);
    list(callback?: (error: T1CLibException, data: PrinterListResponse) => void): Promise<PrinterListResponse>;
    print(name: string, job: string, data: string, callback?: (error: T1CLibException, data: PrintResponse) => void): Promise<PrintResponse>;
    protected printApp(path?: string): string;
}
