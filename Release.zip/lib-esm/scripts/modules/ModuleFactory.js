import { EidBe } from './smartcards/token/eid/be/EidBe';
import { Aventra } from './smartcards/token/pki/aventra4/Aventra';
import { Oberthur } from "./smartcards/token/pki/oberthur73/Oberthur";
import { Idemia } from "./smartcards/token/pki/idemia82/Idemia";
import { Emv } from "./smartcards/payment/emv/Emv";
import { FileExchange } from "./file/fileExchange/FileExchange";
import { RemoteLoading } from "./hsm/remoteloading/RemoteLoading";
import { EidGeneric } from "./smartcards/token/eid/generic/EidGeneric";
import { EidDiplad } from "./smartcards/token/eid/diplad/EidDiplad";
import { PaymentGeneric } from "./smartcards/payment/generic/PaymentGeneric";
import { EidLux } from "./smartcards/token/eid/lux/EidLux";
import { Wacom } from "./wacom/Wacom";
import { Crelan } from "./smartcards/payment/crelan/Crelan";
import { RawPrint } from "./print/rawprint/RawPrint";
import { Certigna } from "./smartcards/token/pki/certigna/Certigna";
import { DNIe } from "./smartcards/token/pki/dnie/DNIe";
import { Certinomis } from "./smartcards/token/pki/certinomis/Certinomis";
import { Safenet } from "./smartcards/token/pki/safenet/Safenet";
import { EHerkenning } from "./smartcards/token/pki/eHerkenning/eHerkenning";
import { Jcop } from "./smartcards/token/pki/jcop/Jcop";
import { Airbus } from "./smartcards/token/pki/airbus/Airbus";
var CONTAINER_NEW_CONTEXT_PATH = '/modules/';
var CONTAINER_BEID = CONTAINER_NEW_CONTEXT_PATH + 'beid';
var CONTAINER_DIPLAD = CONTAINER_NEW_CONTEXT_PATH + 'diplad';
var CONTAINER_LUXEID = CONTAINER_NEW_CONTEXT_PATH + 'luxeid';
var CONTAINER_DNIE = CONTAINER_NEW_CONTEXT_PATH + 'dnie';
var CONTAINER_SAFENET = CONTAINER_NEW_CONTEXT_PATH + 'safenet';
var CONTAINER_EHERKENNING = CONTAINER_NEW_CONTEXT_PATH + 'eherkenning';
var CONTAINER_JCOP = CONTAINER_NEW_CONTEXT_PATH + 'jcop3';
var CONTAINER_AIRBUS = CONTAINER_NEW_CONTEXT_PATH + 'airbus';
var CONTAINER_EMV = CONTAINER_NEW_CONTEXT_PATH + 'emv';
var CONTAINER_CRELAN = CONTAINER_NEW_CONTEXT_PATH + 'crelan';
var CONTAINER_WACOM = CONTAINER_NEW_CONTEXT_PATH + 'wacom-stu';
var CONTAINER_ISABEL = CONTAINER_NEW_CONTEXT_PATH + 'isabel';
var CONTAINER_FILE_EXCHANGE = CONTAINER_NEW_CONTEXT_PATH + 'fileexchange';
var CONTAINER_LUXTRUST = CONTAINER_NEW_CONTEXT_PATH + 'luxtrust';
var CONTAINER_MOBIB = CONTAINER_NEW_CONTEXT_PATH + 'mobib';
var CONTAINER_OCRA = CONTAINER_NEW_CONTEXT_PATH + 'ocra';
var CONTAINER_AVENTRA = CONTAINER_NEW_CONTEXT_PATH + 'aventra_myid_4';
var CONTAINER_OBERTHUR = CONTAINER_NEW_CONTEXT_PATH + 'oberthur_73';
var CONTAINER_IDEMIA = CONTAINER_NEW_CONTEXT_PATH + 'idemia_cosmo_82';
var CONTAINER_PIV = CONTAINER_NEW_CONTEXT_PATH + 'piv';
var CONTAINER_PTEID = CONTAINER_NEW_CONTEXT_PATH + 'pteid';
var CONTAINER_REMOTE_LOADING = CONTAINER_NEW_CONTEXT_PATH + 'remoteloading';
var CONTAINER_JAVA_KEY_TOOL = CONTAINER_NEW_CONTEXT_PATH + 'java-keytool';
var CONTAINER_SSH = CONTAINER_NEW_CONTEXT_PATH + 'ssh';
var CONTAINER_RAW_PRINT = CONTAINER_NEW_CONTEXT_PATH + 'rawprint';
var CONTAINER_CERTIGNA = CONTAINER_NEW_CONTEXT_PATH + 'certigna';
var CONTAINER_CERTINOMIS = CONTAINER_NEW_CONTEXT_PATH + 'certinomis';
var ModuleFactory = (function () {
    function ModuleFactory(url, connection) {
        this.url = url;
        this.connection = connection;
    }
    ModuleFactory.prototype.createEidGeneric = function (reader_id, pin, pinType) {
        return new EidGeneric(this.url, CONTAINER_NEW_CONTEXT_PATH, this.connection, reader_id, pin, pinType);
    };
    ModuleFactory.prototype.createPaymentGeneric = function (reader_id) {
        return new PaymentGeneric(this.url, CONTAINER_NEW_CONTEXT_PATH, this.connection, reader_id);
    };
    ModuleFactory.prototype.createEidDiplad = function (reader_id) {
        return new EidDiplad(this.url, CONTAINER_DIPLAD, this.connection, reader_id);
    };
    ModuleFactory.prototype.createEidBE = function (reader_id) {
        return new EidBe(this.url, CONTAINER_BEID, this.connection, reader_id);
    };
    ModuleFactory.prototype.createAventra = function (reader_id) {
        return new Aventra(this.url, CONTAINER_AVENTRA, this.connection, reader_id);
    };
    ModuleFactory.prototype.createOberthur = function (reader_id) {
        return new Oberthur(this.url, CONTAINER_OBERTHUR, this.connection, reader_id);
    };
    ModuleFactory.prototype.createIdemia = function (reader_id) {
        return new Idemia(this.url, CONTAINER_IDEMIA, this.connection, reader_id);
    };
    ModuleFactory.prototype.createEmv = function (reader_id) {
        return new Emv(this.url, CONTAINER_EMV, this.connection, reader_id);
    };
    ModuleFactory.prototype.createCrelan = function (reader_id) {
        return new Crelan(this.url, CONTAINER_CRELAN, this.connection, reader_id);
    };
    ModuleFactory.prototype.createFileExchange = function () {
        return new FileExchange(this.url, CONTAINER_FILE_EXCHANGE, this.connection);
    };
    ModuleFactory.prototype.createRawPrint = function () {
        return new RawPrint(this.url, CONTAINER_RAW_PRINT, this.connection);
    };
    ModuleFactory.prototype.createRemoteLoading = function (reader_id) {
        return new RemoteLoading(this.url, CONTAINER_REMOTE_LOADING, this.connection, reader_id);
    };
    ModuleFactory.prototype.createEidLUX = function (reader_id, pin, pinType) {
        return new EidLux(this.url, CONTAINER_LUXEID, this.connection, reader_id, pin, pinType);
    };
    ModuleFactory.prototype.createWacom = function () {
        return new Wacom(this.url, CONTAINER_WACOM, this.connection);
    };
    ModuleFactory.prototype.createCertigna = function (reader_id) {
        return new Certigna(this.url, CONTAINER_CERTIGNA, this.connection, reader_id);
    };
    ModuleFactory.prototype.createCertinomis = function (reader_id) {
        return new Certinomis(this.url, CONTAINER_CERTINOMIS, this.connection, reader_id);
    };
    ModuleFactory.prototype.createDNIe = function (reader_id) {
        return new DNIe(this.url, CONTAINER_DNIE, this.connection, reader_id);
    };
    ModuleFactory.prototype.createSafenet = function (reader_id) {
        return new Safenet(this.url, CONTAINER_SAFENET, this.connection, reader_id);
    };
    ModuleFactory.prototype.createEherkenning = function (reader_id) {
        return new EHerkenning(this.url, CONTAINER_EHERKENNING, this.connection, reader_id);
    };
    ModuleFactory.prototype.createJcop = function (reader_id) {
        return new Jcop(this.url, CONTAINER_JCOP, this.connection, reader_id);
    };
    ModuleFactory.prototype.createAirbus = function (reader_id) {
        return new Airbus(this.url, CONTAINER_AIRBUS, this.connection, reader_id);
    };
    return ModuleFactory;
}());
export { ModuleFactory };
//# sourceMappingURL=ModuleFactory.js.map